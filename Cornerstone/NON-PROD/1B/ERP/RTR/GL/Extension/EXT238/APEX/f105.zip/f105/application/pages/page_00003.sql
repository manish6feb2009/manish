prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1205386977126596
,p_default_application_id=>105
,p_default_id_offset=>35798846405545990
,p_default_owner=>'FININT'
);
wwv_flow_api.create_page(
 p_id=>3
,p_user_interface_id=>wwv_flow_api.id(43190103830617253)
,p_name=>'WSC_INTER-INTRA_COMPANY_UPLOAD_RESULT'
,p_alias=>'WSC-INTER-INTRA-COMPANY-UPLOAD-RESULT'
,p_page_mode=>'MODAL'
,p_step_title=>'WSC_INTER-INTRA_COMPANY_UPLOAD_RESULT'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_api.id(43050635187617170)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'700'
,p_dialog_width=>'1300'
,p_page_is_public_y_n=>'Y'
,p_rejoin_existing_sessions=>'Y'
,p_last_updated_by=>'WESCO_UAT_DEVELOPER'
,p_last_upd_yyyymmddhh24miss=>'20230323105729'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(29678085751564918389)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(43098635012617198)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    C001 LE,',
'	C002 OP_GROUP,',
'	C003 ACCOUNT,',
'	C004 DEPT,',
'	C005 SITE,',
'	C006 IC,',
'	C007 PROJECT,',
'	C008 FUTURE1,',
'    C009 FUTURE2,  ',
'    C010 IC_PARTNER_IDENTIFIER,',
'    C011 TRANSACTION_CURRENCY,',
'    C012 ENTERED_DEBIT,',
'    C013 ENTERED_CREDIT,',
'    C014 ACCOUNTED_DEBIT,',
'    C015 ACCOUNTED_CREDIT,',
'    C016 LINE_DESCRIPTION',
'    FROM APEX_COLLECTIONS C',
'WHERE C.COLLECTION_NAME=''XL2''',
'AND SEQ_ID > 10;'))
,p_plug_source_type=>'NATIVE_IG'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(43411475051865535)
,p_name=>'LE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LE'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'LE'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>270
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(43411618515865536)
,p_name=>'OP_GROUP'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'OP_GROUP'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Op Group'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>280
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(43411656218865537)
,p_name=>'ACCOUNT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ACCOUNT'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Account'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>290
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(43411837893865538)
,p_name=>'DEPT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DEPT'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Dept'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>300
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(43411938214865539)
,p_name=>'SITE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SITE'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Site'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>310
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(43411947426865540)
,p_name=>'IC'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'IC'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'IC'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>320
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(43584441756445291)
,p_name=>'PROJECT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PROJECT'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Project'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>330
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(43584455231445292)
,p_name=>'FUTURE1'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FUTURE1'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Future1'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>340
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(43584604207445293)
,p_name=>'FUTURE2'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FUTURE2'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Future2'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>350
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(43584649531445294)
,p_name=>'IC_PARTNER_IDENTIFIER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'IC_PARTNER_IDENTIFIER'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Ic Partner Identifier'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>360
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(43584778310445295)
,p_name=>'TRANSACTION_CURRENCY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TRANSACTION_CURRENCY'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Transaction Currency'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>370
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(77687850413057701)
,p_name=>'ENTERED_DEBIT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ENTERED_DEBIT'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Entered Debit'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>190
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(77687925307057702)
,p_name=>'ENTERED_CREDIT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ENTERED_CREDIT'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Entered Credit'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>200
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(77688329856057706)
,p_name=>'ACCOUNTED_DEBIT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ACCOUNTED_DEBIT'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Accounted Debit'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>240
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(77688459105057707)
,p_name=>'ACCOUNTED_CREDIT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ACCOUNTED_CREDIT'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Accounted Credit'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>250
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(77688551312057708)
,p_name=>'LINE_DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LINE_DESCRIPTION'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Line Description'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>260
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_interactive_grid(
 p_id=>wwv_flow_api.id(29678085914959918390)
,p_internal_uid=>29642287068554372400
,p_is_editable=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_show_nulls_as=>'-'
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_api.create_ig_report(
 p_id=>wwv_flow_api.id(29679871848996392617)
,p_interactive_grid_id=>wwv_flow_api.id(29678085914959918390)
,p_static_id=>'120775262'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_api.create_ig_report_view(
 p_id=>wwv_flow_api.id(29679871986852392617)
,p_report_id=>wwv_flow_api.id(29679871848996392617)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(43590405015445717)
,p_view_id=>wwv_flow_api.id(29679871986852392617)
,p_display_seq=>5
,p_column_id=>wwv_flow_api.id(43411475051865535)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>65
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(43591284435445720)
,p_view_id=>wwv_flow_api.id(29679871986852392617)
,p_display_seq=>6
,p_column_id=>wwv_flow_api.id(43411618515865536)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>86
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(43592179557445723)
,p_view_id=>wwv_flow_api.id(29679871986852392617)
,p_display_seq=>7
,p_column_id=>wwv_flow_api.id(43411656218865537)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>65
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(43593122297445725)
,p_view_id=>wwv_flow_api.id(29679871986852392617)
,p_display_seq=>8
,p_column_id=>wwv_flow_api.id(43411837893865538)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>57
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(43593958260445728)
,p_view_id=>wwv_flow_api.id(29679871986852392617)
,p_display_seq=>9
,p_column_id=>wwv_flow_api.id(43411938214865539)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(43594906923445731)
,p_view_id=>wwv_flow_api.id(29679871986852392617)
,p_display_seq=>10
,p_column_id=>wwv_flow_api.id(43411947426865540)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(43595792907445733)
,p_view_id=>wwv_flow_api.id(29679871986852392617)
,p_display_seq=>11
,p_column_id=>wwv_flow_api.id(43584441756445291)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>64
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(43596678824445736)
,p_view_id=>wwv_flow_api.id(29679871986852392617)
,p_display_seq=>12
,p_column_id=>wwv_flow_api.id(43584455231445292)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>67
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(43597623402445739)
,p_view_id=>wwv_flow_api.id(29679871986852392617)
,p_display_seq=>13
,p_column_id=>wwv_flow_api.id(43584604207445293)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>70
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(43598478895445742)
,p_view_id=>wwv_flow_api.id(29679871986852392617)
,p_display_seq=>14
,p_column_id=>wwv_flow_api.id(43584649531445294)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>137
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(43599422781445744)
,p_view_id=>wwv_flow_api.id(29679871986852392617)
,p_display_seq=>15
,p_column_id=>wwv_flow_api.id(43584778310445295)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>140
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(77707844255203832)
,p_view_id=>wwv_flow_api.id(29679871986852392617)
,p_display_seq=>0
,p_column_id=>wwv_flow_api.id(77687850413057701)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>90
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(77708750891203841)
,p_view_id=>wwv_flow_api.id(29679871986852392617)
,p_display_seq=>1
,p_column_id=>wwv_flow_api.id(77687925307057702)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>90
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(77712329913203880)
,p_view_id=>wwv_flow_api.id(29679871986852392617)
,p_display_seq=>2
,p_column_id=>wwv_flow_api.id(77688329856057706)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>120
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(77713254998203887)
,p_view_id=>wwv_flow_api.id(29679871986852392617)
,p_display_seq=>3
,p_column_id=>wwv_flow_api.id(77688459105057707)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>125
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(77714097664203894)
,p_view_id=>wwv_flow_api.id(29679871986852392617)
,p_display_seq=>4
,p_column_id=>wwv_flow_api.id(77688551312057708)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>117
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(29679829023099783062)
,p_plug_name=>'Vendor Cost Data Upload'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(43069543803617182)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43283780135648194)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(29679829023099783062)
,p_button_name=>'P3_LOAD'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(43165564723617237)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Load'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43285715935648195)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(29678085751564918389)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(43165564723617237)
,p_button_image_alt=>'Cancel'
,p_button_position=>'BELOW_BOX'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43286124903648195)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(29678085751564918389)
,p_button_name=>'Finish'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(43165564723617237)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Finish'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(43293393811648202)
,p_branch_name=>'Go To Page 2'
,p_branch_action=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:RP,::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(43285715935648195)
,p_branch_sequence=>30
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43284201346648194)
,p_name=>'P3_NEW_1'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(29679829023099783062)
,p_prompt=>'Please Select the Excel File:'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(43163084891617236)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'REQUEST'
,p_attribute_10=>'N'
,p_attribute_12=>'NATIVE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43284644474648194)
,p_name=>'P3_NEW'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(29679829023099783062)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43284968615648195)
,p_name=>'P3_ERROR_MSG'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(29679829023099783062)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(43287278088648197)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(43285715935648195)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(43287763909648198)
,p_event_id=>wwv_flow_api.id(43287278088648197)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(43288222798648198)
,p_name=>'New'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P3_BROWSE'
,p_condition_element=>'P3_BROWSE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(43288720869648199)
,p_event_id=>wwv_flow_api.id(43288222798648198)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var fp = $("#P3_BROWSE");',
'var lg = fp[0].files.length; // get length',
'var items = fp[0].files;',
'if (lg > 0) {',
'        for (var i = 0; i < lg; i++) {',
'            var fileName = items[i].name; // get file name',
'            var fileSize = items[i].size; // get file size ',
'            var fileType = items[i].type; // get file type',
'            apex.item( "P3_NEW" ).setValue( fileName, null, true );',
'           ',
' }',
'',
'}'))
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(43289205282648199)
,p_event_id=>wwv_flow_api.id(43288222798648198)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P_FILE_NAME := :P3_NEW;'
,p_attribute_02=>'P_FILE_NAME,P3_NEW'
,p_attribute_03=>'P_FILE_NAME'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(43289617502648199)
,p_name=>'New_2'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P3_BROWSE_1'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(43290052963648200)
,p_event_id=>wwv_flow_api.id(43289617502648199)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var fp = $("#P3_BROWSE_1");',
'var lg = fp[0].files.length; // get length',
'var items = fp[0].files;',
'if (lg > 0) {',
'        for (var i = 0; i < lg; i++) {',
'            var fileName = items[i].name; // get file name',
'            var fileSize = items[i].size; // get file size ',
'            var fileType = items[i].type; // get file type',
'            apex.item( "P3_NEW" ).setValue( fileName, null, true );',
'           ',
' }',
'',
'}'))
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(43290590863648200)
,p_event_id=>wwv_flow_api.id(43289617502648199)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P_FILE_NAME := :P3_NEW;'
,p_attribute_02=>'P3_NEW,P_FILE_NAME'
,p_attribute_03=>'P_FILE_NAME'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(43291022521648200)
,p_name=>'New_1'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(43286124903648195)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(43291537997648200)
,p_event_id=>wwv_flow_api.id(43291022521648200)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'APEX_COLLECTION.TRUNCATE_COLLECTION( ',
'',
'',
'    p_collection_name => ''XL2'');'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(43291856565648201)
,p_name=>'New_2'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P3_NEW_1'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(43292364574648201)
,p_event_id=>wwv_flow_api.id(43291856565648201)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var fp = $("#P3_NEW_1");',
'var lg = fp[0].files.length; // get length',
'var items = fp[0].files;',
'if (lg > 0) {',
'        for (var i = 0; i < lg; i++) {',
'            var fileName = items[i].name; // get file name',
'            var fileSize = items[i].size; // get file size ',
'            var fileType = items[i].type; // get file type',
'            apex.item( "P3_NEW" ).setValue( fileName, null, true );',
'           ',
' }',
'',
'}'))
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(43292888933648201)
,p_event_id=>wwv_flow_api.id(43291856565648201)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P_FILE_NAME := :P3_NEW;'
,p_attribute_02=>'P3_NEW,P_FILE_NAME'
,p_attribute_03=>'P_FILE_NAME'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(43286922658648197)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'PLUGIN_NL.AMIS.SCHEFFER.PROCESS.EXCEL2COLLECTION'
,p_process_name=>'ParseItemsDataFromXLSX'
,p_attribute_01=>'P3_NEW_1'
,p_attribute_02=>'XL2'
,p_attribute_03=>'1'
,p_attribute_04=>';'
,p_attribute_05=>'"'
,p_attribute_07=>'Y'
,p_attribute_08=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(43283780135648194)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(43286447880648196)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'LoadParsedItemsData'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Declare',
'    Line_ID_Value number;',
'    P_Header_ID Number;',
'    test varchar2(7);',
'    USER_NAME varchar2(200);',
'    LV_COA_MAP_CNT number;',
'    lv_error_msg varchar2(400);',
'    lv_error varchar2(30) := ''False'';',
'    V_COA_MAP_CHECK varchar2(200);',
'    error_flag varchar2(1000) ;',
'    p_count number;',
'    p_count_v number;',
'    provider_LE varchar2(30);',
'    e_error exception;',
'    p_count_identifier number;',
'    p_count_identifier_ic number;',
'    ',
'    lv_err_msg varchar2(1000);',
'    CURSOR cur_validation_msg (',
'            P_Header_ID VARCHAR2',
'        ) IS',
'        SELECT',
'            PROVIDER ,IC_TRANSACTION_TYPE, ACCOUNTING_DATE, BATCH_DESCRIPTION, JOURNAL_CATAGORY, IC_BATCH_DATE',
'        FROM',
'            WSC_INTER_INTRA_COMPANY_FILE_HDR_T',
'        WHERE',
'            batch_id = P_Header_ID;',
'    TYPE wsc_vali_ic_value_type IS VARRAY(17) OF VARCHAR2(50); ',
'    lv_vali_ic_value wsc_vali_ic_value_type := wsc_vali_ic_value_type(''Provider'',''IC Transaction Type'',''Accounting Date'',''Batch Description'',''Journal Category'',''IC Batch Date'');',
'    TYPE wsc_vali_ic_value_1_type IS TABLE OF INTEGER;',
'    lv_vali_ic_value_1 wsc_vali_ic_value_1_type := wsc_vali_ic_value_1_type(''1'', ''1'', ''1'', ''1'', ''1'',''1''); ',
'',
'    TYPE wsc_vali_without_ic_value_type IS VARRAY(17) OF VARCHAR2(50); ',
'    lv_vali_without_ic_value   wsc_vali_without_ic_value_type := wsc_vali_without_ic_value_type(''Provider'',''IC Transaction Type'',''Accounting Date'',''Batch Description'',''IC Batch Date'');',
'    TYPE wsc_vali_without_ic_value_1_type IS TABLE OF INTEGER;',
'    lv_vali_without_ic_value_1 wsc_vali_without_ic_value_1_type := wsc_vali_without_ic_value_1_type(''1'', ''1'', ''1'', ''1'', ''1''); ',
'',
'begin',
'    if upper(substr(:P_FILE_NAME,instr(:P_FILE_NAME,''.'',1)+1,length(:P_FILE_NAME)-instr(:P_FILE_NAME,''.'',1))) = upper(''CSV'') then',
'    insert into wsc_tbl_time_t(a,b,c) values (''123'',sysdate,999999);',
'    -- null;',
'        apex_util.set_session_state(''P3_ERROR_MSG'', ''Please Upload Excel Template'');',
'        raise e_error;',
'    else ',
'    -- insert into wsc_tbl_time_t(a,b,c) values (''1'',sysdate,999999);',
'    -- commit;',
'        select count(*) into p_count_identifier from APEX_COLLECTIONS C WHERE C.COLLECTION_NAME=''XL2'' AND SEQ_ID>10 and C.C010 = ''INTRA'' order by SEQ_ID; ',
'        select count(*) into p_count_identifier_ic from APEX_COLLECTIONS C WHERE C.COLLECTION_NAME=''XL2'' AND SEQ_ID>10 and C.C010 <> ''INTRA'' order by SEQ_ID; ',
'        -- insert into temp_data(LEGACY_HEADER_ID,LEGACY_LINE_NUMBER,APPLICATION)values(p_count_identifier,p_count_identifier_ic,test);',
'        -- insert into wsc_tbl_time_t(a,b,c) values (''2'',sysdate,999999);',
'        -- commit;',
'	    P_Header_ID := WSC_INTER_INTRA_COMPANY_SEQ_H.nextval;',
'        insert into WSC_INTER_INTRA_COMPANY_FILE_HDR_T(BATCH_ID,FILE_NAME,USER_NAME,STATUS,PROVIDER,IC_TRANSACTION_TYPE,IC_BATCH_DATE,ACCOUNTING_DATE,',
'        BATCH_DESCRIPTION,JOURNAL_CATAGORY,CONVERSION_RATE_TYPE) ',
'        Select P_Header_ID,:P_FILE_NAME,:P_USER_NAME,''In Progress'',C0030.C002,C0031.C002,to_date(C0032.C002,''dd-mm-yyyy hh24:mi:ss''),to_date(C0033.C002,''dd-mm-yyyy hh24:mi:ss''),',
'        C0051.C004,C0052.C004,C0053.C004',
'        FROM ',
'        (select C002,C.COLLECTION_NAME FROM APEX_COLLECTIONS C WHERE C.COLLECTION_NAME=''XL2'' AND SEQ_ID=4) C0030,',
'        (select C002,C.COLLECTION_NAME FROM APEX_COLLECTIONS C WHERE C.COLLECTION_NAME=''XL2'' AND SEQ_ID=5) C0031,',
'        (select C002,C.COLLECTION_NAME FROM APEX_COLLECTIONS C WHERE C.COLLECTION_NAME=''XL2'' AND SEQ_ID=6) C0032,',
'        (select C002,C.COLLECTION_NAME FROM APEX_COLLECTIONS C WHERE C.COLLECTION_NAME=''XL2'' AND SEQ_ID=7) C0033,',
'        (select C004,C.COLLECTION_NAME FROM APEX_COLLECTIONS C WHERE C.COLLECTION_NAME=''XL2'' AND SEQ_ID=4) C0051,',
'        (select C004,C.COLLECTION_NAME FROM APEX_COLLECTIONS C WHERE C.COLLECTION_NAME=''XL2'' AND SEQ_ID=5) C0052,',
'        (select C004,C.COLLECTION_NAME FROM APEX_COLLECTIONS C WHERE C.COLLECTION_NAME=''XL2'' AND SEQ_ID=6) C0053',
'        where C0030.COLLECTION_NAME=C0031.COLLECTION_NAME AND C0032.COLLECTION_NAME=C0031.COLLECTION_NAME',
'          AND C0033.COLLECTION_NAME=C0031.COLLECTION_NAME AND C0051.COLLECTION_NAME=C0031.COLLECTION_NAME ',
'          AND C0052.COLLECTION_NAME=C0031.COLLECTION_NAME AND C0053.COLLECTION_NAME=C0031.COLLECTION_NAME;',
'-- if(p_count_identifier >0)then',
'-- select ''abc'' into test from dual;',
'-- insert into wsc_tbl_time_t(a,b,c) values (''3'',sysdate,999999);',
'--         commit;',
'--         insert into temp_data(LEGACY_HEADER_ID,LEGACY_LINE_NUMBER,APPLICATION)values(p_count_identifier,p_count_identifier_ic,test);',
'-- end if;',
'',
'        ',
'        if(p_count_identifier_ic>=0 and p_count_identifier>0)then',
'        -- insert into wsc_tbl_time_t(a,b,c) values (''4'',sysdate,999999);',
'        -- commit;',
'            FOR validation_msg IN cur_validation_msg(P_Header_ID) LOOP',
'                IF validation_msg.PROVIDER IS NULL THEN lv_vali_ic_value_1(1) := 0;ELSE lv_vali_ic_value_1(1) := 1;END IF;',
'                IF validation_msg.IC_TRANSACTION_TYPE IS NULL THEN lv_vali_ic_value_1(2) := 0;ELSE lv_vali_ic_value_1(2) := 1;END IF;',
'                IF validation_msg.ACCOUNTING_DATE IS NULL THEN lv_vali_ic_value_1(3) := 0; ELSE lv_vali_ic_value_1(3) := 1;END IF;',
'                IF validation_msg.BATCH_DESCRIPTION IS NULL THEN lv_vali_ic_value_1(4) := 0;ELSE lv_vali_ic_value_1(4) := 1; END IF;',
'                IF validation_msg.JOURNAL_CATAGORY IS NULL THEN lv_vali_ic_value_1(5) := 0; ELSE lv_vali_ic_value_1(5) := 1;END IF;',
'                IF validation_msg.IC_BATCH_DATE IS NULL THEN lv_vali_ic_value_1(6) := 0; ELSE lv_vali_ic_value_1(6) := 1;END IF;',
'            end loop;',
'',
'            FOR j IN 1..6 LOOP',
'                IF lv_vali_ic_value_1(j) = 0 THEN',
'                    lv_err_msg := lv_err_msg',
'                                        || ''Please enter ''',
'                                        || lv_vali_ic_value(j)',
'                                        || ''. '';',
'                END IF;',
'            END LOOP;',
'            ',
'            update WSC_INTER_INTRA_COMPANY_FILE_HDR_T set status = ''BV_FAIL'',',
'            error_message = lv_err_msg,',
'            -- error_message= ''Provider,Batch Description,IC Transaction Type,Journal Category,IC Batch Date,Accounting Date is mandatory for Intra Company transaction.'',',
'            attribute1 = ''Y'' ',
'            where (PROVIDER is null or IC_TRANSACTION_TYPE is null or ACCOUNTING_DATE is null or BATCH_DESCRIPTION is null or JOURNAL_CATAGORY is null or IC_BATCH_DATE is null) ',
'            and batch_id = P_Header_ID;',
'',
'            select attribute1 into error_flag from WSC_INTER_INTRA_COMPANY_FILE_HDR_T where batch_id = P_Header_ID;',
'',
'        elsif(p_count_identifier = 0 and p_count_identifier_ic >0)then',
'            -- insert into wsc_tbl_time_t(a,b,c) values (''5'',sysdate,999999);',
'            -- commit;',
'            FOR validation_msg IN cur_validation_msg(P_Header_ID) LOOP',
'                IF validation_msg.PROVIDER IS NULL THEN lv_vali_without_ic_value_1(1) := 0;ELSE lv_vali_without_ic_value_1(1) := 1;END IF;',
'                IF validation_msg.IC_TRANSACTION_TYPE IS NULL THEN lv_vali_without_ic_value_1(2) := 0;ELSE lv_vali_without_ic_value_1(2) := 1;END IF;',
'                IF validation_msg.ACCOUNTING_DATE IS NULL THEN lv_vali_without_ic_value_1(3) := 0; ELSE lv_vali_without_ic_value_1(3) := 1;END IF;',
'                IF validation_msg.BATCH_DESCRIPTION IS NULL THEN lv_vali_without_ic_value_1(4) := 0;ELSE lv_vali_without_ic_value_1(4) := 1; END IF;',
'                IF validation_msg.IC_BATCH_DATE IS NULL THEN lv_vali_without_ic_value_1(5) := 0; ELSE lv_vali_without_ic_value_1(5) := 1;END IF;',
'            end loop;',
'            lv_err_msg := '''';',
'            FOR j IN 1..5 LOOP',
'                IF lv_vali_without_ic_value_1(j) = 0 THEN',
'                    lv_err_msg := lv_err_msg',
'                                        || ''Please enter ''',
'                                        || lv_vali_without_ic_value(j)',
'                                        || ''. '';',
'                END IF;',
'            END LOOP;',
'',
'            update WSC_INTER_INTRA_COMPANY_FILE_HDR_T ',
'            set status = ''BV_FAIL'',',
'            error_message= lv_err_msg,',
'            -- error_message= ''Provider,Batch Description,IC Transaction Type,IC Batch Date,Accounting Date is mandatory for Inter Company transaction.'',',
'            attribute1 = ''Y'' ',
'            where (PROVIDER is null or IC_TRANSACTION_TYPE is null or ACCOUNTING_DATE is null',
'            or BATCH_DESCRIPTION is null or IC_BATCH_DATE is null) and batch_id = P_Header_ID;',
'',
'            select attribute1 into error_flag from WSC_INTER_INTRA_COMPANY_FILE_HDR_T where batch_id = P_Header_ID;',
'        ',
'        else',
'            null;',
'        ',
'        end if;',
'',
'',
'        if( ''Y'' = error_flag) THEN',
'            null;',
'        else',
'            select PROVIDER into provider_LE from WSC_INTER_INTRA_COMPANY_FILE_HDR_T where BATCH_ID = P_Header_ID;',
'            insert into WSC_INTER_INTRA_COMPANY_FILE_LINE_T(BATCH_ID,LE , ',
'                OP_GROUP , ',
'                ACCOUNT , ',
'                DEPT , ',
'                SITE , ',
'                IC , ',
'                PROJECT , ',
'                FUTURE1 , ',
'                FUTURE2 , ',
'                IC_PARTNER_IDENTIFIER , ',
'                TRANSACTION_CURRENCY , ',
'                ENTERED_DEBIT , ',
'                ENTERED_CREDIT , ',
'                ACCOUNTED_DEBIT , ',
'                ACCOUNTED_CREDIT , ',
'                LINE_DESCRIPTION) ',
'                select  P_Header_ID,',
'                C001,',
'                C002,',
'                C003,',
'                C004,',
'                C005,',
'                C006,',
'                C007,',
'                C008,',
'                C009,',
'                C010,',
'                C011,',
'                C012,',
'                C013,',
'                C014,',
'                C015,',
'                C016',
'                FROM APEX_COLLECTIONS C',
'                WHERE C.COLLECTION_NAME=''XL2''',
'                AND SEQ_ID>10 order by SEQ_ID ; ',
'            commit;',
'    ',
'            update WSC_INTER_INTRA_COMPANY_FILE_LINE_T ',
'            set status = ''BV_FAIL'',error_message = ''Kindly fill all the mandatory field'',attribute1= ''Y''',
'            where ',
'                (LE is null or ',
'                OP_GROUP is null or ',
'                ACCOUNT is null or ',
'                DEPT is null or ',
'                SITE is null or ',
'                IC is null or ',
'                PROJECT is null or ',
'                FUTURE1 is null or ',
'                FUTURE2 is null or ',
'                IC_PARTNER_IDENTIFIER is null or ',
'                TRANSACTION_CURRENCY is null)',
'                and BATCH_ID = P_Header_ID;',
'',
'            update WSC_INTER_INTRA_COMPANY_FILE_LINE_T ',
'            set status = ''BV_FAIL'', error_message = ''Every line should have a Dr or Cr but not both'', attribute1 = ''Y''',
'            where (ENTERED_DEBIT is not null and ENTERED_CREDIT is not null)  and BATCH_ID = P_Header_ID;',
'',
'            update WSC_INTER_INTRA_COMPANY_FILE_LINE_T ',
'            set status = ''BV_FAIL'', error_message = ''Every line should have atleast Dr or CR'', attribute1 = ''Y''',
'            where (ENTERED_DEBIT is  null and ENTERED_CREDIT is  null)  and BATCH_ID = P_Header_ID;',
'',
'            select count(*) into p_count from(',
'                select sum(entered_debit) sd, sum(entered_credit) sc from WSC_INTER_INTRA_COMPANY_FILE_LINE_T ',
'                where BATCH_ID = P_Header_ID)',
'            where sd<>sc; ',
'',
'            if(p_count>0)then',
'                update WSC_INTER_INTRA_COMPANY_FILE_LINE_T ',
'                set status = ''BV_FAIL'',error_message = ''All line debit total should equal credit total in entered currency '',attribute1 =''Y''',
'                where BATCH_ID = P_Header_ID; ',
'            end if;',
'',
'            select count(*) into p_count_v from WSC_INTER_INTRA_COMPANY_FILE_LINE_T where BATCH_ID = P_Header_ID and attribute1=''Y'';',
'            ',
'            if(p_count_v >0) then',
'                update WSC_INTER_INTRA_COMPANY_FILE_HDR_T set status = ''BV_FAIL'',error_message=''Validation failure'' where  BATCH_ID = P_Header_ID;',
'            else ',
'                update WSC_INTER_INTRA_COMPANY_FILE_HDR_T set status = ''BV_PASS'' where  BATCH_ID = P_Header_ID;',
'                dbms_scheduler.create_job (',
'                job_name   =>  ''WSC_GL_IC_''||to_char(sysdate,''ddmonyyyyhh24miss'')||''_''||WSC_GL_USER_JOB_NAME_S.nextval,',
'                job_type   => ''PLSQL_BLOCK'',',
'                job_action => ',
'                    ''BEGIN ',
'                    WSC_INTER_INTRA_COMPANY_VALIDATION_PKG.wsc_gl_ic_validation(''||P_Header_ID||'');',
'                    END;'',',
'                enabled   =>  TRUE,  ',
'                auto_drop =>  TRUE, ',
'                comments  =>  ''Inserting data into GL and IC table with Validation'');',
'            end if;',
'            commit;',
'        end if;',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'&P3_ERROR_MSG.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
