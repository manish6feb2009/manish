prompt --application/pages/page_00010
begin
--   Manifest
--     PAGE: 00010
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1701052144005286
,p_default_application_id=>108
,p_default_id_offset=>16491536708563557
,p_default_owner=>'FININT'
);
wwv_flow_api.create_page(
 p_id=>10
,p_user_interface_id=>wwv_flow_api.id(26819689742726089)
,p_name=>'LSI REPROCESSING'
,p_alias=>'ERROR-REPRO'
,p_step_title=>'LSI REPROCESSING'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_last_updated_by=>'WESCO_DEV_DEVELOPER'
,p_last_upd_yyyymmddhh24miss=>'20230515171444'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(32083997743680583)
,p_plug_name=>'Error Reprocessing'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(26730122453726012)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2359005727840945)
,p_plug_name=>'Data'
,p_parent_plug_id=>wwv_flow_api.id(32083997743680583)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(26728175846726011)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    record_type,',
'    batch_id,',
'    failed_invoice_count,',
'    failed_payment_count,',
'    failed_receipt_count,',
'    failed_ahcs_count,',
'    accounting_date,',
'    status',
'FROM',
'    (',
'        SELECT',
'            record_type,',
'            batch_id,',
'            (',
'                SELECT',
'                    COUNT(1)',
'                FROM',
'                    wsc_ahcs_lsi_invoice_for_cm_h_t',
'                WHERE',
'                        batch_id = a.batch_id',
'                    AND inv_creation_status = ''REJECTED''',
'            )                                                                                                                                                                                                       failed_invoice_count,',
'            (',
'                SELECT',
'                    COUNT(1)',
'                FROM',
'                    wsc_ahcs_lsi_ap_t',
'                WHERE',
'                        batch_id = a.batch_id',
'                    AND status = ''ERROR''',
'            )                                                                                                                                                                                                       failed_payment_count,',
'            (',
'                SELECT',
'                    COUNT(1)',
'                FROM',
'                    wsc_ahcs_lsi_ar_t',
'                WHERE',
'                        batch_id = a.batch_id',
'                    AND status = ''ERROR''',
'            )                                                                                                                                                                                                       failed_receipt_count,',
'            (select ',
'                count(distinct error_msg) ',
'            from ',
'                wsc_ahcs_lsi_err_t  ',
'            where  ',
'                batch_id=a.batch_id ) failed_ahcs_count,',
'            accounting_date,',
'            decode(inv_pay_status, ''IN PROGRESS'', ''IN PROGRESS'', decode(receipt_status, ''IN PROGRESS'', ''IN PROGRESS'', decode(inv_create_status,',
'            ''IN PROGRESS'', ''IN PROGRESS'', decode(netting_status,''IN PROGRESS'', ''IN PROGRESS'',''REPROCESSABLE''))))                             status',
'        FROM',
'            wsc_ahcs_lsi_control_t a',
'        WHERE',
'            inv_pay_status IN ( ''ERROR'', ''WARNING'', ''IN PROGRESS'' )',
'            OR receipt_status IN ( ''ERROR'', ''WARNING'', ''IN PROGRESS'' )',
'            OR inv_create_status IN ( ''ERROR'', ''WARNING'', ''IN PROGRESS'' )',
'            OR netting_status IN (''NOT SUCCESS'',''PARTIAL SUCCESS'')',
'    )',
'WHERE',
'    failed_payment_count > 0',
'    OR failed_receipt_count > 0',
'    OR failed_invoice_count > 0',
'    OR failed_ahcs_count>0'))
,p_plug_source_type=>'NATIVE_IG'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Data'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(2359391748840948)
,p_name=>'RECORD_TYPE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'RECORD_TYPE'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Record Type'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>10
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>true
,p_max_length=>5
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(2359485002840949)
,p_name=>'BATCH_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BATCH_ID'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Batch Id'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>20
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'right'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(2359566986840950)
,p_name=>'FAILED_PAYMENT_COUNT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FAILED_PAYMENT_COUNT'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Failed Payment Count'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>30
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'right'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(2970737962655402)
,p_name=>'FAILED_AHCS_COUNT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FAILED_AHCS_COUNT'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Failed Ahcs Count'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>80
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'right'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(5447618255114748)
,p_name=>'FAILED_INVOICE_COUNT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FAILED_INVOICE_COUNT'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Failed Invoice Count'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>70
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'right'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(16553995569986801)
,p_name=>'FAILED_RECEIPT_COUNT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FAILED_RECEIPT_COUNT'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Failed Receipt Count'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>40
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'right'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(16554099485986802)
,p_name=>'ACCOUNTING_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ACCOUNTING_DATE'
,p_data_type=>'TIMESTAMP'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>50
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(16554192059986803)
,p_name=>'STATUS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STATUS'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Status'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>13
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_interactive_grid(
 p_id=>wwv_flow_api.id(2359271494840947)
,p_internal_uid=>2359271494840947
,p_is_editable=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SET'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_api.create_ig_report(
 p_id=>wwv_flow_api.id(16559534850988901)
,p_interactive_grid_id=>wwv_flow_api.id(2359271494840947)
,p_static_id=>'165596'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_api.create_ig_report_view(
 p_id=>wwv_flow_api.id(16559776455988901)
,p_report_id=>wwv_flow_api.id(16559534850988901)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(3823106720101677)
,p_view_id=>wwv_flow_api.id(16559776455988901)
,p_display_seq=>6
,p_column_id=>wwv_flow_api.id(2970737962655402)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(8499312261678463)
,p_view_id=>wwv_flow_api.id(16559776455988901)
,p_display_seq=>2
,p_column_id=>wwv_flow_api.id(5447618255114748)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(16560203076988905)
,p_view_id=>wwv_flow_api.id(16559776455988901)
,p_display_seq=>0
,p_column_id=>wwv_flow_api.id(2359391748840948)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(16561167776988911)
,p_view_id=>wwv_flow_api.id(16559776455988901)
,p_display_seq=>1
,p_column_id=>wwv_flow_api.id(2359485002840949)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(16562072210988915)
,p_view_id=>wwv_flow_api.id(16559776455988901)
,p_display_seq=>3
,p_column_id=>wwv_flow_api.id(2359566986840950)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(16562948390988918)
,p_view_id=>wwv_flow_api.id(16559776455988901)
,p_display_seq=>4
,p_column_id=>wwv_flow_api.id(16553995569986801)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(16563865232988921)
,p_view_id=>wwv_flow_api.id(16559776455988901)
,p_display_seq=>6
,p_column_id=>wwv_flow_api.id(16554099485986802)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(16564754724988924)
,p_view_id=>wwv_flow_api.id(16559776455988901)
,p_display_seq=>7
,p_column_id=>wwv_flow_api.id(16554192059986803)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(32558100174749095)
,p_plug_name=>'Submit Error Reprocessing '
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(26730122453726012)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5444349585114715)
,p_plug_name=>'Submit Error Reprocessing '
,p_parent_plug_id=>wwv_flow_api.id(32558100174749095)
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_api.id(26736871889726017)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5444461756114716)
,p_plug_name=>'Payment, Receipt & AHCS Reprocessing'
,p_parent_plug_id=>wwv_flow_api.id(5444349585114715)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(26730122453726012)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5444542176114717)
,p_plug_name=>'Journals & AHCS  Reprocessing'
,p_parent_plug_id=>wwv_flow_api.id(5444349585114715)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(26730122453726012)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5446400974114736)
,p_plug_name=>'CM Invoice Creation Reprocessing'
,p_parent_plug_id=>wwv_flow_api.id(5444349585114715)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(26730122453726012)
,p_plug_display_sequence=>1
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(43888066917057020)
,p_plug_name=>'Adhoc Process Start'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(26730122453726012)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5444981562114721)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(5444542176114717)
,p_button_name=>'SubmitGL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(26795179108726064)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Submit'
,p_button_position=>'BELOW_BOX'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5446797303114739)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(5446400974114736)
,p_button_name=>'SubmitCM'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(26795179108726064)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Submit'
,p_button_position=>'BELOW_BOX'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16202922770450813)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(32083997743680583)
,p_button_name=>'Refresh'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(26795179108726064)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Refresh'
,p_button_position=>'BELOW_BOX'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(32558688244749101)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(5444461756114716)
,p_button_name=>'Submit'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(26795179108726064)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Submit'
,p_button_position=>'BELOW_BOX'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(32674662029001521)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(43888066917057020)
,p_button_name=>'Adhoc_submit'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(26795179108726064)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Submit'
,p_button_position=>'BELOW_BOX'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5444803576114720)
,p_name=>'BATCH_ID_GL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(5444542176114717)
,p_prompt=>'Batch ID'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct a.batch_id from wsc_ahcs_lsi_err_t a,wsc_ahcs_lsi_control_t b',
' where a.batch_id=b.batch_id',
' and b.record_type=''GL'''))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(26792776777726061)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5445159073114723)
,p_name=>'DATE_SELECTION_GL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(5444542176114717)
,p_prompt=>'LSI Run Date'
,p_display_as=>'NATIVE_DATE_PICKER_JET'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(26792482217726061)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5446590963114737)
,p_name=>'BATCH_ID_CM'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(5446400974114736)
,p_prompt=>'Batch ID'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select BATCH_ID',
'      from WSC_AHCS_LSI_CONTROL_T a',
' where Inv_CREATE_status in (''ERROR'',''WARNING'')',
' order by batch_id'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(26792776777726061)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5446624573114738)
,p_name=>'DATE_SELECTION_CM'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(5446400974114736)
,p_prompt=>'LSI Run Date'
,p_display_as=>'NATIVE_DATE_PICKER_JET'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(26792482217726061)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32558204674749096)
,p_name=>'BATCH_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(5444461756114716)
,p_prompt=>'Batch ID'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct batch_id from (select b.batch_id batch_id from (',
'select BATCH_ID,',
'       (select count(1) from wsc_ahcs_lsi_ap_t where batch_id=a.batch_id and status=''ERROR'') failed_payment_count,',
'       (select count(1) from wsc_ahcs_lsi_ar_t where batch_id=a.batch_id and status=''ERROR'') failed_receipt_count',
'      from WSC_AHCS_LSI_CONTROL_T a',
'where (Inv_pay_status in (''ERROR'',''WARNING'') or Receipt_status in (''ERROR'',''WARNING''))',
'AND Inv_pay_status!=''IN PROGRESS'' AND Receipt_status!=''IN PROGRESS'') b',
'where b.failed_payment_count <> 0 or failed_receipt_count <> 0',
'--  order by b.batch_id',
'union all',
'select distinct a.batch_id from wsc_ahcs_lsi_err_t a,wsc_ahcs_lsi_control_t b',
'where a.batch_id=b.batch_id',
'and b.record_type=''AP-AR'')',
'order by batch_id'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(26792776777726061)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32559277823749107)
,p_name=>'DATE_SELECTION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(5444461756114716)
,p_prompt=>'LSI Run Date'
,p_display_as=>'NATIVE_DATE_PICKER_JET'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(26792482217726061)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32675497119001526)
,p_name=>'10_HINT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(43888066917057020)
,p_source=>'Please provide below information'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(26792482217726061)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32675913153001530)
,p_name=>'10_FLOW'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(43888066917057020)
,p_prompt=>'Flow'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:AP/AR;AP/AR,GL;GL,Credit Memo;Credit Memo'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(26792776777726061)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32676243710001531)
,p_name=>'LSI_RUN_DATE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(43888066917057020)
,p_prompt=>'LSI Run Date'
,p_display_as=>'NATIVE_DATE_PICKER_JET'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(26792482217726061)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(32559034629749104)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(32558688244749101)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(5444090597114712)
,p_event_id=>wwv_flow_api.id(32559034629749104)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Do you want to submit process?'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(5444105868114713)
,p_event_id=>wwv_flow_api.id(32559034629749104)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'var spinner = apex.util.showSpinner();'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(32559109108749105)
,p_event_id=>wwv_flow_api.id(32559034629749104)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    wsc_lsi_pkg.wsc_ahcs_lsi_reprocess_p(:BATCH_ID,:DATE_SELECTION);',
'-- insert into wsc_tbl_time_t values(to_char(''123123''||''-''||to_char(:BATCH_ID)||''-''||to_char(:DATE_SELECTION)),sysdate,123123);',
'end;'))
,p_attribute_02=>'BATCH_ID,DATE_SELECTION'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(16554415044986806)
,p_event_id=>wwv_flow_api.id(32559034629749104)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(2359005727840945)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(16554559459986807)
,p_event_id=>wwv_flow_api.id(32559034629749104)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'BATCH_ID'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(5444296957114714)
,p_event_id=>wwv_flow_api.id(32559034629749104)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'//remove spinner',
'$("#apex_wait_overlay").remove();',
'$(".u-Processing").remove();'))
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(32559145074749106)
,p_event_id=>wwv_flow_api.id(32559034629749104)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Reprocess Submitted Successfully.'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(32693309753014358)
,p_name=>'New_1'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(32674662029001521)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(5443773015114709)
,p_event_id=>wwv_flow_api.id(32693309753014358)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Do you want to submit process?'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(5443803569114710)
,p_event_id=>wwv_flow_api.id(32693309753014358)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'var spinner = apex.util.showSpinner();'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(32693343376014359)
,p_event_id=>wwv_flow_api.id(32693309753014358)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'WSC_LSI_PKG.wsc_ahcs_lsi_kickoff(:10_FLOW,to_char(to_date(:LSI_RUN_DATE,''mm/dd/yyyy''),''dd-mm-yyyy''),',
'to_char(to_date(sysdate,''mm/dd/yyyy''),''dd-mm-yyyy''));',
'end;'))
,p_attribute_02=>'10_FLOW,LSI_RUN_DATE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(5443982399114711)
,p_event_id=>wwv_flow_api.id(32693309753014358)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'//remove spinner',
'$("#apex_wait_overlay").remove();',
'$(".u-Processing").remove();'))
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(32693453963014360)
,p_event_id=>wwv_flow_api.id(32693309753014358)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Process Submitted Successfully.'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(16203008545450814)
,p_name=>'New_2'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(16202922770450813)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(16203111713450815)
,p_event_id=>wwv_flow_api.id(16203008545450814)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(2359005727840945)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(16554612978986808)
,p_event_id=>wwv_flow_api.id(16203008545450814)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'BATCH_ID'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(5445391535114725)
,p_name=>'New_3'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(5444981562114721)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(5445409702114726)
,p_event_id=>wwv_flow_api.id(5445391535114725)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Do you want to submit process?'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(5445594538114727)
,p_event_id=>wwv_flow_api.id(5445391535114725)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'var spinner = apex.util.showSpinner();'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(5445638135114728)
,p_event_id=>wwv_flow_api.id(5445391535114725)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'-- wsc_lsi_pkg.wsc_ahcs_lsi_reprocess_gl_p(:BATCH_ID_GL,:DATE_SELECTION_GL);',
'wsc_lsi_pkg.WSC_AHCS_ASYNC_LSI_REPROCESS_GL_P(:BATCH_ID_GL,:DATE_SELECTION_GL);',
'end;'))
,p_attribute_02=>'BATCH_ID_GL,DATE_SELECTION_GL'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(5445714758114729)
,p_event_id=>wwv_flow_api.id(5445391535114725)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(2359005727840945)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(5445887091114730)
,p_event_id=>wwv_flow_api.id(5445391535114725)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'BATCH_ID_GL'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1701052144005286
,p_default_application_id=>108
,p_default_id_offset=>16491536708563557
,p_default_owner=>'FININT'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(5446159585114733)
,p_event_id=>wwv_flow_api.id(5445391535114725)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'//remove spinner',
'$("#apex_wait_overlay").remove();',
'$(".u-Processing").remove();'))
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(5445905407114731)
,p_event_id=>wwv_flow_api.id(5445391535114725)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Reprocess Submitted Successfully.'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(5446830165114740)
,p_name=>'New_4'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(5446797303114739)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(5446923472114741)
,p_event_id=>wwv_flow_api.id(5446830165114740)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Do you want to submit process?'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(5447053813114742)
,p_event_id=>wwv_flow_api.id(5446830165114740)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'var spinner = apex.util.showSpinner();'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(5447132260114743)
,p_event_id=>wwv_flow_api.id(5446830165114740)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'wsc_lsi_pkg.wsc_ahcs_lsi_reprocess_cm_p(:BATCH_ID_CM,:DATE_SELECTION_CM);',
'end;'))
,p_attribute_02=>'BATCH_ID_CM,DATE_SELECTION_CM'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(5447234512114744)
,p_event_id=>wwv_flow_api.id(5446830165114740)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(2359005727840945)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(5447342155114745)
,p_event_id=>wwv_flow_api.id(5446830165114740)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'BATCH_ID_CM'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(5447405120114746)
,p_event_id=>wwv_flow_api.id(5446830165114740)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'//remove spinner',
'$("#apex_wait_overlay").remove();',
'$(".u-Processing").remove();'))
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(5447563882114747)
,p_event_id=>wwv_flow_api.id(5446830165114740)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Reprocess Submitted Successfully.'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(16202813571450812)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'username varchar2(200) := APEX_UTIL.GET_SESSION_STATE(''USER_NAME'');',
'begin :P_USER_NAME := username; end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(16202792799450811)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_user_name varchar2(200);',
'v_jwt_token  varchar2(4000);',
'',
'BEGIN',
'',
' /*APEX_CUSTOM_AUTH.SET_USER(''WESCO_USER'');',
' APEX_UTIL.SET_SESSION_STATE(''USER_NAME'',''WESCO_USER'');*/',
'',
'IF  APEX_UTIL.GET_SESSION_STATE(''USER_NAME'') IS NULL THEN',
'   ',
'  xx_apex_user_security_pkg.main(v_jwt_token,v_user_name,null);  ',
'   ',
'    APEX_UTIL.SET_SESSION_STATE(''USER_NAME'',v_user_name);',
'    APEX_UTIL.SET_SESSION_STATE(''JWT_TOKEN'',v_jwt_token);',
'   ',
'    IF APEX_UTIL.GET_SESSION_STATE(''USER_NAME'') IS NULL THEN',
'        APEX_UTIL.REDIRECT_URL(''f?p=&APP_ID.:9999:&APP_SESSION.'');',
'   ELSE',
'        APEX_CUSTOM_AUTH.SET_USER(APEX_UTIL.GET_SESSION_STATE(''USER_NAME''));',
'        ',
'   END IF;',
'   ',
'ELSE',
'   APEX_CUSTOM_AUTH.SET_USER(APEX_UTIL.GET_SESSION_STATE(''USER_NAME''));  ',
'   ',
'END IF; ',
'',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
