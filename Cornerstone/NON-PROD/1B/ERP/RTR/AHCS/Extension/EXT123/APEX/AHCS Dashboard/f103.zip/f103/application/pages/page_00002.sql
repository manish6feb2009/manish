prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1701052144005286
,p_default_application_id=>103
,p_default_id_offset=>2298761677084397
,p_default_owner=>'FININT'
);
wwv_flow_api.create_page(
 p_id=>2
,p_user_interface_id=>wwv_flow_api.id(8554886317286990)
,p_name=>'Welcome to AHCS Dashboard'
,p_alias=>'HOME1'
,p_step_title=>'Welcome to AHCS Dashboard'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_last_updated_by=>'WESCO_UAT_DEVELOPER'
,p_last_upd_yyyymmddhh24miss=>'20220523053320'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8574107930287348)
,p_plug_name=>'Welcome to AHCS Dashboard'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(8465443656286755)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'BELOW'
,p_menu_id=>wwv_flow_api.id(8407793560286616)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(8531945451286926)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2023275071493410)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(8574107930287348)
,p_button_name=>'Dashboard1'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(8530555504286924)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'OIC Dashboard View'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2023370343493411)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(8574107930287348)
,p_button_name=>'Dashboard2'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(8530555504286924)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Subledger Dashboard View'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.component_end;
end;
/
