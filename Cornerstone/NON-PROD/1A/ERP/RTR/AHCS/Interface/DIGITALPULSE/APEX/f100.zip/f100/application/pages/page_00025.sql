prompt --application/pages/page_00025
begin
--   Manifest
--     PAGE: 00025
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1709070790630706
,p_default_application_id=>100
,p_default_id_offset=>14758838573580759
,p_default_owner=>'DGTL_PLS'
);
wwv_flow_api.create_page(
 p_id=>25
,p_user_interface_id=>wwv_flow_api.id(33326459299734847953)
,p_name=>'Reconciliation Report'
,p_step_title=>'Reconciliation Report'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_last_updated_by=>'VPARASHAR@DELOITTE.COM'
,p_last_upd_yyyymmddhh24miss=>'20191104194034'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6288187857437029918)
,p_plug_name=>'Reconciliation Report'
,p_region_name=>'tablercn'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(33326379582771847900)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       INTEGRATION_RUN_ID,',
'ERROR_DESCRIPTION,RECORD_STATUS,ATTRIBUTE1,ATTRIBUTE2,ATTRIBUTE3,ATTRIBUTE4,ATTRIBUTE5,ATTRIBUTE6,ATTRIBUTE7,ATTRIBUTE8,ATTRIBUTE9,ATTRIBUTE10,ATTRIBUTE11,ATTRIBUTE12,ATTRIBUTE13,ATTRIBUTE14,ATTRIBUTE15,ATTRIBUTE16,ATTRIBUTE17,ATTRIBUTE18',
'  from XX_IMD_RECON_REPORT_DATA_T',
'where INTEGRATION_RUN_ID = :P25_RUN_ID'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(6288187989803029918)
,p_name=>'Reconciliation Report'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'VPARASHAR@DELOITTE.COM'
,p_internal_uid=>739500572402088672
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6288188378345029920)
,p_db_column_name=>'ID'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6288188811539029920)
,p_db_column_name=>'INTEGRATION_RUN_ID'
,p_display_order=>30
,p_column_identifier=>'B'
,p_column_label=>'Integration Run Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7432294734798000289)
,p_db_column_name=>'ERROR_DESCRIPTION'
,p_display_order=>40
,p_column_identifier=>'BH'
,p_column_label=>'Error Description'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7432295041965000292)
,p_db_column_name=>'RECORD_STATUS'
,p_display_order=>50
,p_column_identifier=>'BI'
,p_column_label=>'Record Status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7432295176671000293)
,p_db_column_name=>'ATTRIBUTE1'
,p_display_order=>60
,p_column_identifier=>'BJ'
,p_column_label=>'&P25_ATTR_1.'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7432295322397000294)
,p_db_column_name=>'ATTRIBUTE2'
,p_display_order=>70
,p_column_identifier=>'BK'
,p_column_label=>'&P25_ATTR_2.'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7432295332626000295)
,p_db_column_name=>'ATTRIBUTE3'
,p_display_order=>80
,p_column_identifier=>'BL'
,p_column_label=>'&P25_ATTR_3.'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7432295460019000296)
,p_db_column_name=>'ATTRIBUTE4'
,p_display_order=>90
,p_column_identifier=>'BM'
,p_column_label=>'&P25_ATTR_4.'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7432295534679000297)
,p_db_column_name=>'ATTRIBUTE5'
,p_display_order=>100
,p_column_identifier=>'BN'
,p_column_label=>'&P25_ATTR_5.'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7432295686852000298)
,p_db_column_name=>'ATTRIBUTE6'
,p_display_order=>110
,p_column_identifier=>'BO'
,p_column_label=>'&P25_ATTR_6.'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7432295820283000299)
,p_db_column_name=>'ATTRIBUTE7'
,p_display_order=>120
,p_column_identifier=>'BP'
,p_column_label=>'&P25_ATTR_7.'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7432295885438000300)
,p_db_column_name=>'ATTRIBUTE8'
,p_display_order=>130
,p_column_identifier=>'BQ'
,p_column_label=>'&P25_ATTR_8.'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7432295990419000301)
,p_db_column_name=>'ATTRIBUTE9'
,p_display_order=>140
,p_column_identifier=>'BR'
,p_column_label=>'&P25_ATTR_9.'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7432296069289000302)
,p_db_column_name=>'ATTRIBUTE10'
,p_display_order=>150
,p_column_identifier=>'BS'
,p_column_label=>'&P25_ATTR_10.'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7432296132735000303)
,p_db_column_name=>'ATTRIBUTE11'
,p_display_order=>160
,p_column_identifier=>'BT'
,p_column_label=>'&P25_ATTR_11.'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7432296273370000304)
,p_db_column_name=>'ATTRIBUTE12'
,p_display_order=>170
,p_column_identifier=>'BU'
,p_column_label=>'&P25_ATTR_12.'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7432296370572000305)
,p_db_column_name=>'ATTRIBUTE13'
,p_display_order=>180
,p_column_identifier=>'BV'
,p_column_label=>'&P25_ATTR_13.'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7432296500856000306)
,p_db_column_name=>'ATTRIBUTE14'
,p_display_order=>190
,p_column_identifier=>'BW'
,p_column_label=>'&P25_ATTR_14.'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7432296556710000307)
,p_db_column_name=>'ATTRIBUTE15'
,p_display_order=>200
,p_column_identifier=>'BX'
,p_column_label=>'&P25_ATTR_15.'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7432296639671000308)
,p_db_column_name=>'ATTRIBUTE16'
,p_display_order=>210
,p_column_identifier=>'BY'
,p_column_label=>'&P25_ATTR_16.'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7432296822853000309)
,p_db_column_name=>'ATTRIBUTE17'
,p_display_order=>220
,p_column_identifier=>'BZ'
,p_column_label=>'&P25_ATTR_17.'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7432296892163000310)
,p_db_column_name=>'ATTRIBUTE18'
,p_display_order=>230
,p_column_identifier=>'CA'
,p_column_label=>'&P25_ATTR_18.'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(6289993751141062870)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'7413064'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:INTEGRATION_RUN_ID7_DESCRIPTION:ERROR_DESCRIPTION:RECORD_STATUS:ATTRIBUTE1:ATTRIBUTE2:ATTRIBUTE3:ATTRIBUTE4:ATTRIBUTE5:ATTRIBUTE6:ATTRIBUTE7:ATTRIBUTE8:ATTRIBUTE9:ATTRIBUTE10:ATTRIBUTE11:ATTRIBUTE12:ATTRIBUTE13:ATTRIBUTE14:ATTRIBUTE15:ATTRIBUTE16:'
||'ATTRIBUTE17:ATTRIBUTE18'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(42169828756632115159)
,p_plug_name=>'Filter'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(33326355631923847887)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6322437655161022677)
,p_name=>'P25_RUN_ID'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(42169828756632115159)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6322437791574022678)
,p_name=>'P25_ACTIVITY_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(42169828756632115159)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6610108144580687089)
,p_name=>'P25_ATTR_1'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_api.id(42169828756632115159)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ATTRIBUTE1  from XX_IMD_RECON_REPORT_HEADER_T ',
'where INTEGRATION_MASTER_ID = :P25_MASTER_ID'))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6610108279948687090)
,p_name=>'P25_ATTR_2'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_api.id(42169828756632115159)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ATTRIBUTE2  from XX_IMD_RECON_REPORT_HEADER_T ',
'where INTEGRATION_MASTER_ID = :P25_MASTER_ID'))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6610108342345687091)
,p_name=>'P25_ATTR_3'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_api.id(42169828756632115159)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ATTRIBUTE3  from XX_IMD_RECON_REPORT_HEADER_T ',
'where INTEGRATION_MASTER_ID = :P25_MASTER_ID'))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6610108491051687092)
,p_name=>'P25_ATTR_4'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_api.id(42169828756632115159)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ATTRIBUTE4  from XX_IMD_RECON_REPORT_HEADER_T ',
'where INTEGRATION_MASTER_ID = :P25_MASTER_ID'))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6610108567806687093)
,p_name=>'P25_ATTR_5'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_api.id(42169828756632115159)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ATTRIBUTE5  from XX_IMD_RECON_REPORT_HEADER_T ',
'where INTEGRATION_MASTER_ID = :P25_MASTER_ID'))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6610108643478687094)
,p_name=>'P25_ATTR_6'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_api.id(42169828756632115159)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ATTRIBUTE6  from XX_IMD_RECON_REPORT_HEADER_T ',
'where INTEGRATION_MASTER_ID = :P25_MASTER_ID'))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6610108770819687095)
,p_name=>'P25_ATTR_7'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(42169828756632115159)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ATTRIBUTE7  from XX_IMD_RECON_REPORT_HEADER_T ',
'where INTEGRATION_MASTER_ID = :P25_MASTER_ID'))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6610108909619687096)
,p_name=>'P25_ATTR_8'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(42169828756632115159)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ATTRIBUTE8  from XX_IMD_RECON_REPORT_HEADER_T ',
'where INTEGRATION_MASTER_ID = :P25_MASTER_ID'))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6610109011267687097)
,p_name=>'P25_ATTR_9'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(42169828756632115159)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ATTRIBUTE9  from XX_IMD_RECON_REPORT_HEADER_T ',
'where INTEGRATION_MASTER_ID = :P25_MASTER_ID'))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6610109046148687098)
,p_name=>'P25_ATTR_10'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(42169828756632115159)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ATTRIBUTE10  from XX_IMD_RECON_REPORT_HEADER_T ',
'where INTEGRATION_MASTER_ID = :P25_MASTER_ID'))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6610109217198687099)
,p_name=>'P25_ATTR_11'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(42169828756632115159)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ATTRIBUTE11  from XX_IMD_RECON_REPORT_HEADER_T ',
'where INTEGRATION_MASTER_ID = :P25_MASTER_ID'))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6610109327456687100)
,p_name=>'P25_ATTR_12'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(42169828756632115159)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ATTRIBUTE12  from XX_IMD_RECON_REPORT_HEADER_T ',
'where INTEGRATION_MASTER_ID = :P25_MASTER_ID'))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6610109383971687101)
,p_name=>'P25_ATTR_13'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(42169828756632115159)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ATTRIBUTE13  from XX_IMD_RECON_REPORT_HEADER_T ',
'where INTEGRATION_MASTER_ID = :P25_MASTER_ID'))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6610109524990687102)
,p_name=>'P25_ATTR_14'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(42169828756632115159)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ATTRIBUTE14  from XX_IMD_RECON_REPORT_HEADER_T ',
'where INTEGRATION_MASTER_ID = :P25_MASTER_ID'))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6610109600505687103)
,p_name=>'P25_ATTR_15'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(42169828756632115159)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ATTRIBUTE15  from XX_IMD_RECON_REPORT_HEADER_T ',
'where INTEGRATION_MASTER_ID = :P25_MASTER_ID'))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6610109656259687104)
,p_name=>'P25_ATTR_16'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(42169828756632115159)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ATTRIBUTE16  from XX_IMD_RECON_REPORT_HEADER_T ',
'where INTEGRATION_MASTER_ID = :P25_MASTER_ID'))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6610109748347687105)
,p_name=>'P25_ATTR_17'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(42169828756632115159)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ATTRIBUTE17  from XX_IMD_RECON_REPORT_HEADER_T ',
'where INTEGRATION_MASTER_ID = :P25_MASTER_ID'))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6610109909536687106)
,p_name=>'P25_ATTR_18'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(42169828756632115159)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ATTRIBUTE18  from XX_IMD_RECON_REPORT_HEADER_T ',
'where INTEGRATION_MASTER_ID = :P25_MASTER_ID'))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40884762200798988612)
,p_name=>'P25_MASTER_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(42169828756632115159)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(42169828860214115160)
,p_name=>'P25_REQUEST_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(42169828756632115159)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(6610110022306687107)
,p_name=>'New'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(6610110646342687114)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'',
'XX_APEX_GET_RECON_REPORT_PKG.get_recon_report(:P25_RUN_ID,:P25_ACTIVITY_ID,:P25_MASTER_ID,:P25_REQUEST_ID);',
'',
'/*XX_APEX_GET_RECON_REPORT_PKG.get_recon_report(1,1,141,93566);*/',
'',
'end ;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
