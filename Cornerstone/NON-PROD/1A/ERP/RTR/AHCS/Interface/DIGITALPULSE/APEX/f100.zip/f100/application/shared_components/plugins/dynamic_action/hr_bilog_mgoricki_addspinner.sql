prompt --application/shared_components/plugins/dynamic_action/hr_bilog_mgoricki_addspinner
begin
--   Manifest
--     PLUGIN: HR.BILOG.MGORICKI.ADDSPINNER
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1709070790630706
,p_default_application_id=>100
,p_default_id_offset=>14758838573580759
,p_default_owner=>'DGTL_PLS'
);
wwv_flow_api.create_plugin(
 p_id=>wwv_flow_api.id(6806221753469398502)
,p_plugin_type=>'DYNAMIC ACTION'
,p_name=>'HR.BILOG.MGORICKI.ADDSPINNER'
,p_display_name=>'Add Spinner'
,p_category=>'INIT'
,p_supported_ui_types=>'DESKTOP'
,p_image_prefix => nvl(wwv_flow_application_install.get_static_plugin_file_prefix('DYNAMIC ACTION','HR.BILOG.MGORICKI.ADDSPINNER'),'')
,p_plsql_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-------------------------------------------------------------------------',
'-- Author  : Marko Goricki',
'-- Mail    : mgoricki8@gmail.com',
'-- Blog    : http://apexbyg.blogspot.com/',
'-- Company : http://bilog.hr/',
'-- Created : 25.05.2015 6:36:02 PM',
'-- Purpose : Render function for APEX plugin that adds spinner to classic report regions',
'-- Version : v.1.0.0 ',
'FUNCTION f_Add_Spinner (p_dynamic_action IN apex_plugin.t_dynamic_action',
'                      , p_plugin         IN apex_plugin.t_plugin )',
'  RETURN apex_plugin.t_dynamic_action_render_result',
'IS',
'  v_return      apex_plugin.t_dynamic_action_render_result;',
'  v_onload_code varchar2(2000); ',
'BEGIN',
'  v_return.javascript_function := ''function(){null}'';  ',
'      ',
'  -- add onLoadCode',
'  v_onload_code := ''apex.jQuery("''||p_dynamic_action.attribute_01||''").addSpinner();'';',
'    ',
'  apex_javascript.add_library(''hr.bilog.mgoricki.addspinner''',
'                            , p_check_to_add_minified => TRUE',
'                            , p_directory => p_plugin.file_prefix);',
'                            ',
'  apex_javascript.add_onload_code(p_code => v_onload_code);                            ',
'  RETURN v_return;',
'END f_Add_Spinner;',
''))
,p_api_version=>1
,p_render_function=>'f_Add_Spinner'
,p_substitute_attributes=>true
,p_subscribe_plugin_settings=>true
,p_help_text=>'Plugin that adds spinner to classic report regions. You can apply it globaly on page 0 (by using some CSS clase, e.g. .t-Region) or on each page for specific region.'
,p_version_identifier=>'1.0.0'
,p_about_url=>'https://apex.oracle.com/pls/apex/f?p=apexbyg:addspinner'
,p_plugin_comment=>'Release date: 26.05.2015'
,p_files_version=>6
);
wwv_flow_api.create_plugin_attribute(
 p_id=>wwv_flow_api.id(6806222719382434611)
,p_plugin_id=>wwv_flow_api.id(6806221753469398502)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>1
,p_display_sequence=>10
,p_prompt=>'Spinner jQuery Selector'
,p_attribute_type=>'TEXT'
,p_is_required=>true
,p_default_value=>'.t-Region'
,p_is_translatable=>false
,p_help_text=>'Spinner jQuery selector defines region Static ID or CSS class that spinner will be attached to, e.g. .t-Region'
,p_attribute_comment=>'.t-Region - CSS class of Universal Theme Standard Region'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1709070790630706
,p_default_application_id=>100
,p_default_id_offset=>14758838573580759
,p_default_owner=>'DGTL_PLS'
);
wwv_flow_api.g_varchar2_table := wwv_flow_api.empty_varchar2_table;
wwv_flow_api.g_varchar2_table(1) := '2F2A0D0A2A2A204E616D65202020203A204F7261636C65204150455820416464205370696E6E657220506C7567696E0D0A2A2A20417574686F7220203A204D61726B6F20476F7269636B690D0A2A2A204D61696C202020203A206D676F7269636B693840';
wwv_flow_api.g_varchar2_table(2) := '676D61696C2E636F6D0D0A2A2A20426C6F67202020203A20687474703A2F2F617065786279672E626C6F6773706F742E636F6D2F0D0A2A2A20436F6D70616E79203A20687474703A2F2F62696C6F672E68722F0D0A2A2A2043726561746564203A203235';
wwv_flow_api.g_varchar2_table(3) := '2E30352E3230313520363A33363A303220504D0D0A2A2A20507572706F7365203A2052656E6465722066756E6374696F6E20666F72204150455820706C7567696E20746861742061646473207370696E6E657220746F20636C6173736963207265706F72';
wwv_flow_api.g_varchar2_table(4) := '7420726567696F6E730D0A2A2A2056657273696F6E203A20762E312E302E30200D0A2A2A20415045582056657273696F6E3A20352E302E302E30302E333120200D0A2A2F0D0A242866756E6374696F6E2829207B0D0A2020242E77696467657428202263';
wwv_flow_api.g_varchar2_table(5) := '7573746F6D2E6164645370696E6E6572222C207B0D0A202020205F6372656174653A2066756E6374696F6E2829207B0D0A20202020202076617220246F203D20746869732E656C656D656E743B202F2F207265706F72740D0A2020202020207661722024';
wwv_flow_api.g_varchar2_table(6) := '615370696E6E6572203D205B5D3B202F2F207370696E6E65720D0A20202020202076617220765370696E6E65723B0D0A2020202020200D0A2020202020202F2F206265666F726520726566726573680D0A202020202020246F2E6F6E2827617065786265';
wwv_flow_api.g_varchar2_table(7) := '666F726572656672657368272C2066756E6374696F6E28297B0D0A2020202020202020617065782E64656275672E6C6F67282741504558206164645370696E6E6572272C202741504558204265666F7265205265667265736820537461727427293B0D0A';
wwv_flow_api.g_varchar2_table(8) := '202020202020202076617220764964203D20242874686973292E617474722827696427293B0D0A202020202020202076617220765370696E6E65724578697473203D2066616C73653B0D0A2020202020202020242E656163682824615370696E6E65722C';
wwv_flow_api.g_varchar2_table(9) := '2066756E6374696F6E28692C206F626A297B20200D0A202020202020202020206966286F626A5B315D3D3D764964297B0D0A202020202020202020202020765370696E6E65724578697473203D20747275653B0D0A202020202020202020207D0D0A2020';
wwv_flow_api.g_varchar2_table(10) := '2020202020207D293B0D0A20202020202020202F2F20696620646F65736E27742065786973747320616464207370696E6E65720D0A202020202020202069662821765370696E6E65724578697473297B202020202020202020200D0A2020202020202020';
wwv_flow_api.g_varchar2_table(11) := '2020765370696E6E6572203D20617065782E7574696C2E73686F775370696E6E657228246F293B202020202020202020200D0A20202020202020207D0D0A202020202020202024615370696E6E65722E70757368285B765370696E6E65722C7649645D29';
wwv_flow_api.g_varchar2_table(12) := '3B20202020202020200D0A2020202020207D293B0D0A2020202020200D0A2020202020202F2F20616674657220726566726573680D0A202020202020246F2E6F6E282761706578616674657272656672657368272C2066756E6374696F6E28297B0D0A20';
wwv_flow_api.g_varchar2_table(13) := '20202020202020617065782E64656275672E6C6F67282741504558206164645370696E6E6572272C202741504558204166746572205265667265736820537461727427293B0D0A202020202020202076617220764964203D20242874686973292E617474';
wwv_flow_api.g_varchar2_table(14) := '722827696427293B0D0A2020202020202020242E656163682824615370696E6E65722C2066756E6374696F6E28692C206F626A297B0D0A202020202020202020206966286F626A297B0D0A2020202020202020202020206966286F626A5B315D3D3D7649';
wwv_flow_api.g_varchar2_table(15) := '64297B0D0A202020202020202020202020202024615370696E6E65722E73706C69636528692C31293B0D0A202020202020202020202020202069662824615370696E6E65722E6C656E6774683D3D3D30297B0D0A20202020202020202020202020202020';
wwv_flow_api.g_varchar2_table(16) := '6F626A5B305D2E72656D6F766528293B20202020200D0A20202020202020202020202020207D0D0A202020202020202020202020202072657475726E3B202020200D0A2020202020202020202020207D0D0A202020202020202020207D0D0A2020202020';
wwv_flow_api.g_varchar2_table(17) := '2020207D293B20202020202020200D0A2020202020207D293B0D0A202020207D0D0A20207D293B20200D0A7D293B';
null;
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1709070790630706
,p_default_application_id=>100
,p_default_id_offset=>14758838573580759
,p_default_owner=>'DGTL_PLS'
);
wwv_flow_api.create_plugin_file(
 p_id=>wwv_flow_api.id(6808052413672570193)
,p_plugin_id=>wwv_flow_api.id(6806221753469398502)
,p_file_name=>'hr.bilog.mgoricki.addspinner.js'
,p_mime_type=>'application/javascript'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_api.varchar2_to_blob(wwv_flow_api.g_varchar2_table)
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1709070790630706
,p_default_application_id=>100
,p_default_id_offset=>14758838573580759
,p_default_owner=>'DGTL_PLS'
);
wwv_flow_api.g_varchar2_table := wwv_flow_api.empty_varchar2_table;
wwv_flow_api.g_varchar2_table(1) := '242866756E6374696F6E28297B242E7769646765742822637573746F6D2E6164645370696E6E6572222C7B5F6372656174653A66756E6374696F6E28297B76617220652C743D746869732E656C656D656E742C6E3D5B5D3B742E6F6E2822617065786265';
wwv_flow_api.g_varchar2_table(2) := '666F726572656672657368222C66756E6374696F6E28297B617065782E64656275672E6C6F67282241504558206164645370696E6E6572222C2241504558204265666F7265205265667265736820537461727422293B76617220723D242874686973292E';
wwv_flow_api.g_varchar2_table(3) := '617474722822696422292C693D21313B242E65616368286E2C66756E6374696F6E28652C74297B745B315D3D3D72262628693D2130297D292C697C7C28653D617065782E7574696C2E73686F775370696E6E6572287429292C6E2E70757368285B652C72';
wwv_flow_api.g_varchar2_table(4) := '5D297D292C742E6F6E282261706578616674657272656672657368222C66756E6374696F6E28297B617065782E64656275672E6C6F67282241504558206164645370696E6E6572222C224150455820416674657220526566726573682053746172742229';
wwv_flow_api.g_varchar2_table(5) := '3B76617220653D242874686973292E617474722822696422293B242E65616368286E2C66756E6374696F6E28742C72297B72657475726E20722626725B315D3D3D653F286E2E73706C69636528742C31292C766F696428303D3D3D6E2E6C656E67746826';
wwv_flow_api.g_varchar2_table(6) := '26725B305D2E72656D6F7665282929293A766F696420307D297D297D7D297D293B';
null;
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1709070790630706
,p_default_application_id=>100
,p_default_id_offset=>14758838573580759
,p_default_owner=>'DGTL_PLS'
);
wwv_flow_api.create_plugin_file(
 p_id=>wwv_flow_api.id(6808052850738570892)
,p_plugin_id=>wwv_flow_api.id(6806221753469398502)
,p_file_name=>'hr.bilog.mgoricki.addspinner.min.js'
,p_mime_type=>'application/javascript'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_api.varchar2_to_blob(wwv_flow_api.g_varchar2_table)
);
wwv_flow_api.component_end;
end;
/
