prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1709070790630706
,p_default_application_id=>100
,p_default_id_offset=>14758838573580759
,p_default_owner=>'DGTL_PLS'
);
wwv_flow_api.create_page(
 p_id=>2
,p_user_interface_id=>wwv_flow_api.id(33326459299734847953)
,p_name=>'Dashboard'
,p_step_title=>'Dashboard'
,p_autocomplete_on_off=>'OFF'
,p_css_file_urls=>'#WORKSPACE_IMAGES#Digital-Pulse.css'
,p_step_template=>wwv_flow_api.id(33326347800135847881)
,p_page_is_public_y_n=>'Y'
,p_last_updated_by=>'WESCO_DP_SIT1_DEVELOPER'
,p_last_upd_yyyymmddhh24miss=>'20220216070000'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(15221010433119422)
,p_name=>'List of Integrations'
,p_template=>wwv_flow_api.id(33326355421291847887)
,p_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:u-colors:t-BadgeList--large:t-BadgeList--dash:t-BadgeList--fixed:t-Report--hideNoPagination'
,p_grid_column_span=>4
,p_display_column=>5
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'(select COUNT(1)  from XX_IMD_INTEGRATION_RUN_T p, XX_IMD_TRACKS_T tr,XX_IMD_INTEGRATION_MASTER_T xmt',
'  WHERE  tr.track_code = xmt.track AND xmt.id=p.INTEGRATION_MASTER_ID ',
'  AND (extract(hour from systimestamp - cast (p.START_TIME as timestamp)) + 24 * ',
'	  extract(day from systimestamp - cast (p.START_TIME as timestamp ))) <= NVL(:P2_DURATION,100000000)',
'	  AND EXISTS',
'	    (SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_MODULES_T XXM,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXMT.MODULE_CODE = XXM.MODULE_CODE',
'  AND XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXM.MODULE_CODE) = XXM.MODULE_CODE',
'  AND xmt.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME''))) ',
'UNION',
'SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXMT.INTEGRATION_CODE) = XXMT.INTEGRATION_CODE',
'  AND xmt.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME'')))',
')',
'	  )  "Total",',
'NVL((select ',
'       COUNT(p.ID)',
'  FROM XX_IMD_INTEGRATION_RUN_T p, XX_IMD_TRACKS_T tr,XX_IMD_INTEGRATION_MASTER_T xmt',
'  WHERE  tr.track_code = xmt.track AND xmt.id=p.INTEGRATION_MASTER_ID',
'  AND (extract(hour from systimestamp - cast (p.START_TIME as timestamp)) + 24 * ',
'	  extract(day from systimestamp - cast (p.START_TIME as timestamp ))) <= NVL(:P2_DURATION,100000000)',
'  AND tr.TRACK_NAME = ''Procure to Pay''',
'   AND EXISTS',
'	    (SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_MODULES_T XXM,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXMT.MODULE_CODE = XXM.MODULE_CODE',
'  AND XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXM.MODULE_CODE) = XXM.MODULE_CODE',
'  AND xmt.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME''))) ',
'UNION',
'SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXMT.INTEGRATION_CODE) = XXMT.INTEGRATION_CODE',
'  AND xmt.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME'')))',
')',
'  GROUP BY tr.TRACK_NAME,xmt.track),0) "Procure to Pay",',
'        NVL((select ',
'       COUNT(p.ID) ',
'  FROM XX_IMD_INTEGRATION_RUN_T p, XX_IMD_TRACKS_T tr,XX_IMD_INTEGRATION_MASTER_T xmt',
'  WHERE  tr.track_code = xmt.track AND xmt.id=p.INTEGRATION_MASTER_ID',
'  AND (extract(hour from systimestamp - cast (p.START_TIME as timestamp)) + 24 * ',
'	  extract(day from systimestamp - cast (p.START_TIME as timestamp ))) <= NVL(:P2_DURATION,100000000)',
'  AND tr.TRACK_NAME = ''Invoice to Cash''',
'   AND EXISTS',
'	    (SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_MODULES_T XXM,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXMT.MODULE_CODE = XXM.MODULE_CODE',
'  AND XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXM.MODULE_CODE) = XXM.MODULE_CODE',
'  AND xmt.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME''))) ',
'UNION',
'SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXMT.INTEGRATION_CODE) = XXMT.INTEGRATION_CODE',
'  AND xmt.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME'')))',
')',
'  GROUP BY tr.TRACK_NAME,xmt.track) ,0)',
'    "Order to Cash",',
'  NVL(( select ',
'       COUNT(p.ID) ',
'  FROM XX_IMD_INTEGRATION_RUN_T p, XX_IMD_TRACKS_T tr,XX_IMD_INTEGRATION_MASTER_T xmt',
'  WHERE  tr.track_code = xmt.track AND xmt.id=p.INTEGRATION_MASTER_ID',
'  AND (extract(hour from systimestamp - cast (p.START_TIME as timestamp)) + 24 * ',
'	  extract(day from systimestamp - cast (p.START_TIME as timestamp ))) <= NVL(:P2_DURATION,100000000)',
'  AND tr.TRACK_NAME = ''Record to Report''',
'   AND EXISTS',
'	    (SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_MODULES_T XXM,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXMT.MODULE_CODE = XXM.MODULE_CODE',
'  AND XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXM.MODULE_CODE) = XXM.MODULE_CODE',
'  AND xmt.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME''))) ',
'UNION',
'SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXMT.INTEGRATION_CODE) = XXMT.INTEGRATION_CODE',
'  AND xmt.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME'')))',
')',
'  GROUP BY tr.TRACK_NAME,xmt.track) ,0)',
'    "Record to Report", ',
'    NVL((SELECT ',
'       COUNT(p.ID) ',
'  FROM XX_IMD_INTEGRATION_RUN_T p, XX_IMD_TRACKS_T tr,XX_IMD_INTEGRATION_MASTER_T xmt',
'  WHERE  tr.track_code = xmt.track AND xmt.id=p.INTEGRATION_MASTER_ID',
'  AND (extract(hour from systimestamp - cast (p.START_TIME as timestamp)) + 24 * ',
'	  extract(day from systimestamp - cast (p.START_TIME as timestamp ))) <= NVL(:P2_DURATION,100000000)',
'  AND tr.TRACK_NAME = ''Common Tech Integrations''',
'   AND EXISTS',
'	    (SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_MODULES_T XXM,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXMT.MODULE_CODE = XXM.MODULE_CODE',
'  AND XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXM.MODULE_CODE) = XXM.MODULE_CODE',
'  AND xmt.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME''))) ',
'UNION',
'SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXMT.INTEGRATION_CODE) = XXMT.INTEGRATION_CODE',
'  AND xmt.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME'')))',
')',
'  GROUP BY tr.TRACK_NAME,xmt.track),0)',
'    "Forecast to Delivery"',
'',
'FROM DUAL ',
'',
''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(33326392556374847908)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(15222614743119438)
,p_query_column_id=>1
,p_column_alias=>'Total'
,p_column_display_sequence=>1
,p_column_heading=>'Total'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:RP:P4_DURATION:&P2_DURATION.'
,p_column_linktext=>'#Total#'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(15294293462750806)
,p_name=>'List of Integrations'
,p_template=>wwv_flow_api.id(33326355421291847887)
,p_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:u-colors:t-BadgeList--large:t-BadgeList--dash:t-BadgeList--fixed:t-Report--hideNoPagination'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'(select COUNT(1)  from XX_IMD_INTEGRATION_RUN_T p, XX_IMD_TRACKS_T tr,XX_IMD_INTEGRATION_MASTER_T xmt',
'  WHERE  tr.track_code = xmt.track AND xmt.id=p.INTEGRATION_MASTER_ID ',
'  AND (extract(hour from systimestamp - cast (p.START_TIME as timestamp)) + 24 * ',
'	  extract(day from systimestamp - cast (p.START_TIME as timestamp ))) <= NVL(:P2_DURATION,100000000)',
'	  AND EXISTS',
'	    (SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_MODULES_T XXM,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXMT.MODULE_CODE = XXM.MODULE_CODE',
'  AND XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXM.MODULE_CODE) = XXM.MODULE_CODE',
'  AND xmt.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME''))) ',
'UNION',
'SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXMT.INTEGRATION_CODE) = XXMT.INTEGRATION_CODE',
'  AND xmt.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME'')))',
')',
'	  )  "Total",',
'NVL((select ',
'       COUNT(p.ID)',
'  FROM XX_IMD_INTEGRATION_RUN_T p, XX_IMD_TRACKS_T tr,XX_IMD_INTEGRATION_MASTER_T xmt',
'  WHERE  tr.track_code = xmt.track AND xmt.id=p.INTEGRATION_MASTER_ID',
'  AND (extract(hour from systimestamp - cast (p.START_TIME as timestamp)) + 24 * ',
'	  extract(day from systimestamp - cast (p.START_TIME as timestamp ))) <= NVL(:P2_DURATION,100000000)',
'  AND tr.TRACK_NAME = ''Procure to Pay''',
'   AND EXISTS',
'	    (SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_MODULES_T XXM,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXMT.MODULE_CODE = XXM.MODULE_CODE',
'  AND XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXM.MODULE_CODE) = XXM.MODULE_CODE',
'  AND xmt.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME''))) ',
'UNION',
'SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXMT.INTEGRATION_CODE) = XXMT.INTEGRATION_CODE',
'  AND xmt.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME'')))',
')',
'  GROUP BY tr.TRACK_NAME,xmt.track),0) "Procure to Pay",',
'        NVL((select ',
'       COUNT(p.ID) ',
'  FROM XX_IMD_INTEGRATION_RUN_T p, XX_IMD_TRACKS_T tr,XX_IMD_INTEGRATION_MASTER_T xmt',
'  WHERE  tr.track_code = xmt.track AND xmt.id=p.INTEGRATION_MASTER_ID',
'  AND (extract(hour from systimestamp - cast (p.START_TIME as timestamp)) + 24 * ',
'	  extract(day from systimestamp - cast (p.START_TIME as timestamp ))) <= NVL(:P2_DURATION,100000000)',
'  AND tr.TRACK_NAME = ''Invoice to Cash''',
'   AND EXISTS',
'	    (SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_MODULES_T XXM,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXMT.MODULE_CODE = XXM.MODULE_CODE',
'  AND XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXM.MODULE_CODE) = XXM.MODULE_CODE',
'  AND xmt.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME''))) ',
'UNION',
'SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXMT.INTEGRATION_CODE) = XXMT.INTEGRATION_CODE',
'  AND xmt.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME'')))',
')',
'  GROUP BY tr.TRACK_NAME,xmt.track) ,0)',
'    "Order to Cash",',
'  NVL(( select ',
'       COUNT(p.ID) ',
'  FROM XX_IMD_INTEGRATION_RUN_T p, XX_IMD_TRACKS_T tr,XX_IMD_INTEGRATION_MASTER_T xmt',
'  WHERE  tr.track_code = xmt.track AND xmt.id=p.INTEGRATION_MASTER_ID',
'  AND (extract(hour from systimestamp - cast (p.START_TIME as timestamp)) + 24 * ',
'	  extract(day from systimestamp - cast (p.START_TIME as timestamp ))) <= NVL(:P2_DURATION,100000000)',
'  AND tr.TRACK_NAME = ''Record to Report''',
'   AND EXISTS',
'	    (SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_MODULES_T XXM,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXMT.MODULE_CODE = XXM.MODULE_CODE',
'  AND XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXM.MODULE_CODE) = XXM.MODULE_CODE',
'  AND xmt.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME''))) ',
'UNION',
'SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXMT.INTEGRATION_CODE) = XXMT.INTEGRATION_CODE',
'  AND xmt.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME'')))',
')',
'  GROUP BY tr.TRACK_NAME,xmt.track) ,0)',
'    "Record to Report", ',
'    NVL((SELECT ',
'       COUNT(p.ID) ',
'  FROM XX_IMD_INTEGRATION_RUN_T p, XX_IMD_TRACKS_T tr,XX_IMD_INTEGRATION_MASTER_T xmt',
'  WHERE  tr.track_code = xmt.track AND xmt.id=p.INTEGRATION_MASTER_ID',
'  AND (extract(hour from systimestamp - cast (p.START_TIME as timestamp)) + 24 * ',
'	  extract(day from systimestamp - cast (p.START_TIME as timestamp ))) <= NVL(:P2_DURATION,100000000)',
'  AND tr.TRACK_NAME = ''Common Tech Integrations''',
'   AND EXISTS',
'	    (SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_MODULES_T XXM,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXMT.MODULE_CODE = XXM.MODULE_CODE',
'  AND XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXM.MODULE_CODE) = XXM.MODULE_CODE',
'  AND xmt.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME''))) ',
'UNION',
'SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXMT.INTEGRATION_CODE) = XXMT.INTEGRATION_CODE',
'  AND xmt.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME'')))',
')',
'  GROUP BY tr.TRACK_NAME,xmt.track),0)',
'    "Forecast to Delivery"',
'',
'FROM DUAL ',
'',
''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(33326392556374847908)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(15294451803750807)
,p_query_column_id=>1
,p_column_alias=>'Procure to Pay'
,p_column_display_sequence=>1
,p_column_heading=>'Procure to Pay'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:RP:P4_DURATION,P4_MODULE,P4_SOURCE_SYSTEM,P4_TRACK:&P2_DURATION.,,,P2P#DURATION#,,,P2P'
,p_column_linktext=>'#Procure to Pay#'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(15294535221750808)
,p_query_column_id=>2
,p_column_alias=>'Order to Cash'
,p_column_display_sequence=>2
,p_column_heading=>'Invoice to Cash'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:RP:P4_DURATION,P4_MODULE,P4_SOURCE_SYSTEM,P4_TRACK:&P2_DURATION.,,,ITC#DURATION#,,,ITC'
,p_column_linktext=>'#Order to Cash#'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(15294593480750809)
,p_query_column_id=>3
,p_column_alias=>'Record to Report'
,p_column_display_sequence=>3
,p_column_heading=>'Record To Report'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:RP,:P4_DURATION,P4_MODULE,P4_SOURCE_SYSTEM,P4_TRACK:&P2_DURATION.,,,RTR'
,p_column_linktext=>'#Record to Report#'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(15294675078750810)
,p_query_column_id=>4
,p_column_alias=>'Forecast to Delivery'
,p_column_display_sequence=>4
,p_column_heading=>'Common Tech Integrations'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:RP:P4_DURATION,P4_MODULE,P4_SOURCE_SYSTEM,P4_TRACK:&P2_DURATION.,,,TECH'
,p_column_linktext=>'#Forecast to Delivery#'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(15294872381750812)
,p_name=>'List of Integrations'
,p_template=>wwv_flow_api.id(33326355421291847887)
,p_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:u-colors:t-BadgeList--large:t-BadgeList--dash:t-BadgeList--fixed:t-Report--hideNoPagination'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
' NVL((SELECT ',
'       COUNT(p.ID) ',
'  FROM XX_IMD_INTEGRATION_RUN_T p, XX_IMD_TRACKS_T tr,XX_IMD_INTEGRATION_MASTER_T xmt',
'  WHERE  tr.track_code = xmt.track AND xmt.id=p.INTEGRATION_MASTER_ID',
'  AND (extract(hour from systimestamp - cast (p.START_TIME as timestamp)) + 24 * ',
'	  extract(day from systimestamp - cast (p.START_TIME as timestamp ))) <= NVL(:P2_DURATION,100000000)',
'  AND tr.TRACK_NAME = ''Payroll''',
'   AND EXISTS',
'	    (SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_MODULES_T XXM,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXMT.MODULE_CODE = XXM.MODULE_CODE',
'  AND XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXM.MODULE_CODE) = XXM.MODULE_CODE',
'  AND xmt.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME''))) ',
'UNION',
'SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXMT.INTEGRATION_CODE) = XXMT.INTEGRATION_CODE',
'  AND xmt.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME'')))',
')',
'  GROUP BY tr.TRACK_NAME,xmt.track),0)',
'    "Payroll",',
'NVL((SELECT ',
'       COUNT(p.ID) ',
'  FROM XX_IMD_INTEGRATION_RUN_T p, XX_IMD_TRACKS_T tr,XX_IMD_INTEGRATION_MASTER_T xmt',
'  WHERE  tr.track_code = xmt.track AND xmt.id=p.INTEGRATION_MASTER_ID',
'  AND (extract(hour from systimestamp - cast (p.START_TIME as timestamp)) + 24 * ',
'	  extract(day from systimestamp - cast (p.START_TIME as timestamp ))) <= NVL(:P2_DURATION,100000000)',
'  AND tr.TRACK_NAME = ''Benefits''',
'   AND EXISTS',
'	    (SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_MODULES_T XXM,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXMT.MODULE_CODE = XXM.MODULE_CODE',
'  AND XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXM.MODULE_CODE) = XXM.MODULE_CODE',
'  AND xmt.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME''))) ',
'UNION',
'SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXMT.INTEGRATION_CODE) = XXMT.INTEGRATION_CODE',
'  AND xmt.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME'')))',
')',
'  GROUP BY tr.TRACK_NAME,xmt.track),0)',
'    "Benefits",    ',
'NVL((SELECT ',
'       COUNT(p.ID) ',
'  FROM XX_IMD_INTEGRATION_RUN_T p, XX_IMD_TRACKS_T tr,XX_IMD_INTEGRATION_MASTER_T xmt',
'  WHERE  tr.track_code = xmt.track AND xmt.id=p.INTEGRATION_MASTER_ID',
'  AND (extract(hour from systimestamp - cast (p.START_TIME as timestamp)) + 24 * ',
'	  extract(day from systimestamp - cast (p.START_TIME as timestamp ))) <= NVL(:P2_DURATION,100000000)',
'  AND tr.TRACK_NAME = ''Human Capital Management''',
'   AND EXISTS',
'	    (SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_MODULES_T XXM,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXMT.MODULE_CODE = XXM.MODULE_CODE',
'  AND XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXM.MODULE_CODE) = XXM.MODULE_CODE',
'  AND xmt.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME''))) ',
'UNION',
'SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXMT.INTEGRATION_CODE) = XXMT.INTEGRATION_CODE',
'  AND xmt.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME'')))',
')',
'  GROUP BY tr.TRACK_NAME,xmt.track),0)',
'    "Human Resources",',
'NVL((SELECT ',
'       COUNT(p.ID) ',
'  FROM XX_IMD_INTEGRATION_RUN_T p, XX_IMD_TRACKS_T tr,XX_IMD_INTEGRATION_MASTER_T xmt',
'  WHERE  tr.track_code = xmt.track AND xmt.id=p.INTEGRATION_MASTER_ID',
'  AND (extract(hour from systimestamp - cast (p.START_TIME as timestamp)) + 24 * ',
'	  extract(day from systimestamp - cast (p.START_TIME as timestamp ))) <= NVL(:P2_DURATION,100000000)',
'  AND tr.TRACK_NAME = ''Sales Commission''',
'   AND EXISTS',
'	    (SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_MODULES_T XXM,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXMT.MODULE_CODE = XXM.MODULE_CODE',
'  AND XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXM.MODULE_CODE) = XXM.MODULE_CODE',
'  AND xmt.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME''))) ',
'UNION',
'SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXMT.INTEGRATION_CODE) = XXMT.INTEGRATION_CODE',
'  AND xmt.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME'')))',
')',
'  GROUP BY tr.TRACK_NAME,xmt.track),0)',
'    "Sales Commission"',
'FROM DUAL '))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(33326392556374847908)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(15295512467750818)
,p_query_column_id=>1
,p_column_alias=>'Payroll'
,p_column_display_sequence=>1
,p_column_heading=>'Payroll'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:RP:P4_DURATION,P4_TRACK:&P2_DURATION.,PAY'
,p_column_linktext=>'#Payroll#'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(15295601580750819)
,p_query_column_id=>2
,p_column_alias=>'Benefits'
,p_column_display_sequence=>2
,p_column_heading=>'Benefits'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:RP:P4_DURATION,P4_TRACK:&P2_DURATION.,BEN'
,p_column_linktext=>'#Benefits#'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(15295721625750820)
,p_query_column_id=>3
,p_column_alias=>'Human Resources'
,p_column_display_sequence=>3
,p_column_heading=>'Human Resources'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:RP,:P4_DURATION,P4_TRACK:&P2_DURATION.,HCM'
,p_column_linktext=>'#Human Resources#'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(15295835171750821)
,p_query_column_id=>4
,p_column_alias=>'Sales Commission'
,p_column_display_sequence=>4
,p_column_heading=>'Sales Commission'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:RP:P4_DURATION,P4_TRACK:&P2_DURATION.,SC'
,p_column_linktext=>'#Sales Commission#'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5819988426351423149)
,p_plug_name=>'Integration Status - Process Area'
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(33326380712036847901)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*SELECT tr.TRACK_NAME AS label,',
'       COUNT(1) AS VALUE,',
'       INTEGRATION_STATUS AS series ',
'  FROM XX_IMD_INTEGRATION_RUN_T p, XX_IMD_TRACKS_T tr,XX_IMD_INTEGRATION_MASTER_T m',
'  WHERE  tr.track_code = m.track',
'    AND  p.integration_master_id = m.id',
'  GROUP BY tr.TRACK_NAME, INTEGRATION_STATUS',
'order by integration_status */',
'SELECT tr.TRACK_NAME AS label,',
'       COUNT(1) AS VALUE,',
'       INTEGRATION_STATUS AS series ,',
'       case when INTEGRATION_STATUS = ''SUCCESS'' THEN ''GREEN''',
'            WHEN INTEGRATION_STATUS = ''ERROR'' THEN ''RED''',
'			WHEN INTEGRATION_STATUS = ''WARNING'' THEN ''YELLOW''',
'        END COLOR_CHART',
'  FROM XX_IMD_INTEGRATION_RUN_T p, XX_IMD_TRACKS_T tr,XX_IMD_INTEGRATION_MASTER_T m',
'  WHERE  tr.track_code = m.track',
'    AND  p.integration_master_id = m.id',
'	AND (extract(hour from systimestamp - cast (p.START_TIME as timestamp)) + 24 * ',
'	  extract(day from systimestamp - cast (p.START_TIME as timestamp ))) <= NVL(:P2_DURATION,100000000)',
'	AND EXISTS',
'	    (SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_MODULES_T XXM,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXMT.MODULE_CODE = XXM.MODULE_CODE',
'  AND XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXM.MODULE_CODE) = XXM.MODULE_CODE',
'  AND M.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME''))) ',
'UNION',
'SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXMT.INTEGRATION_CODE) = XXMT.INTEGRATION_CODE',
'  AND M.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME'')))',
')',
'  GROUP BY tr.TRACK_NAME, INTEGRATION_STATUS',
'order by integration_status '))
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_jet_chart(
 p_id=>wwv_flow_api.id(5819988549708423150)
,p_region_id=>wwv_flow_api.id(5819988426351423149)
,p_chart_type=>'bar'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'none'
,p_hover_behavior=>'none'
,p_stack=>'on'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(5819988630437423151)
,p_chart_id=>wwv_flow_api.id(5819988549708423150)
,p_seq=>10
,p_name=>'New'
,p_location=>'REGION_SOURCE'
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_color=>'&COLOR_CHART.'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_link_target=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:RP:P17_TRACK,P17_INTEGRATION_STATUS,P17_DURATION,P17_INTEGRATION_MID,P17_TOUCHPOINT_NAME:&LABEL.,&SERIES.,&P2_DURATION.,,'
,p_link_target_type=>'REDIRECT_PAGE'
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(5819988813870423152)
,p_chart_id=>wwv_flow_api.id(5819988549708423150)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(5819988820169423153)
,p_chart_id=>wwv_flow_api.id(5819988549708423150)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1709070790630706
,p_default_application_id=>100
,p_default_id_offset=>14758838573580759
,p_default_owner=>'DGTL_PLS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(34202211873082676460)
,p_plug_name=>'Integration Dashboard'
,p_icon_css_classes=>'app-icon'
,p_region_template_options=>'#DEFAULT#:t-Form--slimPadding'
,p_plug_template=>wwv_flow_api.id(33326373219501847897)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(34202212003532676461)
,p_plug_name=>'Integration Report - Monthly'
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(33326380712036847901)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT to_char(START_TIME,''MON-YY'') AS label, count(1) AS VALUE, INTEGRATION_STATUS AS series ',
'  FROM XX_IMD_INTEGRATION_RUN_T p,XX_IMD_INTEGRATION_MASTER_T M',
' WHERE P.INTEGRATION_MASTER_ID = M.ID',
'   AND EXISTS',
'	    (SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_MODULES_T XXM,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXMT.MODULE_CODE = XXM.MODULE_CODE',
'  AND XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXM.MODULE_CODE) = XXM.MODULE_CODE',
'  AND M.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME''))) ',
'UNION',
'SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXMT.INTEGRATION_CODE) = XXMT.INTEGRATION_CODE',
'  AND M.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME'')))',
')',
'  GROUP BY to_char(START_TIME,''MON-YY''), INTEGRATION_STATUS',
'order by integration_status'))
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_jet_chart(
 p_id=>wwv_flow_api.id(38791722649512722959)
,p_region_id=>wwv_flow_api.id(34202212003532676461)
,p_chart_type=>'bar'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'none'
,p_hover_behavior=>'none'
,p_stack=>'on'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(options){',
'    options.dataFilter=function(data){',
'if(data.series[0]!=undefined){',
'data.series[0].color=''rgb(60, 175, 133)'';',
'}',
'if(data.series[1]!=undefined){',
'',
'        data.series[1].color=''rgb(233, 91, 84)'';',
'}',
'if(data.series[2]!=undefined){',
'data.series[2].color=''rgb(255, 255, 0)'';',
'',
'}',
'        ',
'        ',
'        return data;',
'    };',
'    return options;',
'}'))
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(38791722808632722960)
,p_chart_id=>wwv_flow_api.id(38791722649512722959)
,p_seq=>10
,p_name=>'New'
,p_location=>'REGION_SOURCE'
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_link_target=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:RP:P17_INTEGRATION_STATUS,P17_MONTH:&SERIES.,&LABEL.'
,p_link_target_type=>'REDIRECT_PAGE'
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(38791722915158722961)
,p_chart_id=>wwv_flow_api.id(38791722649512722959)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(38791723016820722962)
,p_chart_id=>wwv_flow_api.id(38791722649512722959)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(42369454006720367352)
,p_plug_name=>'Integration Report - Modules'
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(33326380712036847901)
,p_plug_display_sequence=>90
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_jet_chart(
 p_id=>wwv_flow_api.id(42369454101247367353)
,p_region_id=>wwv_flow_api.id(42369454006720367352)
,p_chart_type=>'pie'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'none'
,p_hover_behavior=>'none'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_value_format_scaling=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(42369454207024367354)
,p_chart_id=>wwv_flow_api.id(42369454101247367353)
,p_seq=>10
,p_name=>'New'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
' SELECT XST.TRACK_NAME LABEL,',
'        COUNT(XRT.INTEGRATION_MASTER_ID) VALUE',
'FROM XX_IMD_INTEGRATION_MASTER_T XMT,',
'XX_IMD_INTEGRATION_RUN_T XRT',
'   , XX_IMD_TRACKS_T XST',
'WHERE XST.TRACK_CODE = XMT.TRACK',
'AND XMT.id = xrt.INTEGRATION_MASTER_ID',
'AND EXISTS',
'	    (SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_MODULES_T XXM,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXMT.MODULE_CODE = XXM.MODULE_CODE',
'  AND XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXM.MODULE_CODE) = XXM.MODULE_CODE',
'  AND XMT.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME''))) ',
'UNION',
'SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXMT.INTEGRATION_CODE) = XXMT.INTEGRATION_CODE',
'  AND XMT.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME'')))',
')',
' GROUP BY XsT.TRACK_name;'))
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(42369454425667367357)
,p_plug_name=>'Integration Report - Systems'
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(33326380712036847901)
,p_plug_display_sequence=>100
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_jet_chart(
 p_id=>wwv_flow_api.id(42369454549221367358)
,p_region_id=>wwv_flow_api.id(42369454425667367357)
,p_chart_type=>'donut'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'none'
,p_hover_behavior=>'none'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_value_format_scaling=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(42369454697681367359)
,p_chart_id=>wwv_flow_api.id(42369454549221367358)
,p_seq=>10
,p_name=>'New'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT XST.SYSTEM_NAME LABEL,',
'        COUNT(XRT.INTEGRATION_MASTER_ID) VALUE',
'FROM XX_IMD_INTEGRATION_RUN_T XRT',
'   , XX_IMD_INTEGRATION_MASTER_T XMT',
'   , XX_IMD_SYSTEM_T XST',
'WHERE XRT.INTEGRATION_MASTER_ID= XMT.ID ',
' AND XST.SYSTEM_CODE = XMT.SOURCE_SYSTEM',
' AND EXISTS',
'	    (SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_MODULES_T XXM,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXMT.MODULE_CODE = XXM.MODULE_CODE',
'  AND XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXM.MODULE_CODE) = XXM.MODULE_CODE',
'  AND XMT.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME''))) ',
'UNION',
'SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXMT.INTEGRATION_CODE) = XXMT.INTEGRATION_CODE',
'  AND XMT.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME'')))',
')',
' GROUP BY XsT.SYSTEM_name;'))
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(42369457674665367389)
,p_plug_name=>'Integration Report - Daily'
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(33326380712036847901)
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  label,count(1) as VALUE,series,ORDER_DATE',
'FROM (SELECT to_char(START_TIME,''DD/MM/YY'') AS label, INTEGRATION_STATUS AS series,to_date(to_char(START_TIME,''DD/MM/YY''),''DD/MM/YY'') ORDER_DATE',
'  FROM XX_IMD_INTEGRATION_RUN_T p,XX_IMD_INTEGRATION_MASTER_T M',
' WHERE P.INTEGRATION_MASTER_ID = M.ID',
'   AND EXISTS',
'	    (SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_MODULES_T XXM,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXMT.MODULE_CODE = XXM.MODULE_CODE',
'  AND XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXM.MODULE_CODE) = XXM.MODULE_CODE',
'  AND M.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME''))) ',
'UNION',
'SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXMT.INTEGRATION_CODE) = XXMT.INTEGRATION_CODE',
'  AND M.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME'')))',
')',
')',
'  GROUP BY label, SERIES,ORDER_DATE',
'  ORDER BY 4,SERIES'))
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_jet_chart(
 p_id=>wwv_flow_api.id(42369457747310367390)
,p_region_id=>wwv_flow_api.id(42369457674665367389)
,p_chart_type=>'bar'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'none'
,p_hover_behavior=>'none'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(options){',
'    options.dataFilter=function(data){',
'if(data.series[0]!=undefined){',
'data.series[0].color=''rgb(60, 175, 133)'';',
'}',
'if(data.series[1]!=undefined){',
'',
'        data.series[1].color=''rgb(233, 91, 84)'';',
'}',
'if(data.series[2]!=undefined){',
'data.series[2].color=''rgb(255, 255, 0)'';',
'',
'}',
'        ',
'        ',
'        return data;',
'    };',
'    return options;',
'}'))
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(42369457848075367391)
,p_chart_id=>wwv_flow_api.id(42369457747310367390)
,p_seq=>10
,p_name=>'New'
,p_location=>'REGION_SOURCE'
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_link_target=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:RP:P17_INTEGRATION_STATUS,P17_DAY:&SERIES.,&LABEL.'
,p_link_target_type=>'REDIRECT_PAGE'
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(42369457981109367392)
,p_chart_id=>wwv_flow_api.id(42369457747310367390)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(42369458058952367393)
,p_chart_id=>wwv_flow_api.id(42369457747310367390)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22812080634830795)
,p_name=>'P2_DURATION'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(34202211873082676460)
,p_prompt=>'<B> Duration </B>'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:Last 1 hr.;1,Last 2 hrs.;2,Last 4 hrs.;4,1 Day;24,1 Week;168,1 Month;720'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Retention Period'
,p_lov_null_value=>'1000000000000000000'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(33326435487753847937)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2082809735627401629)
,p_name=>'PX_MOD1'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(34202211873082676460)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6704335583944725378)
,p_name=>'P2_NEW'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(34202211873082676460)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'/*insert into testnew SELECT owa_util.get_cgi_env(''QUERY_STRING'')',
'     FROM DUAL;*/',
'null;',
'end;'))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(8292535471065144278)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_user_name varchar2(200);',
'v_jwt_token  varchar2(4000);',
'',
'BEGIN',
'',
' /*APEX_CUSTOM_AUTH.SET_USER(''AHSERP'');',
' APEX_UTIL.SET_SESSION_STATE(''USER_NAME'',APEX_CUSTOM_AUTH.GET_USER());*/',
'',
' IF  APEX_UTIL.GET_SESSION_STATE(''USER_NAME'') IS NULL THEN',
'   ',
'  xx_apex_user_security_pkg.main(v_jwt_token,v_user_name,null);  ',
'',
'   ',
'    APEX_UTIL.SET_SESSION_STATE(''USER_NAME'',v_user_name);',
'    APEX_UTIL.SET_SESSION_STATE(''JWT_TOKEN'',v_jwt_token);',
'   ',
'    IF APEX_UTIL.GET_SESSION_STATE(''USER_NAME'') IS NULL THEN',
'        APEX_UTIL.REDIRECT_URL(''f?p=&APP_ID.:9999:&APP_SESSION.'');',
'   ELSE',
'        APEX_CUSTOM_AUTH.SET_USER(APEX_UTIL.GET_SESSION_STATE(''USER_NAME''));',
'   END IF;',
'   ',
'ELSE',
'   APEX_CUSTOM_AUTH.SET_USER(APEX_UTIL.GET_SESSION_STATE(''USER_NAME''));  ',
'   ',
'END IF;',
'',
'',
'',
'',
'',
'',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
