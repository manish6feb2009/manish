prompt --application/shared_components/user_interface/lovs/xx_imd_role_values
begin
--   Manifest
--     XX_IMD_ROLE_VALUES
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1709070790630706
,p_default_application_id=>100
,p_default_id_offset=>14758838573580759
,p_default_owner=>'DGTL_PLS'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(6790978388945525665)
,p_lov_name=>'XX_IMD_ROLE_VALUES'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT TRACK_CODE LEVEL_VALUE,TRACK_NAME LEVEL_DESCRIPTION FROM XX_IMD_TRACKS_T WHERE :P36_ACCESS_LEVEL = ''TRACKS''',
'UNION ALL',
'SELECT MODULE_CODE,MODULE_NAME FROM XX_IMD_MODULES_T WHERE :P36_ACCESS_LEVEL = ''MODULES''',
'UNION ALL',
'SELECT INTEGRATION_CODE,DESCRIPTION FROM XX_IMD_INTEGRATION_MASTER_T WHERE :P36_ACCESS_LEVEL = ''INTEGRATIONS'''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'LEVEL_VALUE'
,p_display_column_name=>'LEVEL_DESCRIPTION'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'LEVEL_DESCRIPTION'
,p_default_sort_direction=>'ASC'
);
wwv_flow_api.component_end;
end;
/
