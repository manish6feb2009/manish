prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1709070790630706
,p_default_application_id=>100
,p_default_id_offset=>14758838573580759
,p_default_owner=>'DGTL_PLS'
);
wwv_flow_api.create_page(
 p_id=>4
,p_user_interface_id=>wwv_flow_api.id(33326459299734847953)
,p_name=>'Integrations'
,p_step_title=>'Integrations'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_last_updated_by=>'WESCO_DP_SIT1_DEVELOPER'
,p_last_upd_yyyymmddhh24miss=>'20220216114644'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6508064881854710087)
,p_plug_name=>'Charts'
,p_region_template_options=>'#DEFAULT#:margin-top-none:margin-bottom-none:margin-left-none:margin-right-none'
,p_plug_template=>wwv_flow_api.id(33326355421291847887)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6322440106843022701)
,p_plug_name=>'Modules - Monthly Job Runs'
,p_parent_plug_id=>wwv_flow_api.id(6508064881854710087)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(33326380712036847901)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT to_char(START_TIME,''MON-YY'') AS label, count(1) AS VALUE, INTEGRATION_STATUS AS series ',
'  FROM XX_IMD_INTEGRATION_RUN_T xrt,XX_IMD_INTEGRATION_MASTER_T xmt',
'  where',
'  XRT.INTEGRATION_MASTER_ID= XMT.ID',
'   and (XMT.MODULE_CODE = :P4_MODULE)',
'  GROUP BY to_char(START_TIME,''MON-YY''), INTEGRATION_STATUS',
'order by integration_status'))
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P4_MODULE'
);
wwv_flow_api.create_jet_chart(
 p_id=>wwv_flow_api.id(6322440200178022702)
,p_region_id=>wwv_flow_api.id(6322440106843022701)
,p_chart_type=>'bar'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'none'
,p_hover_behavior=>'none'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(options){',
'    options.dataFilter=function(data){',
'if(data.series)',
'if(data.series[1]!=undefined){',
'        data.series[1].color=''rgb(48, 159, 219)''; ',
'}',
'if(data.series[2]!=undefined){',
'        data.series[2].color=''rgb(60, 175, 133)'';',
'}',
'if(data.series[0]!=undefined){',
'        data.series[0].color=''rgb(233, 91, 84)'';',
'}',
'        return data;',
'    };',
'    return options;',
'}'))
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(6322440272535022703)
,p_chart_id=>wwv_flow_api.id(6322440200178022702)
,p_seq=>10
,p_name=>'New'
,p_location=>'REGION_SOURCE'
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(6322440529767022705)
,p_chart_id=>wwv_flow_api.id(6322440200178022702)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(6322440332206022704)
,p_chart_id=>wwv_flow_api.id(6322440200178022702)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6322440566612022706)
,p_plug_name=>'Modules - Daily Job Runs'
,p_parent_plug_id=>wwv_flow_api.id(6508064881854710087)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(33326380712036847901)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT to_char(START_TIME,''DD/MM/YY'') AS label, count(1) AS VALUE, INTEGRATION_STATUS AS series ',
'  FROM XX_IMD_INTEGRATION_RUN_T xrt,XX_IMD_INTEGRATION_MASTER_T xmt',
'  where',
'  XRT.INTEGRATION_MASTER_ID= XMT.ID',
'   and (XMT.MODULE_CODE= :P4_MODULE)',
'  GROUP BY to_char(START_TIME,''DD/MM/YY''), INTEGRATION_STATUS',
'  order by integration_status'))
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P4_MODULE'
);
wwv_flow_api.create_jet_chart(
 p_id=>wwv_flow_api.id(6322440649162022707)
,p_region_id=>wwv_flow_api.id(6322440566612022706)
,p_chart_type=>'bar'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'none'
,p_hover_behavior=>'none'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(options){',
'    options.dataFilter=function(data){',
'if(data.series)',
'if(data.series[1]!=undefined){',
'        data.series[1].color=''rgb(48, 159, 219)''; ',
'}',
'if(data.series[2]!=undefined){',
'        data.series[2].color=''rgb(60, 175, 133)'';',
'}',
'if(data.series[0]!=undefined){',
'        data.series[0].color=''rgb(233, 91, 84)'';',
'}',
'        return data;',
'    };',
'    return options;',
'}'))
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(6322440761766022708)
,p_chart_id=>wwv_flow_api.id(6322440649162022707)
,p_seq=>10
,p_name=>'New'
,p_location=>'REGION_SOURCE'
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(6322440873482022709)
,p_chart_id=>wwv_flow_api.id(6322440649162022707)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(6322441009369022710)
,p_chart_id=>wwv_flow_api.id(6322440649162022707)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6508065690454710095)
,p_plug_name=>'System -  Monthly Job Runs'
,p_parent_plug_id=>wwv_flow_api.id(6508064881854710087)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(33326380712036847901)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT to_char(START_TIME,''MON-YY'') AS label, count(1) AS VALUE, INTEGRATION_STATUS AS series ',
'  FROM XX_IMD_INTEGRATION_RUN_T xrt,XX_IMD_INTEGRATION_MASTER_T xmt',
'  where',
'  XRT.INTEGRATION_MASTER_ID= XMT.ID',
'   and (XMT.SOURCE_SYSTEM = :P4_SOURCE_SYSTEM',
'	  OR XMT.TARGET_SYSTEM = :P4_SOURCE_SYSTEM)',
'  GROUP BY to_char(START_TIME,''MON-YY''), INTEGRATION_STATUS',
'order by integration_status'))
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P4_SOURCE_SYSTEM'
);
wwv_flow_api.create_jet_chart(
 p_id=>wwv_flow_api.id(6508065782489710096)
,p_region_id=>wwv_flow_api.id(6508065690454710095)
,p_chart_type=>'bar'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'none'
,p_hover_behavior=>'none'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(options){',
'    options.dataFilter=function(data){',
'if(data.series)',
'if(data.series[1]!=undefined){',
'        data.series[1].color=''rgb(48, 159, 219)''; ',
'}',
'if(data.series[2]!=undefined){',
'        data.series[2].color=''rgb(60, 175, 133)'';',
'}',
'if(data.series[0]!=undefined){',
'        data.series[0].color=''rgb(233, 91, 84)'';',
'}',
'        return data;',
'    };',
'    return options;',
'}'))
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(6508065926085710097)
,p_chart_id=>wwv_flow_api.id(6508065782489710096)
,p_seq=>10
,p_name=>'New'
,p_location=>'REGION_SOURCE'
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(6508065936531710098)
,p_chart_id=>wwv_flow_api.id(6508065782489710096)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(6508066084148710099)
,p_chart_id=>wwv_flow_api.id(6508065782489710096)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6508066198510710100)
,p_plug_name=>'System -  Daily Job Runs'
,p_parent_plug_id=>wwv_flow_api.id(6508064881854710087)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(33326380712036847901)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT to_char(START_TIME,''DD/MM/YY'') AS label, count(1) AS VALUE, INTEGRATION_STATUS AS series ',
'  FROM XX_IMD_INTEGRATION_RUN_T xrt,XX_IMD_INTEGRATION_MASTER_T xmt',
'  where',
'  XRT.INTEGRATION_MASTER_ID= XMT.ID',
'   and (XMT.SOURCE_SYSTEM = :P4_SOURCE_SYSTEM',
'	  OR XMT.TARGET_SYSTEM = :P4_SOURCE_SYSTEM)',
'  GROUP BY to_char(START_TIME,''DD/MM/YY''), INTEGRATION_STATUS',
'  order by integration_status'))
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P4_SOURCE_SYSTEM'
);
wwv_flow_api.create_jet_chart(
 p_id=>wwv_flow_api.id(6508066234621710101)
,p_region_id=>wwv_flow_api.id(6508066198510710100)
,p_chart_type=>'bar'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'none'
,p_hover_behavior=>'none'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(options){',
'    options.dataFilter=function(data){',
'if(data.series)',
'if(data.series[1]!=undefined){',
'        data.series[1].color=''rgb(48, 159, 219)'';',
'}',
'if(data.series[2]!=undefined){',
'        data.series[2].color=''rgb(60, 175, 133)'';',
'}',
'if(data.series[0]!=undefined){',
'        data.series[0].color=''rgb(233, 91, 84)'';',
'}',
'        return data;',
'    };',
'    return options;',
'}'))
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(6508066364536710102)
,p_chart_id=>wwv_flow_api.id(6508066234621710101)
,p_seq=>10
,p_name=>'New'
,p_location=>'REGION_SOURCE'
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(6508066609576710104)
,p_chart_id=>wwv_flow_api.id(6508066234621710101)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(6508066515984710103)
,p_chart_id=>wwv_flow_api.id(6508066234621710101)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(40282861004469007178)
,p_plug_name=>'Integration List'
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(33326380712036847901)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT * FROM ',
'(SELECT  XMT.TRACK',
'       , XMT.DESCRIPTION',
'       , XRT.INTEGRATION_STATUS',
'       , XST.SYSTEM_NAME',
'	   , XMT.INTEGRATION_TYPE',
'	   , XMST.MODULE_NAME',
'	   , XST1.SYSTEM_NAME TARGET_SYSTEM',
'	   , XMT.RICE_CODE',
'           , XMT.ID',
'	   , (select count(INTEGRATION_STATUS) from XX_IMD_INTEGRATION_RUN_T',
'     	   where INTEGRATION_MASTER_ID= XRT.INTEGRATION_MASTER_ID',
'		   AND (extract(hour from systimestamp - cast (START_TIME as timestamp)) + 24 * ',
'		   extract(day from systimestamp - cast (START_TIME as timestamp ))) <= NVL(:P4_DURATION,100000000)',
'		   --AND TRACK = NVL(null,TRACK)',
'		) TOTAL ',
'	   ',
'FROM XX_IMD_INTEGRATION_RUN_T XRT',
'   , XX_IMD_INTEGRATION_MASTER_T XMT',
'   , XX_IMD_SYSTEM_T XST',
'   , XX_IMD_SYSTEM_T XST1',
'   , XX_IMD_MODULES_T XMST',
'WHERE  ',
'      XRT.INTEGRATION_MASTER_ID= XMT.ID ',
' AND XST.SYSTEM_CODE = XMT.SOURCE_SYSTEM',
' AND XMST.MODULE_CODE=XMT.MODULE_CODE',
' AND XST1.SYSTEM_CODE = XMT.TARGET_SYSTEM',
' AND EXISTS',
'	    (SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_MODULES_T XXM,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXMT.MODULE_CODE = XXM.MODULE_CODE',
'  AND XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXM.MODULE_CODE) = XXM.MODULE_CODE',
'  AND XMT.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME''))) ',
'UNION',
'SELECT XXMT.ID INTEGRATION_MASTER_ID',
'FROM XX_IMD_INTEGRATION_MASTER_T XXMT,',
'     XX_IMD_USER_ROLE_DETAILS_T XXURD,',
'     XX_IMD_ROLE_MAPPINGS_T XXRM',
'WHERE XXURD.ROLE = XXRM.ROLE',
'  AND NVL(XXRM.NAME,XXMT.INTEGRATION_CODE) = XXMT.INTEGRATION_CODE',
'  AND XMT.ID = XXMT.ID',
'  AND UPPER(XXURD.USERNAME) = UPPER(NVL(:USER_NAME,APEX_UTIL.GET_SESSION_STATE(''USER_NAME'')))',
')',
' AND (extract(hour from systimestamp - cast (XRT.START_TIME as timestamp)) + 24 * ',
'	  extract(day from systimestamp - cast (XRT.START_TIME as timestamp ))) <= NVL(:P4_DURATION,100000000)',
'      AND XMT.TRACK = NVL(:P4_TRACK,XMT.TRACK)',
'	  AND XMT.MODULE_CODE=NVL(:P4_MODULE,XMT.MODULE_CODE)',
'      AND (XST.SYSTEM_CODE = NVL(:P4_SOURCE_SYSTEM,XST.SYSTEM_CODE)',
'	  OR XST1.SYSTEM_CODE = NVL(:P4_SOURCE_SYSTEM,XST1.SYSTEM_CODE))',
'     )      ',
'PIVOT (',
'  count(INTEGRATION_STATUS) FOR INTEGRATION_STATUS IN (''SUCCESS'' AS SUCCESS, ''ERROR'' AS ERROR, ''WARNING'' AS WARNING)',
')',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(5568328362438422917)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'VPARASHAR@DELOITTE.COM'
,p_internal_uid=>1304709931185608242
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5568328497451422918)
,p_db_column_name=>'TRACK'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Track'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5568328891450422922)
,p_db_column_name=>'MODULE_NAME'
,p_display_order=>20
,p_column_identifier=>'E'
,p_column_label=>'Module Name'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5568329067040422924)
,p_db_column_name=>'RICE_CODE'
,p_display_order=>30
,p_column_identifier=>'G'
,p_column_label=>'Rice Code'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5568328572283422919)
,p_db_column_name=>'DESCRIPTION'
,p_display_order=>50
,p_column_identifier=>'B'
,p_column_label=>'Description'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5568328809190422921)
,p_db_column_name=>'INTEGRATION_TYPE'
,p_display_order=>60
,p_column_identifier=>'D'
,p_column_label=>'Integration Type'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5568328689603422920)
,p_db_column_name=>'SYSTEM_NAME'
,p_display_order=>70
,p_column_identifier=>'C'
,p_column_label=>'Source System'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5568328959331422923)
,p_db_column_name=>'TARGET_SYSTEM'
,p_display_order=>80
,p_column_identifier=>'F'
,p_column_label=>'Target System'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5568329164304422925)
,p_db_column_name=>'ID'
,p_display_order=>90
,p_column_identifier=>'H'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6091180542279361476)
,p_db_column_name=>'TOTAL'
,p_display_order=>100
,p_column_identifier=>'I'
,p_column_label=>'Total'
,p_column_link=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:RP:P17_DURATION,P17_INTEGRATION_MID,P17_INTEGRATION_STATUS,P17_TOUCHPOINT_NAME,P17_TRACK:&P4_DURATION.,#ID#,,,'
,p_column_linktext=>'#TOTAL#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_static_id=>'TOTAL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6091180684552361477)
,p_db_column_name=>'SUCCESS'
,p_display_order=>110
,p_column_identifier=>'J'
,p_column_label=>'Success'
,p_column_link=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:RP:P17_DURATION,P17_INTEGRATION_MID,P17_INTEGRATION_STATUS,P17_TOUCHPOINT_NAME,P17_TRACK:&P4_DURATION.,#ID#,SUCCESS,,'
,p_column_linktext=>'#SUCCESS#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_static_id=>'SUCCESS'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6091180797512361478)
,p_db_column_name=>'ERROR'
,p_display_order=>120
,p_column_identifier=>'K'
,p_column_label=>'Error'
,p_column_link=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:RP:P17_DURATION,P17_INTEGRATION_MID,P17_INTEGRATION_STATUS,P17_TOUCHPOINT_NAME,P17_TRACK:&P4_DURATION.,#ID#,ERROR,,'
,p_column_linktext=>'#ERROR#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_static_id=>'ERROR'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5515855198933503)
,p_db_column_name=>'WARNING'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Warning'
,p_column_link=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.::P17_DURATION,P17_INTEGRATION_MID,P17_INTEGRATION_STATUS,P17_TOUCHPOINT_NAME,P17_TRACK:&P4_DURATION.,#ID#,ERROR,,'
,p_column_linktext=>'#WARNING#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(6091757611928897578)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'18281392'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TRACK:DESCRIPTION:SYSTEM_NAME:INTEGRATION_TYPE:MODULE_NAME:TARGET_SYSTEM:RICE_CODE:ID:TOTAL:SUCCESS:ERROR:WARNING'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6322440018388022700)
,p_name=>'P4_MODULE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(40282861004469007178)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40282861392085007182)
,p_name=>'P4_DURATION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(40282861004469007178)
,p_prompt=>'<b> Duration </b>'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:Last 1 hr.;1,Last 2 hrs.;2,Last 4 hrs.;4,1 Day;24,1 Week;168,1 Month;720'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Retention Period'
,p_lov_null_value=>'1000000000000000000'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(33326435487753847937)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(42072398409090973747)
,p_name=>'P4_TRACK'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(40282861004469007178)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(42072398517372973748)
,p_name=>'P4_SOURCE_SYSTEM'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(40282861004469007178)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(22751872212825524)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'',
'',
'v_name varchar2(200);',
'v_token  varchar2(4000);',
'',
'BEGIN',
'',
'',
'',
'IF APEX_UTIL.GET_SESSION_STATE(''USER_NAME'') IS NULL THEN',
'        APEX_UTIL.REDIRECT_URL(''f?p=&APP_ID.:9999:&APP_SESSION.'');',
'   ELSE',
'        APEX_CUSTOM_AUTH.SET_USER(APEX_UTIL.GET_SESSION_STATE(''USER_NAME''));',
'   END IF;',
'',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
