prompt --application/pages/page_00037
begin
--   Manifest
--     PAGE: 00037
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1709070790630706
,p_default_application_id=>100
,p_default_id_offset=>14758838573580759
,p_default_owner=>'DGTL_PLS'
);
wwv_flow_api.create_page(
 p_id=>37
,p_user_interface_id=>wwv_flow_api.id(33326459299734847953)
,p_name=>'INTEGRATION RUN PAGE COPY'
,p_step_title=>'INTEGRATION RUN PAGE COPY'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_last_updated_by=>'SECURITAS_DP_DEV'
,p_last_upd_yyyymmddhh24miss=>'20200518144708'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(40298726783960761870)
,p_plug_name=>'Integration Run Details'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(33326379582771847900)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT * FROM ',
'(SELECT  XMT.TRACK',
'       , XMT.DESCRIPTION',
'       , XRT.INTEGRATION_STATUS',
'       , XST.SYSTEM_NAME',
'	   , XMT.INTEGRATION_TYPE',
'	   , XMST.MODULE_NAME',
'	   , XST1.SYSTEM_NAME TARGET_SYSTEM',
'	   , XMT.RICE_CODE',
'       , XRT.START_TIME',
'	   , XRT.END_TIME',
'	   , XRT.ID',
'	   ,sys.dbms_lob.getlength("FILE_DATA") "Download"',
'	   ,MIME_TYPE',
'	   ,XRT.INTEGRATION_MASTER_ID ',
'		,XRT.REQUEST_ID    ',
'		,XRT.TICKET_NUMBER     ',
'FROM XX_IMD_INTEGRATION_RUN_T XRT',
'   , XX_IMD_INTEGRATION_MASTER_T XMT',
'   , XX_IMD_SYSTEM_T XST',
'   , XX_IMD_SYSTEM_T XST1',
'   , XX_IMD_MODULES_T XMST',
',XX_IMD_TRACKS_T XTT',
'WHERE  XRT.INTEGRATION_MASTER_ID= XMT.ID ',
' AND XST.SYSTEM_CODE = XMT.SOURCE_SYSTEM',
' AND XMST.MODULE_CODE=XMT.MODULE_CODE',
'AND XTT.TRACK_CODE=XMT.TRACK',
'AND XST1.SYSTEM_CODE = XMT.TARGET_SYSTEM',
'AND (extract(hour from systimestamp - cast (XRT.START_TIME as timestamp)) + 24 * ',
'	  extract(day from systimestamp - cast (XRT.START_TIME as timestamp ))) <= NVL(:P17_DURATION,100000000)',
'AND XTT.TRACK_NAME= NVL(:P17_TRACK,XTT.TRACK_NAME)',
'AND XMT.ID=NVL(:P17_INTEGRATION_MID,XMT.ID)',
'AND INTEGRATION_STATUS=NVL(:P17_INTEGRATION_STATUS,INTEGRATION_STATUS)',
'AND TO_CHAR(XRT.START_TIME,''MON-YY'') = NVL(:P17_MONTH,TO_CHAR(XRT.START_TIME,''MON-YY''))',
'AND TO_CHAR(XRT.START_TIME,''DD/MM/YY'') = NVL(:P17_DAY,TO_CHAR(XRT.START_TIME,''DD/MM/YY''))',
' ) order by start_time desc'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(6093761940605641583)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'VPARASHAR@DELOITTE.COM'
,p_internal_uid=>6072950722711697861
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(23486253642367356)
,p_db_column_name=>'TRACK'
,p_display_order=>10
,p_column_identifier=>'DB'
,p_column_label=>'Track'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(23486354317367357)
,p_db_column_name=>'DESCRIPTION'
,p_display_order=>20
,p_column_identifier=>'DC'
,p_column_label=>'Description'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(23486481170367358)
,p_db_column_name=>'INTEGRATION_STATUS'
,p_display_order=>30
,p_column_identifier=>'DD'
,p_column_label=>'Integration Status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(23486551947367359)
,p_db_column_name=>'SYSTEM_NAME'
,p_display_order=>40
,p_column_identifier=>'DE'
,p_column_label=>'System Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(23486692718367360)
,p_db_column_name=>'INTEGRATION_TYPE'
,p_display_order=>50
,p_column_identifier=>'DF'
,p_column_label=>'Integration Type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(23486782187367361)
,p_db_column_name=>'MODULE_NAME'
,p_display_order=>60
,p_column_identifier=>'DG'
,p_column_label=>'Module Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(23486828344367362)
,p_db_column_name=>'TARGET_SYSTEM'
,p_display_order=>70
,p_column_identifier=>'DH'
,p_column_label=>'Target System'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(23487001336367363)
,p_db_column_name=>'RICE_CODE'
,p_display_order=>80
,p_column_identifier=>'DI'
,p_column_label=>'Rice Code'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(23487067865367364)
,p_db_column_name=>'START_TIME'
,p_display_order=>90
,p_column_identifier=>'DJ'
,p_column_label=>'Start Time'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(23487150733367365)
,p_db_column_name=>'END_TIME'
,p_display_order=>100
,p_column_identifier=>'DK'
,p_column_label=>'End Time'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(23487309610367366)
,p_db_column_name=>'ID'
,p_display_order=>110
,p_column_identifier=>'DL'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(23487397122367367)
,p_db_column_name=>'Download'
,p_display_order=>120
,p_column_identifier=>'DM'
,p_column_label=>'Download'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'DOWNLOAD:XX_IMD_INTEGRATION_RUN_T:FILE_DATA:ID::MIME_TYPE::::attachment::'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(23487438810367368)
,p_db_column_name=>'MIME_TYPE'
,p_display_order=>130
,p_column_identifier=>'DN'
,p_column_label=>'Mime Type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(23487613706367369)
,p_db_column_name=>'INTEGRATION_MASTER_ID'
,p_display_order=>140
,p_column_identifier=>'DO'
,p_column_label=>'Integration Master Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(23487686220367370)
,p_db_column_name=>'REQUEST_ID'
,p_display_order=>150
,p_column_identifier=>'DP'
,p_column_label=>'Request Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(23487742137367371)
,p_db_column_name=>'TICKET_NUMBER'
,p_display_order=>160
,p_column_identifier=>'DQ'
,p_column_label=>'Ticket Number'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(6111495724269041695)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_type=>'REPORT'
,p_report_alias=>'25879'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'INTEGRATION_INTEGRATION_RUN_INTEGRATION_MASTER_REQUEST_REQUEST_REQUEST_RECON_RUN_1:TRACK:DESCRIPTION:INTEGRATION_STATUS:SYSTEM_NAME:INTEGRATION_TYPE:MODULE_NAME:TARGET_SYSTEM:RICE_CODE:START_TIME:END_TIME:ID:Download:MIME_TYPE:INTEGRATION_MASTER_ID:R'
||'EQUEST_ID:TICKET_NUMBER'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(40903617607656868653)
,p_plug_name=>'Filter'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(33326355631923847887)
,p_plug_display_sequence=>5
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(23399824233223830)
,p_name=>'P37_DURATION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(40903617607656868653)
,p_prompt=>'<B> Duration </B>'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:Last 1 hr.;1,Last 2 hrs.;2,Last 4 hrs.;4,1 Day;24,1 Week;168,1 Month;720'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Retention Period'
,p_lov_null_value=>'1000000000000000000'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(33326435487753847937)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(23400315091223833)
,p_name=>'P37_TRACK'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(40903617607656868653)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(23400716292223834)
,p_name=>'P37_INTEGRATION_STATUS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(40903617607656868653)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(23401070437223835)
,p_name=>'P37_TOUCHPOINT_NAME'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(40903617607656868653)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(23401426652223836)
,p_name=>'P37_INTEGRATION_MID'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(40903617607656868653)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(23401884988223836)
,p_name=>'P37_MONTH'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(40903617607656868653)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(23402304568223837)
,p_name=>'P37_DAY'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(40903617607656868653)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(23403053952223844)
,p_name=>'New'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(23403617345223845)
,p_event_id=>wwv_flow_api.id(23403053952223844)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''a[href*=":20:"]'').each(function(index) {',
'   ',
'   lnk1 = $(this).html();',
'   lnk = $(this).attr(''href'');',
'   $(this).parent()',
'          .parent(''tr'')',
'    .attr(''data-href'', lnk)',
'	.attr(''edge-href'', lnk1)',
'    .click(function(){',
'      window.location=$(this).attr(''data-href'');',
'    })',
'    .mouseover(function(){',
'      $(this).css(''cursor'', ''pointer'');',
'    })',
'    .mouseleave(function(){',
'      $(this).css(''cursor'', ''default'');',
'    })',
'});',
'',
''))
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(23402699219223843)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'',
'',
'v_name varchar2(200);',
'v_token  varchar2(4000);',
'',
'BEGIN',
'',
'  /* ',
'   IF APEX_UTIL.GET_SESSION_STATE(''USER_NAME'') IS NULL THEN',
'        APEX_UTIL.REDIRECT_URL(''f?p=&APP_ID.:41:&APP_SESSION.'');',
'   ELSE',
'        APEX_CUSTOM_AUTH.SET_USER(APEX_UTIL.GET_SESSION_STATE(''USER_NAME''));',
'   END IF;',
'',
'*/',
'null;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
