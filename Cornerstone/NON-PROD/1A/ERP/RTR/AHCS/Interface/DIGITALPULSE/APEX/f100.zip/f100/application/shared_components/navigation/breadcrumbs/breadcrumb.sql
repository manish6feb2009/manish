prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU: Breadcrumb
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1709070790630706
,p_default_application_id=>100
,p_default_id_offset=>14758838573580759
,p_default_owner=>'DGTL_PLS'
);
wwv_flow_api.create_menu(
 p_id=>wwv_flow_api.id(33326330350225847866)
,p_name=>'Breadcrumb'
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(34350099993811746033)
,p_short_name=>'LongRunBreadCrumb'
,p_long_name=>'Long Running Jobs'
,p_link=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
,p_page_id=>5
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(34351737518834820847)
,p_parent_id=>wwv_flow_api.id(34350099993811746033)
,p_short_name=>'Long Running Jobs - Entry'
,p_link=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:::'
,p_page_id=>14
);
wwv_flow_api.component_end;
end;
/
