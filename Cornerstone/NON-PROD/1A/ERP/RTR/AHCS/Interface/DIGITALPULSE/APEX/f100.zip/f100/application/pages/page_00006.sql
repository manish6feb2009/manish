prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1709070790630706
,p_default_application_id=>100
,p_default_id_offset=>14758838573580759
,p_default_owner=>'DGTL_PLS'
);
wwv_flow_api.create_page(
 p_id=>6
,p_user_interface_id=>wwv_flow_api.id(33326459299734847953)
,p_name=>'Critical Jobs'
,p_step_title=>'Critical Jobs'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_last_updated_by=>'WESCO_DP_SIT1_DEVELOPER'
,p_last_upd_yyyymmddhh24miss=>'20220202045031'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(34202210771832676449)
,p_plug_name=>'Critical Jobs'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(33326379582771847900)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7169412670848411322)
,p_plug_name=>'Critical Jobs'
,p_parent_plug_id=>wwv_flow_api.id(34202210771832676449)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(33326379582771847900)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  a.request_id, A.PROGRAM_NAME AS description, a.status, a.submitted_by, a.submit_time, a.start_time, a.end_time, a.ticket_number,A.FLOWTASKNAME,A.FLOWINSTANCENAME',
'FROM XX_IMD_JOB_RUN_T a',
'WHERE (A.JOB_TYPE=''C'' OR A.JOB_TYPE=''O'')',
'  AND A.STATUS = NVL(:P6_STATUS,A.STATUS)',
'  AND (extract(hour from systimestamp - cast (START_TIME as timestamp)) + 24 * ',
'	  extract(day from systimestamp - cast (START_TIME as timestamp ))) <= NVL(:P30_NEW,100000000)',
'  /*AND a.program_name = b.job_name*/',
'  AND nvl(A.TRACK,''xx'') = NVL(:P6_TRACK,nvl(A.TRACK,''xx''))',
'  AND nvl(A.PHASE_CODE,''xx'') = nvl(:P6_MODULE,nvl(A.phase_code,''xx''))',
'  AND A.PROGRAM_NAME = NVL(:P6_PROGRAM_NAME,A.PROGRAM_NAME)',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P6_PROGRAM_NAME,P6_TIME,P6_TRACK,P6_MODULE,P6_STATUS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(7169412852383411324)
,p_max_row_count=>'1000000'
,p_max_rows_per_page=>'10'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'VPARASHAR@DELOITTE.COM'
,p_internal_uid=>2905794421130596649
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7169412985925411325)
,p_db_column_name=>'REQUEST_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Request Id'
,p_column_type=>'STRING'
,p_static_id=>'REQUESTID_LRJ1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7288708972862513576)
,p_db_column_name=>'DESCRIPTION'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Description'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7288709196183513578)
,p_db_column_name=>'STATUS'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7288709282003513579)
,p_db_column_name=>'SUBMITTED_BY'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Submitted By'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7288709427305513580)
,p_db_column_name=>'SUBMIT_TIME'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Submit Time'
,p_column_type=>'DATE'
,p_format_mask=>'DD-MON-YYYY HH24:MI:SS'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7288709527571513581)
,p_db_column_name=>'START_TIME'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Start Time'
,p_column_type=>'DATE'
,p_format_mask=>'DD-MON-YYYY HH24:MI:SS'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7288709603723513582)
,p_db_column_name=>'END_TIME'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'End Time'
,p_column_type=>'DATE'
,p_format_mask=>'DD-MON-YYYY HH24:MI:SS'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7288709686355513583)
,p_db_column_name=>'TICKET_NUMBER'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Ticket Number'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_static_id=>'ticket1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5515619245933501)
,p_db_column_name=>'FLOWTASKNAME'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Flowtaskname'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5515765239933502)
,p_db_column_name=>'FLOWINSTANCENAME'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Flowinstancename'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(7289038479323050085)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'30254201'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'REQUEST_ID:DESCRIPTION:STATUS:SUBMITTED_BY:SUBMIT_TIME:START_TIME:END_TIME:TICKET_NUMBER:FLOWTASKNAME:FLOWINSTANCENAME'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7169412787408411323)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(7169412670848411322)
,p_button_name=>'Refresh_1'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(33326436807038847939)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Refresh'
,p_button_position=>'ABOVE_BOX'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16833446131380227)
,p_name=>'P6_PROGRAM_NAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(7169412670848411322)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16833557840380228)
,p_name=>'P6_TIME'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(7169412670848411322)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16833604088380229)
,p_name=>'P6_TRACK'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(7169412670848411322)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16833671699380230)
,p_name=>'P6_MODULE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(7169412670848411322)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16833845503380231)
,p_name=>'P6_STATUS'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(7169412670848411322)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(7288709786407513584)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(7169412787408411323)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(7288710009081513586)
,p_event_id=>wwv_flow_api.id(7288709786407513584)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    XX_APEX_GET_ESS_DET_SEC_PKG.get_reqID_crit(null,null);',
'end ;',
'',
'begin',
'    XX_APEX_GET_ESS_DET_SEC_PKG.get_reqID_outbound(null,null);',
'end ;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(16833891358380232)
,p_event_id=>wwv_flow_api.id(7288709786407513584)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(7169412670848411322)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(22752746708825533)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'',
'',
'v_name varchar2(200);',
'v_token  varchar2(4000);',
'',
'BEGIN',
'',
'   ',
'   IF APEX_UTIL.GET_SESSION_STATE(''USER_NAME'') IS NULL THEN',
'        APEX_UTIL.REDIRECT_URL(''f?p=&APP_ID.:41:&APP_SESSION.'');',
'   ELSE',
'        APEX_CUSTOM_AUTH.SET_USER(APEX_UTIL.GET_SESSION_STATE(''USER_NAME''));',
'   END IF;',
'',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
