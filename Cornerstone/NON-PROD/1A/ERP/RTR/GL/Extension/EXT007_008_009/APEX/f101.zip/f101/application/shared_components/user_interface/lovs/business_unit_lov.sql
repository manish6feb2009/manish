prompt --application/shared_components/user_interface/lovs/business_unit_lov
begin
--   Manifest
--     BUSINESS_UNIT_LOV
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1205386977126596
,p_default_application_id=>101
,p_default_id_offset=>29579689224955998307
,p_default_owner=>'FININT'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(29585699526739994915)
,p_lov_name=>'BUSINESS_UNIT_LOV'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct ',
'BUSINESS_UNIT_NAME as d,',
'BUSINESS_UNIT_ID as r',
'from WSC_BUSINESS_UNIT_T ',
'ORDER BY BUSINESS_UNIT_NAME'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
);
wwv_flow_api.component_end;
end;
/
