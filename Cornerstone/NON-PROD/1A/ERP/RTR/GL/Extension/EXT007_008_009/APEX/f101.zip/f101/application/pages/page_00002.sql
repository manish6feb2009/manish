prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1205386977126596
,p_default_application_id=>101
,p_default_id_offset=>29579689224955998307
,p_default_owner=>'FININT'
);
wwv_flow_api.create_page(
 p_id=>2
,p_user_interface_id=>wwv_flow_api.id(29581573747695996843)
,p_name=>'COA_MAPPING_VALUE'
,p_alias=>'COA-MAPPING-VALUE'
,p_step_title=>'Wesco COA Mapping Value'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'::-webkit-scrollbar {',
'    display: horizontal;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_rejoin_existing_sessions=>'Y'
,p_last_updated_by=>'nobody'
,p_last_upd_yyyymmddhh24miss=>'20220124164804'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2522270981704801)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_api.id(29581506610598996784)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'STANDARD'
,p_attribute_02=>'Y'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2522325558704802)
,p_plug_name=>'Sync CCID'
,p_parent_plug_id=>wwv_flow_api.id(2522270981704801)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(29581499813915996782)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(29587092138132658241)
,p_plug_name=>'Search COA Segment Value'
,p_parent_plug_id=>wwv_flow_api.id(2522270981704801)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(29581499813915996782)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2522479399704803)
,p_plug_name=>'New'
,p_parent_plug_id=>wwv_flow_api.id(29587092138132658241)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(29581499813915996782)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(9662349739828770)
,p_plug_name=>'New'
,p_parent_plug_id=>wwv_flow_api.id(29587092138132658241)
,p_region_template_options=>'#DEFAULT#:margin-top-lg'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(29581498636133996781)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    values1.VALUE_ID,',
'    values1.RULE_NAME,',
'    values1.RULE_ID,   ',
'    values1.SOURCE_SEGMENT1,',
'    values1.SOURCE_SEGMENT2,',
'    values1.SOURCE_SEGMENT3,',
'    values1.SOURCE_SEGMENT4,',
'    values1.SOURCE_SEGMENT5,',
'    values1.SOURCE_SEGMENT6,',
'    values1.SOURCE_SEGMENT7,',
'    values1.SOURCE_SEGMENT8,',
'    values1.SOURCE_SEGMENT9,',
'    values1.SOURCE_SEGMENT10,',
'    values1.TARGET_SEGMENT,',
'    values1.flag,',
'    values1.created_by,',
'    values1.last_updated_by',
'',
'    FROM WSC_GL_COA_SEGMENT_VALUE_T values1  ',
'    WHERE',
'    values1.rule_id = nvl(:RULE_NAME_SEARCH, values1.rule_id)',
'    and exists (select 1 from WSC_GL_COA_MAPPING_RULES_T mapping1',
'    where mapping1.TARGET_SEGMENT = nvl(:TARGET_SEGMENT,mapping1.TARGET_SEGMENT)',
'    and values1.rule_id = mapping1.rule_id and mapping1.coa_map_id = :COA_MAP)'))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'RULE_NAME_SEARCH,COA_MAP,TARGET_SEGMENT'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'New'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(9127925945885984)
,p_name=>'APEX$ROW_ACTION'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(9128078146885985)
,p_name=>'APEX$ROW_SELECTOR'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(9662557388828772)
,p_name=>'RULE_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'RULE_ID'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Rule Code'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>30
,p_value_alignment=>'RIGHT'
,p_value_css_classes=>'Appearance attribute: is-readonly'
,p_attribute_03=>'right'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(9662676258828773)
,p_name=>'RULE_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'RULE_NAME'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Rule Name'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_lov_type=>'SQL_QUERY'
,p_lov_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a,b from (select distinct  rule_name a, rule_name b',
'from wsc_gl_coa_mapping_rules_t)',
'order by a'))
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'EXISTS'
,p_readonly_condition=>'select 1 from dual where :VALUE_ID is not null'
,p_readonly_for_each_row=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(9662764438828774)
,p_name=>'VALUE_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VALUE_ID'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>170
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(9662829718828775)
,p_name=>'SOURCE_SEGMENT1'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT1'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Source Segment1'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>200
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'EXISTS'
,p_readonly_condition=>'select 1 from dual where :VALUE_ID is not null'
,p_readonly_for_each_row=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(9662922308828776)
,p_name=>'SOURCE_SEGMENT2'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT2'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Source Segment2'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>200
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'EXISTS'
,p_readonly_condition=>'select 1 from dual where :VALUE_ID is not null'
,p_readonly_for_each_row=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(9663068579828777)
,p_name=>'SOURCE_SEGMENT3'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT3'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Source Segment3'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>200
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'EXISTS'
,p_readonly_condition=>'select 1 from dual where :VALUE_ID is not null'
,p_readonly_for_each_row=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(9663139590828778)
,p_name=>'SOURCE_SEGMENT4'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT4'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Source Segment4'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>80
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>200
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'EXISTS'
,p_readonly_condition=>'select 1 from dual where :VALUE_ID is not null'
,p_readonly_for_each_row=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(9663243095828779)
,p_name=>'SOURCE_SEGMENT5'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT5'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Source Segment5'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>200
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'EXISTS'
,p_readonly_condition=>'select 1 from dual where :VALUE_ID is not null'
,p_readonly_for_each_row=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(9663339663828780)
,p_name=>'SOURCE_SEGMENT6'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT6'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Source Segment6'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>100
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>200
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'EXISTS'
,p_readonly_condition=>'select 1 from dual where :VALUE_ID is not null'
,p_readonly_for_each_row=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(9663455417828781)
,p_name=>'SOURCE_SEGMENT7'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT7'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Source Segment7'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>110
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>200
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'EXISTS'
,p_readonly_condition=>'select 1 from dual where :VALUE_ID is not null'
,p_readonly_for_each_row=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(9663533327828782)
,p_name=>'SOURCE_SEGMENT8'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT8'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Source Segment8'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>120
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>200
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'EXISTS'
,p_readonly_condition=>'select 1 from dual where :VALUE_ID is not null'
,p_readonly_for_each_row=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(9663652709828783)
,p_name=>'SOURCE_SEGMENT9'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT9'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Source Segment9'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>130
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>200
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'EXISTS'
,p_readonly_condition=>'select 1 from dual where :VALUE_ID is not null'
,p_readonly_for_each_row=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(9663779870828784)
,p_name=>'SOURCE_SEGMENT10'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT10'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Source Segment10'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>140
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>200
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'EXISTS'
,p_readonly_condition=>'select 1 from dual where :VALUE_ID is not null'
,p_readonly_for_each_row=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(9663806193828785)
,p_name=>'TARGET_SEGMENT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TARGET_SEGMENT'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Target Segment'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>150
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>200
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'EXISTS'
,p_readonly_condition=>'select 1 from dual where :VALUE_ID is not null'
,p_readonly_for_each_row=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(9665401483828801)
,p_name=>'FLAG'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FLAG'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SINGLE_CHECKBOX'
,p_heading=>'Flag'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>160
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_default_type=>'STATIC'
,p_default_expression=>'Y'
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'NOT_EXISTS'
,p_readonly_condition=>'select 1 from wsc_gl_coa_segment_value_t where value_id = :value_id and flag = ''Y'''
,p_readonly_for_each_row=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(14076395366953365)
,p_name=>'CREATED_BY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CREATED_BY'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>180
,p_attribute_01=>'N'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_default_type=>'SQL_QUERY'
,p_default_expression=>'select :P_USER_NAME from dual;'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(14076519499953366)
,p_name=>'LAST_UPDATED_BY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LAST_UPDATED_BY'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>190
,p_attribute_01=>'N'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_default_type=>'SQL_QUERY'
,p_default_expression=>'select :P_USER_NAME from dual'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_api.create_interactive_grid(
 p_id=>wwv_flow_api.id(9662426223828771)
,p_internal_uid=>5778743069066607
,p_is_editable=>true
,p_edit_operations=>'i:u'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>true
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SET'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_api.create_ig_report(
 p_id=>wwv_flow_api.id(10620833854906244)
,p_interactive_grid_id=>wwv_flow_api.id(9662426223828771)
,p_static_id=>'67372'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_api.create_ig_report_view(
 p_id=>wwv_flow_api.id(10620985345906245)
,p_report_id=>wwv_flow_api.id(10620833854906244)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(10621425098906255)
,p_view_id=>wwv_flow_api.id(10620985345906245)
,p_display_seq=>15
,p_column_id=>wwv_flow_api.id(9662557388828772)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>80
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(10622300591906268)
,p_view_id=>wwv_flow_api.id(10620985345906245)
,p_display_seq=>2
,p_column_id=>wwv_flow_api.id(9662676258828773)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>235
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(10623201263906273)
,p_view_id=>wwv_flow_api.id(10620985345906245)
,p_display_seq=>3
,p_column_id=>wwv_flow_api.id(9662764438828774)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(10624153006906278)
,p_view_id=>wwv_flow_api.id(10620985345906245)
,p_display_seq=>4
,p_column_id=>wwv_flow_api.id(9662829718828775)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>115
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(10625053362906282)
,p_view_id=>wwv_flow_api.id(10620985345906245)
,p_display_seq=>5
,p_column_id=>wwv_flow_api.id(9662922308828776)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>115
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(10625962024906287)
,p_view_id=>wwv_flow_api.id(10620985345906245)
,p_display_seq=>6
,p_column_id=>wwv_flow_api.id(9663068579828777)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>115
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(10626797835906291)
,p_view_id=>wwv_flow_api.id(10620985345906245)
,p_display_seq=>7
,p_column_id=>wwv_flow_api.id(9663139590828778)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>115
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(10627703794906295)
,p_view_id=>wwv_flow_api.id(10620985345906245)
,p_display_seq=>8
,p_column_id=>wwv_flow_api.id(9663243095828779)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>115
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(10628640160906300)
,p_view_id=>wwv_flow_api.id(10620985345906245)
,p_display_seq=>9
,p_column_id=>wwv_flow_api.id(9663339663828780)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>115
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(10629513310906304)
,p_view_id=>wwv_flow_api.id(10620985345906245)
,p_display_seq=>10
,p_column_id=>wwv_flow_api.id(9663455417828781)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>115
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(10630475015906308)
,p_view_id=>wwv_flow_api.id(10620985345906245)
,p_display_seq=>11
,p_column_id=>wwv_flow_api.id(9663533327828782)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>115
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(10631300138906313)
,p_view_id=>wwv_flow_api.id(10620985345906245)
,p_display_seq=>12
,p_column_id=>wwv_flow_api.id(9663652709828783)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>115
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(10632185147906317)
,p_view_id=>wwv_flow_api.id(10620985345906245)
,p_display_seq=>13
,p_column_id=>wwv_flow_api.id(9663779870828784)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>115
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(10633100409906321)
,p_view_id=>wwv_flow_api.id(10620985345906245)
,p_display_seq=>14
,p_column_id=>wwv_flow_api.id(9663806193828785)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>115
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(10647398384906383)
,p_view_id=>wwv_flow_api.id(10620985345906245)
,p_display_seq=>1
,p_column_id=>wwv_flow_api.id(9665401483828801)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>50
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(10883505129254163)
,p_view_id=>wwv_flow_api.id(10620985345906245)
,p_display_seq=>0
,p_column_id=>wwv_flow_api.id(9127925945885984)
,p_is_visible=>true
,p_is_frozen=>true
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(14082306880953797)
,p_view_id=>wwv_flow_api.id(10620985345906245)
,p_display_seq=>16
,p_column_id=>wwv_flow_api.id(14076395366953365)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(14083192662953806)
,p_view_id=>wwv_flow_api.id(10620985345906245)
,p_display_seq=>17
,p_column_id=>wwv_flow_api.id(14076519499953366)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5532779005560502)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(29587092138132658241)
,p_button_name=>'Search'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(29581551877927996815)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Search'
,p_button_position=>'BELOW_BOX'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5533121061560503)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(29587092138132658241)
,p_button_name=>'Add'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(29581551877927996815)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Upload'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:RP,::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9128253274885987)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(29587092138132658241)
,p_button_name=>'Download'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(29581551877927996815)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Download Value Segment'
,p_button_position=>'BELOW_BOX'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9130976113886014)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(29587092138132658241)
,p_button_name=>'Download_C'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(29581551877927996815)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Download Cache '
,p_button_position=>'BELOW_BOX'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(15046072409979205)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(2522325558704802)
,p_button_name=>'syncccid'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(29581551877927996815)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Sync CCID'
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_column=>2
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2522696693704805)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(2522325558704802)
,p_button_name=>'Refresh_Sync_CCID'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(29581551877927996815)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Refresh Sync CCID'
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_column=>3
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2522574835704804)
,p_name=>'P2_NEW'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(2522325558704802)
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(29581551198252996813)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2523411987704813)
,p_name=>'STATE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(2522325558704802)
,p_prompt=>'State'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(29581551198252996813)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5533492306560507)
,p_name=>'COA_MAP'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(29587092138132658241)
,p_prompt=>'COA Map'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select COA_MAP_NAME a, COA_MAP_ID b from wsc_gl_coa_map_t order by coa_map_id'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(29581551449508996813)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5533944844560509)
,p_name=>'TARGET_SEGMENT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(29587092138132658241)
,p_prompt=>'Target Segment'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct SEGMENT_DESC a, mapping1.TARGET_SEGMENT b ',
'from ',
'WSC_GL_COA_MAPPING_RULES_T mapping1,',
'WSC_GL_COA_SEGMENT_DEFINITIONS_T segment1  ',
'where COA_MAP_ID = :COA_MAP and mapping1.TARGET_SEGMENT = segment1.SEGMENT_NAME and segment1.TARGET_FLAG = ''Y''',
'order by b'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'COA_MAP'
,p_ajax_items_to_submit=>'TARGET_SEGMENT,COA_MAP,RULE_NAME_SEARCH'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(29581551198252996813)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5534353315560509)
,p_name=>'RULE_NAME_SEARCH'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(29587092138132658241)
,p_prompt=>'Rule Name'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT RULE_NAME a, RULE_ID b FROM WSC_GL_COA_MAPPING_RULES_T',
'where  COA_MAP_ID = :COA_MAP and TARGET_SEGMENT = :TARGET_SEGMENT',
'and rule_name not like(''%efault%'')',
'order by RULE_PRIORITY'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'TARGET_SEGMENT'
,p_ajax_items_to_submit=>'RULE_NAME_SEARCH,TARGET_SEGMENT,COA_MAP'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(29581551198252996813)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(9128625190885991)
,p_tabular_form_region_id=>wwv_flow_api.id(9662349739828770)
,p_validation_name=>'New'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT 1',
'FROM   WSC_GL_COA_SEGMENT_VALUE_T',
'WHERE  rule_name = :RULE_NAME',
'and nvl(SOURCE_SEGMENT1,1) = nvl(:SOURCE_SEGMENT1,1)',
'and nvl(SOURCE_SEGMENT2,1) = nvl(:SOURCE_SEGMENT2,1)',
'and nvl(SOURCE_SEGMENT3,1) = nvl(:SOURCE_SEGMENT3,1)',
'and nvl(SOURCE_SEGMENT4,1) = nvl(:SOURCE_SEGMENT4,1)',
'and nvl(SOURCE_SEGMENT5,1) = nvl(:SOURCE_SEGMENT5,1)',
'and nvl(SOURCE_SEGMENT6,1) = nvl(:SOURCE_SEGMENT6,1)',
'and nvl(SOURCE_SEGMENT7,1) = nvl(:SOURCE_SEGMENT7,1)',
'and nvl(SOURCE_SEGMENT8,1) = nvl(:SOURCE_SEGMENT8,1)',
'and nvl(SOURCE_SEGMENT9,1) = nvl(:SOURCE_SEGMENT9,1)',
'and nvl(SOURCE_SEGMENT10,1) = nvl(:SOURCE_SEGMENT10,1)',
'and :flag = ''Y''',
'and flag = ''Y'''))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'COA Source Segment is already available.'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1205386977126596
,p_default_application_id=>101
,p_default_id_offset=>29579689224955998307
,p_default_owner=>'FININT'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(14076871710953369)
,p_tabular_form_region_id=>wwv_flow_api.id(9662349739828770)
,p_validation_name=>'New_1'
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT 1',
'FROM   WSC_GL_COA_SEGMENT_VALUE_T where flag = ''N'' and value_id = :value_id'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'User cannot enable the already disable record!'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(5543308590560538)
,p_name=>'RefreshRegion'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(9662349739828770)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(9665650618828803)
,p_name=>'New'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(5532779005560502)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(9665700278828804)
,p_event_id=>wwv_flow_api.id(9665650618828803)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(9662349739828770)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(9128374231885988)
,p_name=>'New_1'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(9128253274885987)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(9128439036885989)
,p_event_id=>wwv_flow_api.id(9128374231885988)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P_COA_MAP_NAME := :COA_MAP;'
,p_attribute_02=>'P_COA_MAP_NAME'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(9128556074885990)
,p_event_id=>wwv_flow_api.id(9128374231885988)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'javascript:window.open(''f?p=&APP_ID.:5:&SESSION.:APPLICATION_PROCESS=wsc_coa_mapping:NO'', ''_self'');'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(9666420403828811)
,p_name=>'New_2'
,p_event_sequence=>60
,p_triggering_element_type=>'COLUMN'
,p_triggering_region_id=>wwv_flow_api.id(9662349739828770)
,p_triggering_element=>'RULE_NAME'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(9666510706828812)
,p_event_id=>wwv_flow_api.id(9666420403828811)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'COLUMN'
,p_affected_elements=>'RULE_ID'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>'select distinct RULE_ID from WSC_GL_COA_MAPPING_RULES_T where RULE_NAME = :RULE_NAME;'
,p_attribute_07=>'RULE_NAME'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(11564601738089265)
,p_name=>'New_3'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(9130976113886014)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(11564703611089266)
,p_event_id=>wwv_flow_api.id(11564601738089265)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P_COA_MAP_NAME := :COA_MAP;'
,p_attribute_02=>'P_COA_MAP_NAME'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(11564818450089267)
,p_event_id=>wwv_flow_api.id(11564601738089265)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'javascript:window.open(''f?p=&APP_ID.:5:&SESSION.:APPLICATION_PROCESS=WSC_CAHE_DOWNLOAD:NO'', ''_self'');'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(15046087632979206)
,p_name=>'New_4'
,p_event_sequence=>80
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'document'
,p_bind_type=>'bind'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'syncccid1'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(15046633188979211)
,p_event_id=>wwv_flow_api.id(15046087632979206)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(16241813544805865)
,p_event_id=>wwv_flow_api.id(15046087632979206)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'WSC_DISABLED_COA_HANDLE_PKG.wsc_sync_ccid_coa_prc;',
'end;',
''))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(15046862929979213)
,p_name=>'New_5'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(15046072409979205)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(15046937719979214)
,p_event_id=>wwv_flow_api.id(15046862929979213)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>' $.event.trigger("syncccid");'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(2522705972704806)
,p_name=>'New_6'
,p_event_sequence=>100
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(2522696693704805)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(2522851486704807)
,p_event_id=>wwv_flow_api.id(2522705972704806)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'STATE'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''In Process'' from dual ',
'where exists ',
'(select 1 from dba_scheduler_running_jobs where job_name like ''%WSC_DISABLED_COA_HANDLE_%'' )',
'union ',
'select ''Successed'' from dual',
'where not exists ',
'(select 1 from dba_scheduler_running_jobs where job_name like ''%WSC_DISABLED_COA_HANDLE_%'' )'))
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(2523363937704812)
,p_event_id=>wwv_flow_api.id(2522705972704806)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(15046072409979205)
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'STATE'
,p_client_condition_expression=>'Successed'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(2522907275704808)
,p_name=>'New_7'
,p_event_sequence=>110
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(15046072409979205)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(2523083490704809)
,p_event_id=>wwv_flow_api.id(2522907275704808)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  dbms_scheduler.create_job (',
'  job_name   =>  ''WSC_DISABLED_COA_HANDLE_''||to_char(sysdate,''ddmonyyyyhh24miss''),',
'  job_type   => ''PLSQL_BLOCK'',',
'  job_action => ',
'    ''BEGIN ',
'       WSC_DISABLED_COA_HANDLE_PKG.wsc_sync_ccid_coa_prc;',
'     END;'',',
'  enabled   =>  TRUE,  ',
'  auto_drop =>  TRUE, ',
'  comments  =>  ''WSC_DISABLED_COA_HANDLE_PKG'');',
'  :STATE := ''In Process'';',
'end;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(2523157588704810)
,p_event_id=>wwv_flow_api.id(2522907275704808)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'STATE'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'In Process'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(2523295150704811)
,p_event_id=>wwv_flow_api.id(2522907275704808)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(15046072409979205)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11026448573215471)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'username varchar2(200) := APEX_UTIL.GET_SESSION_STATE(''USER_NAME'');',
'begin :P_USER_NAME := username; end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(9128115116885986)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(9662349739828770)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'New - Save Interactive Grid Data'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(5542912152560537)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_user_name varchar2(200);',
'v_jwt_token  varchar2(4000);',
'',
'BEGIN',
'',
'-- APEX_CUSTOM_AUTH.SET_USER(''WESCO_USER'');',
'-- APEX_UTIL.SET_SESSION_STATE(''USER_NAME'',''WESCO_USER'');',
'',
'IF  APEX_UTIL.GET_SESSION_STATE(''USER_NAME'') IS NULL THEN',
'   ',
'  xx_apex_user_security_pkg.main(v_jwt_token,v_user_name,null);  ',
'  ',
'  APEX_UTIL.SET_SESSION_STATE(''USER_NAME'',v_user_name);',
'    APEX_UTIL.SET_SESSION_STATE(''JWT_TOKEN'',v_jwt_token);',
'   ',
'    IF APEX_UTIL.GET_SESSION_STATE(''USER_NAME'') IS NULL THEN',
'        APEX_UTIL.REDIRECT_URL(''f?p=&APP_ID.:9999:&APP_SESSION.'');',
'   ELSE',
'        APEX_CUSTOM_AUTH.SET_USER(APEX_UTIL.GET_SESSION_STATE(''USER_NAME''));',
'        ',
'   END IF;',
'   ',
'ELSE',
'   APEX_CUSTOM_AUTH.SET_USER(APEX_UTIL.GET_SESSION_STATE(''USER_NAME''));  ',
'   ',
'END IF;',
'',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
