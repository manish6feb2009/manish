prompt --application/pages/page_00009
begin
--   Manifest
--     PAGE: 00009
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1701052144005286
,p_default_application_id=>101
,p_default_id_offset=>29579689224955998307
,p_default_owner=>'FININT'
);
wwv_flow_api.create_page(
 p_id=>9
,p_user_interface_id=>wwv_flow_api.id(29581573747695996843)
,p_name=>'CCID Mismatch Report'
,p_alias=>'CCID-MISMATCH-REPORT'
,p_step_title=>'CCID Mismatch Report'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_last_updated_by=>'WESCO_DEV_DEVELOPER'
,p_last_upd_yyyymmddhh24miss=>'20230106122344'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5426114714532105)
,p_plug_name=>'CCID Map ID'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(29581499813915996782)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6756830474543322)
,p_plug_name=>'Report'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(29581499813915996782)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5426724215532111)
,p_plug_name=>'Mismatch Report'
,p_parent_plug_id=>wwv_flow_api.id(6756830474543322)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(29581498636133996781)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select COA_NAME,',
'SOURCE_SEGMENT1,',
'SOURCE_SEGMENT2,',
'SOURCE_SEGMENT3,',
'SOURCE_SEGMENT4,',
'SOURCE_SEGMENT5,',
'SOURCE_SEGMENT6,',
'SOURCE_SEGMENT7,',
'SOURCE_SEGMENT8,',
'SOURCE_SEGMENT9,',
'SOURCE_SEGMENT10,',
'TARGET_SEGMENT_NEW,',
'TARGET_SEGMENT_OLD,',
'''Y'' MISMATCH_STATUS from WSC_CCID_MISMATCH_DATA_T',
'union all',
'select ',
'DECODE(COA_MAP_ID,1,''WESCO to Cloud'',2,''Anixter to Cloud'',3,''Central to Cloud'',4,''POC to Cloud'',''Peoplesoft to Cloud''),',
'a.SOURCE_SEGMENT1,',
'a.SOURCE_SEGMENT2,',
'a.SOURCE_SEGMENT3,',
'a.SOURCE_SEGMENT4,',
'a.SOURCE_SEGMENT5,',
'a.SOURCE_SEGMENT6,',
'a.SOURCE_SEGMENT7,',
'a.SOURCE_SEGMENT8,',
'a.SOURCE_SEGMENT9,',
'a.SOURCE_SEGMENT10,',
'a.TARGET_SEGMENT,',
'a.TARGET_SEGMENT,',
'''N'' ',
'FROM WSC_GL_CCID_MAPPING_T a',
'--WSC_CCID_MISMATCH_DATA_T b',
'where ',
'--not exists(select 1 from WSC_CCID_MISMATCH_DATA_T',
'--where a.source_segment = b.source_segment)',
'a.source_segment not in (select source_segment from WSC_CCID_MISMATCH_DATA_T)',
'--and',
'--a.source_segment <> b.source_segment',
'and a.enable_flag = ''Y''',
'and a.coa_map_id = :CCID_MAP_ID',
'',
'-- UNION all',
'-- select DECODE(COA_MAP_ID,1,''WESCO to Cloud'',2,''Anixter to Cloud'',3,''Central to Cloud'',4,''POC to Cloud'',''Peoplesoft to Cloud''),',
'-- a.SOURCE_SEGMENT1,',
'-- a.SOURCE_SEGMENT2,',
'-- a.SOURCE_SEGMENT3,',
'-- a.SOURCE_SEGMENT4,',
'-- a.SOURCE_SEGMENT5,',
'-- a.SOURCE_SEGMENT6,',
'-- a.SOURCE_SEGMENT7,',
'-- a.SOURCE_SEGMENT8,',
'-- a.SOURCE_SEGMENT9,',
'-- a.SOURCE_SEGMENT10,',
'-- a.TARGET_SEGMENT,',
'-- a.TARGET_SEGMENT,',
'-- ''N'' FROM WSC_GL_CCID_MAPPING_T a,',
'-- WSC_CCID_MISMATCH_DATA_T b',
'-- where a.source_segment <> b.source_segment',
'-- and enable_flag = ''Y''',
'-- and coa_map_id = :CCID_MAP_ID'))
,p_plug_source_type=>'NATIVE_IG'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Mismatch Report'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(7301891255984709)
,p_name=>'MISMATCH_STATUS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MISMATCH_STATUS'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Mismatch Status'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>140
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>1
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(7371461327194414)
,p_name=>'COA_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COA_NAME'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Coa Name'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>150
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>20
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(7371560470194415)
,p_name=>'SOURCE_SEGMENT1'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT1'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Source Segment1'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>160
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>20
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(7371668602194416)
,p_name=>'SOURCE_SEGMENT2'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT2'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Source Segment2'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>170
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>20
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(7371766459194417)
,p_name=>'SOURCE_SEGMENT3'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT3'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Source Segment3'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>180
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>20
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(7371833825194418)
,p_name=>'SOURCE_SEGMENT4'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT4'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Source Segment4'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>190
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>20
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(7371933512194419)
,p_name=>'SOURCE_SEGMENT5'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT5'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Source Segment5'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>200
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>20
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(7372043249194420)
,p_name=>'SOURCE_SEGMENT6'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT6'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Source Segment6'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>210
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>20
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(7372181722194421)
,p_name=>'SOURCE_SEGMENT7'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT7'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Source Segment7'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>220
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>20
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(7372213429194422)
,p_name=>'SOURCE_SEGMENT8'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT8'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Source Segment8'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>230
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>50
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(7372386725194423)
,p_name=>'SOURCE_SEGMENT9'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT9'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Source Segment9'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>240
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>20
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(7372466973194424)
,p_name=>'SOURCE_SEGMENT10'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT10'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Source Segment10'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>250
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>20
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(7372543379194425)
,p_name=>'TARGET_SEGMENT_NEW'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TARGET_SEGMENT_NEW'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Target Segment New'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>260
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>1000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(7372673725194426)
,p_name=>'TARGET_SEGMENT_OLD'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TARGET_SEGMENT_OLD'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Target Segment Old'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>270
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>1000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_interactive_grid(
 p_id=>wwv_flow_api.id(5426878199532112)
,p_internal_uid=>5426878199532112
,p_is_editable=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SET'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_api.create_ig_report(
 p_id=>wwv_flow_api.id(6704249469299680)
,p_interactive_grid_id=>wwv_flow_api.id(5426878199532112)
,p_static_id=>'67043'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_api.create_ig_report_view(
 p_id=>wwv_flow_api.id(6704453556299681)
,p_report_id=>wwv_flow_api.id(6704249469299680)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(7321073923217287)
,p_view_id=>wwv_flow_api.id(6704453556299681)
,p_display_seq=>13
,p_column_id=>wwv_flow_api.id(7301891255984709)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>122
,p_sort_order=>1
,p_sort_direction=>'DESC'
,p_sort_nulls=>'LAST'
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(7397597870202246)
,p_view_id=>wwv_flow_api.id(6704453556299681)
,p_display_seq=>0
,p_column_id=>wwv_flow_api.id(7371461327194414)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>149
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(7398458534202299)
,p_view_id=>wwv_flow_api.id(6704453556299681)
,p_display_seq=>1
,p_column_id=>wwv_flow_api.id(7371560470194415)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>130
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(7399200818202333)
,p_view_id=>wwv_flow_api.id(6704453556299681)
,p_display_seq=>2
,p_column_id=>wwv_flow_api.id(7371668602194416)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>130
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(7400144096202386)
,p_view_id=>wwv_flow_api.id(6704453556299681)
,p_display_seq=>3
,p_column_id=>wwv_flow_api.id(7371766459194417)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>130
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(7400962120202450)
,p_view_id=>wwv_flow_api.id(6704453556299681)
,p_display_seq=>4
,p_column_id=>wwv_flow_api.id(7371833825194418)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>130
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(7401880175202498)
,p_view_id=>wwv_flow_api.id(6704453556299681)
,p_display_seq=>5
,p_column_id=>wwv_flow_api.id(7371933512194419)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>130
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(7402648761202547)
,p_view_id=>wwv_flow_api.id(6704453556299681)
,p_display_seq=>6
,p_column_id=>wwv_flow_api.id(7372043249194420)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>130
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(7403534821202579)
,p_view_id=>wwv_flow_api.id(6704453556299681)
,p_display_seq=>7
,p_column_id=>wwv_flow_api.id(7372181722194421)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>130
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(7404308618202619)
,p_view_id=>wwv_flow_api.id(6704453556299681)
,p_display_seq=>8
,p_column_id=>wwv_flow_api.id(7372213429194422)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>130
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(7405273666202648)
,p_view_id=>wwv_flow_api.id(6704453556299681)
,p_display_seq=>9
,p_column_id=>wwv_flow_api.id(7372386725194423)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>130
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(7406048865202702)
,p_view_id=>wwv_flow_api.id(6704453556299681)
,p_display_seq=>10
,p_column_id=>wwv_flow_api.id(7372466973194424)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>130
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(7406911277202799)
,p_view_id=>wwv_flow_api.id(6704453556299681)
,p_display_seq=>11
,p_column_id=>wwv_flow_api.id(7372543379194425)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>329
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(7407778163202871)
,p_view_id=>wwv_flow_api.id(6704453556299681)
,p_display_seq=>12
,p_column_id=>wwv_flow_api.id(7372673725194426)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>329
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5430128776532145)
,p_plug_name=>'Mismatch Header'
,p_parent_plug_id=>wwv_flow_api.id(6756830474543322)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(29581498636133996781)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  status , CCID_STATUS, TOTAL_COUNT,',
'COMPLETE_COUNT,',
'REMAINING_COUNT, TOTAL_MISMATCH from WSC_CCID_MISMATCH_DATA_HDR_T',
'-- -- where batch_id = :P_BATCH_ID',
'-- select  status, CCID_STATUS from WSC_CCID_MISMATCH_DATA_HDR_T',
'-- union all',
'-- select ''Success'', ''Success'' from dual where (select 1 from WSC_CCID_MISMATCH_DATA_HDR_T) is null;',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Mismatch Header'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(5430640001532150)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_owner=>'WESCO_DEV_DEVELOPER'
,p_internal_uid=>5430640001532150
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6754992025543303)
,p_db_column_name=>'STATUS'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Audit Process Status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6755603170543310)
,p_db_column_name=>'CCID_STATUS'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'CCID Update Status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6757152054543325)
,p_db_column_name=>'TOTAL_COUNT'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Total Count'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6757281993543326)
,p_db_column_name=>'COMPLETE_COUNT'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Completed Count'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6757356785543327)
,p_db_column_name=>'REMAINING_COUNT'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Remaining Count'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6757460820543328)
,p_db_column_name=>'TOTAL_MISMATCH'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Total Mismatch Count'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(6764257020543961)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'67643'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'STATUS:CCID_STATUS:TOTAL_COUNT:COMPLETE_COUNT:REMAINING_COUNT:TOTAL_MISMATCH'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5426261722532106)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(5426114714532105)
,p_button_name=>'Extract'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(29581551877927996815)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Initiate Audit Process'
,p_button_position=>'BELOW_BOX'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from WSC_CCID_MISMATCH_DATA_HDR_T where batch_id = :P_BATCH_ID',
'and status = ''In Process'''))
,p_button_condition_type=>'NOT_EXISTS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6755084150543304)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(5426114714532105)
,p_button_name=>'Refresh'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(29581551877927996815)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Refresh'
,p_button_position=>'BELOW_BOX'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6755160422543305)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(5426114714532105)
,p_button_name=>'CACHEUPDATE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(29581551877927996815)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Update Cache Table'
,p_button_position=>'BELOW_BOX'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from WSC_CCID_MISMATCH_DATA_HDR_T where batch_id = :P_BATCH_ID',
'and status = ''Success'' and ccid_status <> ''Success'''))
,p_button_condition_type=>'EXISTS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6756310180543317)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(5426114714532105)
,p_button_name=>'Go'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(29581551877927996815)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Go'
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_column=>5
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5426351242532107)
,p_name=>'CCID_MAP_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(5426114714532105)
,p_prompt=>'CCID Map ID'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select  coa_map_name a, coa_map_id b from wsc_gl_coa_map_t'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(29581551449508996813)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(5426421779532108)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(5426261722532106)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(5426587404532109)
,p_event_id=>wwv_flow_api.id(5426421779532108)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    batch_id number := WSC_CCID_MISMATCH_BATCH_ID.nextval;',
'begin',
'    :P_BATCH_ID := batch_id;',
'',
'    BEGIN',
'    dbms_scheduler.create_job (',
'    job_name   =>  ''WSC_CCID_MISMATCH_REPORT''||batch_id,',
'    job_type   => ''PLSQL_BLOCK'',',
'    job_action => ',
'        ''DECLARE',
'        L_ERR_MSG VARCHAR2(2000);',
'        L_ERR_CODE VARCHAR2(2);',
'        BEGIN ',
'            WSC_CCID_MISMATCH_REPORT.WSC_CCID(''||:CCID_MAP_ID||'',''||batch_id||'');',
'        END;'',',
'    enabled   =>  TRUE,  ',
'    auto_drop =>  TRUE, ',
'    comments  =>  ''WSC_CCID_MISMATCH_REPORT'');',
'    END;  ',
'',
'    -- WSC_CCID_MISMATCH_REPORT.WSC_CCID(:CCID_MAP_ID,batch_id);',
'end;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(5426609538532110)
,p_event_id=>wwv_flow_api.id(5426421779532108)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(6755756608543311)
,p_name=>'New_1'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(6755084150543304)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(6755841472543312)
,p_event_id=>wwv_flow_api.id(6755756608543311)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(6755952440543313)
,p_name=>'New_2'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(6755160422543305)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(6756289270543316)
,p_event_id=>wwv_flow_api.id(6755952440543313)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Do you want to update the cache table?'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(6756099966543314)
,p_event_id=>wwv_flow_api.id(6755952440543313)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- BEGIN',
'--     WSC_CCID_MISMATCH_REPORT.WSC_CCID_UPDATE;',
'-- end;',
'declare',
'    batch_id number := WSC_CCID_MISMATCH_BATCH_ID.nextval;',
'BEGIN',
'    dbms_scheduler.create_job (',
'    job_name   =>  ''WSC_CCID_MISMATCH_REPORT''||batch_id,',
'    job_type   => ''PLSQL_BLOCK'',',
'    job_action => ',
'        ''DECLARE',
'        L_ERR_MSG VARCHAR2(2000);',
'        L_ERR_CODE VARCHAR2(2);',
'        BEGIN ',
'            WSC_CCID_MISMATCH_REPORT.WSC_CCID_UPDATE;',
'        END;'',',
'    enabled   =>  TRUE,  ',
'    auto_drop =>  TRUE, ',
'    comments  =>  ''WSC_CCID_MISMATCH_REPORT'');',
'    END;  '))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(6756144418543315)
,p_event_id=>wwv_flow_api.id(6755952440543313)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(6756587609543319)
,p_name=>'New_3'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(6756310180543317)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(6756614060543320)
,p_event_id=>wwv_flow_api.id(6756587609543319)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(7372737878194427)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'lv_batch_id number;',
'begin',
'    select batch_id into lv_batch_id from WSC_CCID_MISMATCH_DATA_HDR_T;',
'    :P_BATCH_ID  := lv_batch_id;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
