prompt --application/shared_components/logic/application_processes/wsc_mismatch_cache_update
begin
--   Manifest
--     APPLICATION PROCESS: WSC_MISMATCH_CACHE_UPDATE
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1205386977126596
,p_default_application_id=>101
,p_default_id_offset=>29579689224955998307
,p_default_owner=>'FININT'
);
wwv_flow_api.create_flow_process(
 p_id=>wwv_flow_api.id(8440052193254879)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'WSC_MISMATCH_CACHE_UPDATE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    batch_id number := WSC_CCID_MISMATCH_BATCH_ID.nextval;',
'BEGIN',
'',
'',
'    HTP.FLUSH;',
'    HTP.INIT;',
'    -- insert into wsc_tbl_time_t values(:P_USER_NAME||''_''||:P_COA_MAP_ID,sysdate,909090990);',
'    -- commit;',
'',
'    dbms_scheduler.create_job (',
'    job_name   =>  ''WSC_CCID_MISMATCH_REPORT_UPDATE_''||batch_id,',
'    job_type   => ''PLSQL_BLOCK'',',
'    job_action => ',
'        ''DECLARE',
'        L_ERR_MSG VARCHAR2(2000);',
'        L_ERR_CODE VARCHAR2(2);',
'        BEGIN ',
'            WSC_CCID_MISMATCH_REPORT.WSC_CCID_UPDATE(''''''||:P_USER_NAME||'''''',''''''||:P_COA_MAP_ID||'''''');',
'        END;'',',
'    enabled   =>  TRUE,  ',
'    auto_drop =>  TRUE, ',
'    comments  =>  ''WSC_CCID_MISMATCH_REPORT'');',
'',
'    owa_util.redirect_url(''f?p=&APP_ID.:9:&APP_SESSION.'');',
'',
'    exception',
'    when others then',
'        null;',
'    END;'))
,p_process_clob_language=>'PLSQL'
);
wwv_flow_api.component_end;
end;
/
