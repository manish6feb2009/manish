prompt --application/shared_components/user_interface/lovs/inventory_item_lov
begin
--   Manifest
--     INVENTORY_ITEM_LOV
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1584645834054709
,p_default_application_id=>101
,p_default_id_offset=>29579689224955998307
,p_default_owner=>'FININT'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(29585704883855208888)
,p_lov_name=>'INVENTORY_ITEM_LOV'
,p_lov_query=>'select item_code as d , item_id as r from WSC_ITEM_DETAILS_T order by item_name'
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
);
wwv_flow_api.component_end;
end;
/
