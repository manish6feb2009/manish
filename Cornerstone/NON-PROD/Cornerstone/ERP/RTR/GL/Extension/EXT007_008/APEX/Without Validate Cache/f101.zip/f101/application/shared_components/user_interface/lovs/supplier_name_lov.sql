prompt --application/shared_components/user_interface/lovs/supplier_name_lov
begin
--   Manifest
--     SUPPLIER_NAME_LOV
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1584645834054709
,p_default_application_id=>101
,p_default_id_offset=>29579689224955998307
,p_default_owner=>'FININT'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(29585706052522228608)
,p_lov_name=>'SUPPLIER_NAME_LOV'
,p_lov_query=>'select SUPPLIER_Name as d, SUPPLIER_ID as r	 from WSC_SUPPLIER_T order by SUPPLIER_NAME'
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
);
wwv_flow_api.component_end;
end;
/
