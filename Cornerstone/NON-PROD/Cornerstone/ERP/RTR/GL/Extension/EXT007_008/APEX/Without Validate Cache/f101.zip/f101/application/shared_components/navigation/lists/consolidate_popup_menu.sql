prompt --application/shared_components/navigation/lists/consolidate_popup_menu
begin
--   Manifest
--     LIST: consolidate_popup_menu
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1584645834054709
,p_default_application_id=>101
,p_default_id_offset=>29579689224955998307
,p_default_owner=>'FININT'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(29588680399834700846)
,p_name=>'consolidate_popup_menu'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(29588680548774700847)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'A'
,p_list_item_link_target=>'f?p=&APP_ID.::&SESSION.:'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(29588680981043700847)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'B'
,p_list_item_link_target=>'f?p=&APP_ID.::&SESSION.:'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(29588681347399700848)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'C'
,p_list_item_link_target=>'f?p=&APP_ID.::&SESSION.:'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(29588681756058700848)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'D'
,p_list_item_link_target=>'f?p=&APP_ID.::&SESSION.:'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
