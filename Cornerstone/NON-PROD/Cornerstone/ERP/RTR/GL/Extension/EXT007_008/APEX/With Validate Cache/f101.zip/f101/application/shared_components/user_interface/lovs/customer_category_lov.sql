prompt --application/shared_components/user_interface/lovs/customer_category_lov
begin
--   Manifest
--     CUSTOMER_CATEGORY_LOV
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1205386977126596
,p_default_application_id=>101
,p_default_id_offset=>29579689224955998307
,p_default_owner=>'FININT'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(29585780203847965215)
,p_lov_name=>'CUSTOMER_CATEGORY_LOV'
,p_lov_query=>'.'||wwv_flow_api.id(29585780203847965215)||'.'
,p_location=>'STATIC'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(29585780429008965216)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Platinum'
,p_lov_return_value=>'Platinum'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(29585780911037965217)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Gold'
,p_lov_return_value=>'Gold'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(29585781279609965217)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Silver'
,p_lov_return_value=>'Silver'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(29585781679852965217)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'Authorized'
,p_lov_return_value=>'Authorized'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(29585782116644965217)
,p_lov_disp_sequence=>5
,p_lov_disp_value=>'Non-Authorized'
,p_lov_return_value=>'Non-Authorized'
);
wwv_flow_api.component_end;
end;
/
