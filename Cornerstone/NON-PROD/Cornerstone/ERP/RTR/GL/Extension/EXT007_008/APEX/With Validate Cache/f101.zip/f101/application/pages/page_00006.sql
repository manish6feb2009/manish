prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1205386977126596
,p_default_application_id=>101
,p_default_id_offset=>29579689224955998307
,p_default_owner=>'FININT'
);
wwv_flow_api.create_page(
 p_id=>6
,p_user_interface_id=>wwv_flow_api.id(29581573747695996843)
,p_name=>'CCID_MAPPING_UPLOAD'
,p_alias=>'CCID-MAPPING-UPLOAD'
,p_page_mode=>'MODAL'
,p_step_title=>'Wesco Code Combination Upload'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_api.id(29581465182976996757)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'650'
,p_dialog_width=>'1200'
,p_page_is_public_y_n=>'Y'
,p_rejoin_existing_sessions=>'Y'
,p_last_updated_by=>'WESCO_DEV_DEVLOPER'
,p_last_upd_yyyymmddhh24miss=>'20211102091652'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(29592759043536277405)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(29581498636133996781)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'	C001 COA_MAP_NAME,',
'	C002 SOURCE_SEGMENT,',
'	C003 TARGET_SEGMENT,',
'	C004 ENABLE_FLAG',
'FROM APEX_COLLECTIONS C',
'WHERE C.COLLECTION_NAME=''XL2''',
'AND SEQ_ID > 1;'))
,p_plug_source_type=>'NATIVE_IG'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_required_role=>wwv_flow_api.id(29581576375453996864)
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(8053326584240190)
,p_name=>'COA_MAP_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COA_MAP_NAME'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Coa Map Name'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>10
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(8589342057108969)
,p_name=>'ENABLE_FLAG'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ENABLE_FLAG'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Enable Flag'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>40
,p_value_alignment=>'CENTER'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(8589405227108970)
,p_name=>'SOURCE_SEGMENT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Source Segment'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>20
,p_value_alignment=>'CENTER'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(17520043081018815445)
,p_name=>'TARGET_SEGMENT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TARGET_SEGMENT'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Target Segment'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>30
,p_value_alignment=>'CENTER'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_interactive_grid(
 p_id=>wwv_flow_api.id(29592759206931277406)
,p_internal_uid=>29588875523776515242
,p_is_editable=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_show_nulls_as=>'-'
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>false
,p_toolbar_buttons=>null
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_api.create_ig_report(
 p_id=>wwv_flow_api.id(29594545140967751633)
,p_interactive_grid_id=>wwv_flow_api.id(29592759206931277406)
,p_static_id=>'120775262'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_api.create_ig_report_view(
 p_id=>wwv_flow_api.id(29594545278823751633)
,p_report_id=>wwv_flow_api.id(29594545140967751633)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(8657018138629017)
,p_view_id=>wwv_flow_api.id(29594545278823751633)
,p_display_seq=>3
,p_column_id=>wwv_flow_api.id(8589342057108969)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(8657906982629051)
,p_view_id=>wwv_flow_api.id(29594545278823751633)
,p_display_seq=>1
,p_column_id=>wwv_flow_api.id(8589405227108970)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(8772682440829236)
,p_view_id=>wwv_flow_api.id(29594545278823751633)
,p_display_seq=>0
,p_column_id=>wwv_flow_api.id(8053326584240190)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(17522501536904835257)
,p_view_id=>wwv_flow_api.id(29594545278823751633)
,p_display_seq=>2
,p_column_id=>wwv_flow_api.id(17520043081018815445)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(29594502187410142078)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_plug_template=>wwv_flow_api.id(29581509178198996785)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_api.id(29588155676105941086)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(29581532445315996801)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(29594502315071142078)
,p_plug_name=>'Vendor Cost Data Upload'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(29581478301449996770)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(29594502395198142078)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(29581479231267996771)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8571289159064837)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(29594502315071142078)
,p_button_name=>'P6_LOAD'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(29581551877927996815)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Load'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8572389945064843)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(29594502395198142078)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(29581551877927996815)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8572850533064844)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(29594502395198142078)
,p_button_name=>'NEXT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(29581551941619996815)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(8575416330064851)
,p_branch_name=>'Go To Page 4'
,p_branch_action=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(8572850533064844)
,p_branch_sequence=>20
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(8574993207064850)
,p_branch_name=>'Go To Page 3 '
,p_branch_action=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:RP,::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(8572389945064843)
,p_branch_sequence=>30
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8571685946064840)
,p_name=>'P6_BROWSE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(29594502315071142078)
,p_prompt=>'Please select the excel file:'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(29581551353425996813)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'NATIVE'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(8574036803064848)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(8572389945064843)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(8574513443064848)
,p_event_id=>wwv_flow_api.id(8574036803064848)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11026823319215475)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'username varchar2(200) := APEX_UTIL.GET_SESSION_STATE(''USER_NAME'');',
'begin ',
':P_USER_NAME := username; ',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(8573676003064847)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'PLUGIN_NL.AMIS.SCHEFFER.PROCESS.EXCEL2COLLECTION'
,p_process_name=>'ParseItemsDataFromXLSX'
,p_attribute_01=>'P6_BROWSE'
,p_attribute_02=>'XL2'
,p_attribute_03=>'1'
,p_attribute_04=>';'
,p_attribute_05=>'"'
,p_attribute_07=>'Y'
,p_attribute_08=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(8571289159064837)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(8573280497064846)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'LoadParsedItemsData'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    LV_COA_MAP_NAME_CNT number;',
'    V_COA_MAP_NAME_CHECK varchar2(200);',
'    LV_TARGET_SEG_CNT NUMBER;',
'    lv_error_msg varchar2(2000) ;',
'    lv_error varchar2(50)  := ''false'';',
'    V_DUPLICATE_CHECK number := 0;',
'    ccid_value_id number;',
'    CCID_COUNT number := 0;',
'    CURSOR C1_Y IS',
'        SELECT ',
'            C001 COA_MAP_NAME,',
'            C002 SOURCE_SEGMENT,',
'            C003 TARGET_SEGMENT,',
'            C004 ENABLE_FLAG',
'        FROM APEX_COLLECTIONS C',
'            WHERE C.COLLECTION_NAME=''XL2''',
'            AND SEQ_ID>1',
'            AND C.C004 = ''Y'';',
'    ',
'    CURSOR C1_N IS',
'        SELECT ',
'            C001 COA_MAP_NAME,',
'            C002 SOURCE_SEGMENT,',
'            C003 TARGET_SEGMENT,',
'            C004 ENABLE_FLAG',
'        FROM APEX_COLLECTIONS C',
'            WHERE C.COLLECTION_NAME=''XL2''',
'            AND SEQ_ID>1',
'            AND C.C004 = ''N'';',
'   ',
'    c_m_id NUMBER := 999;',
'BEGIN',
'    delete from WSC_GL_CCID_MAPPING_ERR_T where user_name = :P_USER_NAME;',
'    for REC_C1 in C1_N loop',
'        CCID_COUNT := CCID_COUNT +1;',
'        update WSC_GL_CCID_MAPPING_T set ENABLE_FLAG = ''N'' ',
'        where',
'         ((REC_C1.COA_MAP_NAME is not null and COA_MAP_NAME = REC_C1.COA_MAP_NAME) OR REC_C1.COA_MAP_NAME is null) ',
'         AND',
'         ((REC_C1.SOURCE_SEGMENT is not null and SOURCE_SEGMENT = REC_C1.SOURCE_SEGMENT) OR REC_C1.SOURCE_SEGMENT is null)',
'         AND',
'         ((REC_C1.TARGET_SEGMENT is not null and TARGET_SEGMENT = REC_C1.TARGET_SEGMENT) OR REC_C1.TARGET_SEGMENT is null)',
'         AND ',
'         (COA_MAP_ID = (select COA_MAP_ID from WSC_GL_COA_MAP_T where COA_MAP_NAME = REC_C1.COA_MAP_NAME and rownum = 1));',
'    end loop;',
'    for REC_C1 in C1_Y loop',
'        ccid_value_id :=WSC_GL_CCID_MAPPING_S.NEXTVAL;',
'        ',
'        select WSC_UNIVERSAL_PKG.WSC_CCID_EXIST_COA_MAP_NAME(REC_C1.COA_MAP_NAME) into LV_COA_MAP_NAME_CNT from dual;',
'',
'        IF (LV_COA_MAP_NAME_CNT = 0) ',
'        THEN',
'            lv_error_msg := lv_error_msg || '' -> '' || REC_C1.COA_MAP_NAME || '' :: COA_MAP_NAME value is invalid. Please verify.'';',
'            lv_error := ''True'';',
'        ELSE',
'            SELECT TRIM(COA_MAP_NAME)',
'            INTO V_COA_MAP_NAME_CHECK ',
'            FROM WSC_GL_COA_MAP_T',
'            WHERE UPPER(COA_MAP_NAME) = UPPER(TRIM(REC_C1.COA_MAP_NAME));',
'',
'            SELECT coa_map_id INTO c_m_id',
'            FROM WSC_GL_COA_MAP_T',
'            WHERE UPPER(COA_MAP_NAME) = UPPER(TRIM(REC_C1.COA_MAP_NAME));',
'        END IF;',
'',
'       ',
'        select WSC_UNIVERSAL_PKG.WSC_CCID_DUPLICATE(REC_C1.COA_MAP_NAME, ',
'         REC_C1.SOURCE_SEGMENT) into V_DUPLICATE_CHECK from dual;',
'        ',
'        IF (V_DUPLICATE_CHECK = 1) ',
'		THEN',
'            lv_error_msg :=  ''Duplicate Value is not allow.'';',
'			lv_error := ''True'';',
'		END IF;',
'        ',
'        if(lv_error =''True'')',
'        then',
'            INSERT INTO WSC_GL_CCID_MAPPING_ERR_T(COA_MAP_NAME,',
'                COA_MAP_ID,',
'                SOURCE_SEGMENT,',
'                TARGET_SEGMENT,',
'                ERROR_DESC,',
'                user_name,',
'                CCID_VALUE_ID',
'            )',
'            VALUES(REC_C1.COA_MAP_NAME,',
'                c_m_id,',
'                REC_C1.SOURCE_SEGMENT,',
'                REC_C1.TARGET_SEGMENT,',
'                lv_error_msg,',
'                :P_USER_NAME,',
'                ccid_value_id            ',
'            );',
'        else',
'            CCID_COUNT := CCID_COUNT +1;',
'            INSERT INTO WSC_GL_CCID_MAPPING_T(COA_MAP_NAME,',
'                COA_MAP_ID,',
'                SOURCE_SEGMENT,',
'                TARGET_SEGMENT,',
'                ENABLE_FLAG,',
'                user_name,',
'                UI_Flag,',
'                CCID_VALUE_ID,',
'                created_by,',
'                last_updated_by',
'            )',
'            VALUES(V_COA_MAP_NAME_CHECK,',
'                c_m_id,',
'                REC_C1.SOURCE_SEGMENT,',
'                REC_C1.TARGET_SEGMENT,',
'                REC_C1.ENABLE_FLAG,',
'                :P_USER_NAME,',
'                ''Y'',',
'                ccid_value_id,',
'                :P_USER_NAME,',
'                :P_USER_NAME',
'            );',
'        end if;',
'        lv_error := ''false'';',
'        V_COA_MAP_NAME_CHECK := null;',
'        lv_error_msg := null;',
'        V_DUPLICATE_CHECK := 0;',
'    end loop;',
'    :P_CCID_COUNT := CCID_COUNT;',
'    COMMIT;',
'EXCEPTION',
'    WHEN OTHERS THEN',
'      dbms_output.put_line(''error'');   ',
'END;',
'',
' ',
'',
' ',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
