prompt --application/shared_components/user_interface/lovs/cost_tier_lov
begin
--   Manifest
--     COST_TIER_LOV
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1584645834054709
,p_default_application_id=>101
,p_default_id_offset=>29579689224955998307
,p_default_owner=>'FININT'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(29588914416467465878)
,p_lov_name=>'COST_TIER_LOV'
,p_lov_query=>'.'||wwv_flow_api.id(29588914416467465878)||'.'
,p_location=>'STATIC'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(29588914712655465878)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Customer Special Pricing'
,p_lov_return_value=>'Customer Special Pricing'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(29588915063125465879)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Project Pricing'
,p_lov_return_value=>'Project Pricing'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(29588915490176465879)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Zip Code Level'
,p_lov_return_value=>'Zip Code Level'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(29588915848494465879)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'Warehouse Level / State'
,p_lov_return_value=>'Warehouse Level / State'
);
wwv_flow_api.component_end;
end;
/
