prompt --application/shared_components/navigation/breadcrumbentry
begin
--   Manifest
--     BREADCRUMB ENTRY: 
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1205386977126596
,p_default_application_id=>101
,p_default_id_offset=>29579689224955998307
,p_default_owner=>'FININT'
);
null;
wwv_flow_api.component_end;
end;
/
