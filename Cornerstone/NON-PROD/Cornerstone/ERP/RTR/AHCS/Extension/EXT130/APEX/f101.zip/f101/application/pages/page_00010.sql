prompt --application/pages/page_00010
begin
--   Manifest
--     PAGE: 00010
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1701052144005286
,p_default_application_id=>101
,p_default_id_offset=>29579689224955998307
,p_default_owner=>'FININT'
);
wwv_flow_api.create_page(
 p_id=>10
,p_user_interface_id=>wwv_flow_api.id(29581573747695996843)
,p_name=>'AHCS Mapping Set Update'
,p_alias=>'AHCS-MAPPING-SET-UPDATE'
,p_step_title=>'AHCS Mapping Set Update'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var itemValue = $v("P10_SYNC_DISABLE");',
'',
'var button = apex.jQuery("#syncButton");',
'',
'if (itemValue === ''0'') {',
'  button.prop("disabled", false);',
'} else {',
'  button.prop("disabled", true);',
'}',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.my-custom-font-size {',
'  font-size: 10px;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_last_updated_by=>'WESCO_DEV_DEVELOPER'
,p_last_upd_yyyymmddhh24miss=>'20230727092321'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(9344937842947711)
,p_plug_name=>'AHCS Mapping Set Update'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(29581499813915996782)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(16420313886209509)
,p_plug_name=>'Sync Process History'
,p_parent_plug_id=>wwv_flow_api.id(9344937842947711)
,p_region_template_options=>'#DEFAULT#:margin-top-md'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(29581498636133996781)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select BATCH_ID, ',
'       CREATED_BY as submitted_by,',
'       RESET_DATE,',
'       TO_CHAR(',
'           FROM_TZ(SUBMIT_TIME, ''UTC'') AT TIME ZONE ''America/New_York'', ',
'           ''YYYY-MM-DD HH24:MI:SS''',
'         ) as SUBMIT_TIME,',
'         SUBMISSION_STATUS,',
'         ERROR_MESSAGE',
'  from  WSC_AHCS_COA_SYNC_EXECUTION_HDR_TBL ',
'  order by 1 desc',
'  FETCH FIRST 2 ROWS ONLY'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Sync Process History'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(16420481830209510)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_owner=>'WESCO_DEV_DEVELOPER'
,p_internal_uid=>16420481830209510
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16420550497209511)
,p_db_column_name=>'BATCH_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Batch ID'
,p_column_link=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.::P11_BATCH_ID:#BATCH_ID#'
,p_column_linktext=>'#BATCH_ID#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16420654741209512)
,p_db_column_name=>'SUBMITTED_BY'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Submitted By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16420753131209513)
,p_db_column_name=>'RESET_DATE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Reset Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16421599434209521)
,p_db_column_name=>'SUBMIT_TIME'
,p_display_order=>40
,p_column_identifier=>'E'
,p_column_label=>'Submit Time (EST)'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16421741100209523)
,p_db_column_name=>'ERROR_MESSAGE'
,p_display_order=>50
,p_column_identifier=>'F'
,p_column_label=>'Error Message'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16421893190209524)
,p_db_column_name=>'SUBMISSION_STATUS'
,p_display_order=>60
,p_column_identifier=>'G'
,p_column_label=>'Submission Status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(16547825129076990)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'165479'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BATCH_ID:SUBMITTED_BY:RESET_DATE:SUBMIT_TIME:ERROR_MESSAGE:SUBMISSION_STATUS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16302275230882342)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(9344937842947711)
,p_button_name=>'Refresh'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(29581551877927996815)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Refresh'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9345349243947715)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(9344937842947711)
,p_button_name=>'SYNC'
,p_button_static_id=>'syncButton'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--padTop'
,p_button_template_id=>wwv_flow_api.id(29581551877927996815)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Sync'
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
,p_grid_column=>3
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(9345203798947714)
,p_name=>'RESET_SYNC'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(9344937842947711)
,p_prompt=>'Reset Sync'
,p_display_as=>'NATIVE_DATE_PICKER_JET'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_grid_column=>4
,p_field_template=>wwv_flow_api.id(29581551198252996813)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'By default blank. Provide reset sync date only when last process fails'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16302996916882349)
,p_name=>'P10_COUNT_DATA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(9344937842947711)
,p_item_default=>'0'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16421673782209522)
,p_name=>'P10_LAST_REFRESH'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(9344937842947711)
,p_use_cache_before_default=>'NO'
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT TO_CHAR(',
'           FROM_TZ(LAST_REFRESH_DATE, ''UTC'') AT TIME ZONE ''America/New_York'', ',
'           ''YYYY-MM-DD HH24:MI:SS''',
'         ) || '' EST'' AS EST_LAST_REFRESH_DATE',
'FROM WSC_AHCS_REFRESH_T',
'WHERE DATA_ENTITY_NAME = ''COA_SYNC'';'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Last Refresh'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT TO_CHAR(',
'           FROM_TZ(LAST_REFRESH_DATE, ''UTC'') AT TIME ZONE ''America/New_York'', ',
'           ''YYYY-MM-DD HH24:MI:SS''',
'         ) || '' EST'' AS EST_LAST_REFRESH_DATE',
'FROM WSC_AHCS_REFRESH_T',
'WHERE DATA_ENTITY_NAME = ''COA_SYNC'';'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_css_classes=>'my-custom-font-size'
,p_grid_column=>10
,p_field_template=>wwv_flow_api.id(29581551353425996813)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16421944541209525)
,p_name=>'P10_SYNC_DISABLE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(9344937842947711)
,p_use_cache_before_default=>'NO'
,p_source=>'select count(1) from WSC_AHCS_COA_SYNC_EXECUTION_HDR_TBL where SUBMISSION_STATUS = ''IN_PROGRESS'''
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16782353279100040)
,p_name=>'P10_MAX_DATE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(9344937842947711)
,p_use_cache_before_default=>'NO'
,p_source=>'select to_char(sysdate-3,''DD-MON-YYYY'') from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(16299815334882318)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(9345349243947715)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(16299932628882319)
,p_event_id=>wwv_flow_api.id(16299815334882318)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    cursor cur_count_data(p_reset_date date) is SELECT',
'        COUNT(1)',
'    FROM',
'        wsc_gl_coa_segment_value_t',
'    WHERE',
'        last_update_date >= nvl(p_reset_date,(',
'            SELECT',
'                last_refresh_date',
'            FROM',
'                wsc_ahcs_refresh_t',
'            WHERE',
'                data_entity_name = ''COA_SYNC''',
'        ));',
'',
' lv_batch_id number;',
' lv_reset_date date;',
' lv_count_data number;',
'begin',
'',
'    -- if :RESET_SYNC is null then',
'    --         select LAST_REFRESH_DATE into lv_reset_date from wsc_Ahcs_refresh_t',
'    --         where DATA_ENTITY_NAME = ''COA_SYNC'';',
'    --     else',
'    --         lv_reset_date := :RESET_SYNC;',
'    --     end if;',
'',
'    -- open cur_count_data(lv_reset_date);',
'    -- fetch cur_count_data into lv_count_data;',
'    -- close cur_count_data;',
'    ',
'    open cur_count_data(:RESET_SYNC);',
'    fetch cur_count_data into lv_count_data;',
'    close cur_count_data;',
'    ',
'    -- :P10_COUNT_DATA := lv_count_data;',
'    ',
'    lv_batch_id := WSC_AHCS_COA_SYNC_EXECUTION_BATCH_ID_SEQ.nextval;',
'        ',
'    if  lv_count_data > 0 then ',
'        insert into WSC_AHCS_COA_SYNC_EXECUTION_HDR_TBL (BATCH_ID,',
'            SUBMISSION_STATUS,',
'            SUBMIT_TIME,',
'            USERNAME,',
'            RESET_DATE,',
'            CREATION_DATE,',
'            CREATED_BY,',
'            LAST_UPDATED_BY,',
'            LAST_UPDATE_DATE)',
'            values (lv_batch_id, ''IN_PROGRESS'', sysdate,:P_USER_NAME,:RESET_SYNC,sysdate,:P_USER_NAME,:P_USER_NAME,sysdate);',
'            commit;',
'',
'        dbms_scheduler.create_job (',
'        job_name   =>  ''WSC_AHCS_COA_SYNC_START''||to_char(systimestamp,''ddmonyyyyhh24missff''),',
'        job_type   => ''PLSQL_BLOCK'',',
'        job_action => ',
'            ''BEGIN ',
'                wsc_ahcs_coa_sync_pkg.wsc_ahcs_coa_sync_start(''||lv_batch_id||'',''||''''''''|| :RESET_SYNC||''''''''||'');',
'            END;'',',
'        enabled   =>  TRUE,  ',
'        auto_drop =>  TRUE, ',
'        comments  =>  ''WSC_AHCS_COA_SYNC_START'');',
'',
'            ',
'    else',
'        insert into WSC_AHCS_COA_SYNC_EXECUTION_HDR_TBL (BATCH_ID,',
'            SUBMISSION_STATUS,',
'            SUBMIT_TIME,',
'            USERNAME,',
'            RESET_DATE,',
'            ERROR_MESSAGE,',
'            CREATION_DATE,',
'            CREATED_BY,',
'            LAST_UPDATED_BY,',
'            LAST_UPDATE_DATE)',
'            values (lv_batch_id, ''COMPLETE'', sysdate,:P_USER_NAME,:RESET_SYNC,''No Data To Be Synced'',sysdate,:P_USER_NAME,:P_USER_NAME,sysdate);',
'            commit;',
'        update wsc_ahcS_refresh_t set  last_refresh_date = sysdate where data_entity_name = ''COA_SYNC'';',
'        commit;',
'    -- select count(1) into :P10_SYNC_DISABLE from WSC_AHCS_COA_SYNC_EXECUTION_HDR_TBL where SUBMISSION_STATUS = ''IN_PROGRESS'';',
'    end if;',
'',
'      :RESET_SYNC:= NULL;',
'',
'end;'))
,p_attribute_02=>'RESET_SYNC'
,p_attribute_03=>'RESET_SYNC'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(16300385395882323)
,p_event_id=>wwv_flow_api.id(16299815334882318)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(16300274316882322)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'username varchar2(200) := APEX_UTIL.GET_SESSION_STATE(''USER_NAME'');',
'begin :P_USER_NAME := username; ',
':reset_sync := null;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(16300097372882320)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_user_name varchar2(200);',
'v_jwt_token  varchar2(4000);',
'',
'BEGIN',
'',
'-- APEX_CUSTOM_AUTH.SET_USER(''WESCO_USER'');',
'-- APEX_UTIL.SET_SESSION_STATE(''USER_NAME'',''WESCO_USER'');',
'',
'IF  APEX_UTIL.GET_SESSION_STATE(''USER_NAME'') IS NULL THEN',
'   ',
'  xx_apex_user_security_pkg.main(v_jwt_token,v_user_name,null);  ',
'  ',
'  APEX_UTIL.SET_SESSION_STATE(''USER_NAME'',v_user_name);',
'    APEX_UTIL.SET_SESSION_STATE(''JWT_TOKEN'',v_jwt_token);',
'   ',
'    IF APEX_UTIL.GET_SESSION_STATE(''USER_NAME'') IS NULL THEN',
'        APEX_UTIL.REDIRECT_URL(''f?p=&APP_ID.:9999:&APP_SESSION.'');',
'   ELSE',
'        APEX_CUSTOM_AUTH.SET_USER(APEX_UTIL.GET_SESSION_STATE(''USER_NAME''));',
'        ',
'   END IF;',
'   ',
'ELSE',
'   APEX_CUSTOM_AUTH.SET_USER(APEX_UTIL.GET_SESSION_STATE(''USER_NAME''));  ',
'   ',
'END IF;',
'',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
