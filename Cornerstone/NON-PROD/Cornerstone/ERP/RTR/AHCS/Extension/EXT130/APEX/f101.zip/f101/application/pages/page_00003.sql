prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1701052144005286
,p_default_application_id=>101
,p_default_id_offset=>29579689224955998307
,p_default_owner=>'FININT'
);
wwv_flow_api.create_page(
 p_id=>3
,p_user_interface_id=>wwv_flow_api.id(29581573747695996843)
,p_name=>'COA_MAPPING_UPLOAD'
,p_alias=>'COA-MAPPING-UPLOAD'
,p_page_mode=>'MODAL'
,p_step_title=>'Wesco Code Combination Mapping Value'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_api.id(29581465182976996757)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'650'
,p_dialog_width=>'1200'
,p_page_is_public_y_n=>'Y'
,p_rejoin_existing_sessions=>'Y'
,p_last_updated_by=>'WESCO_UAT_DEVELOPER'
,p_last_upd_yyyymmddhh24miss=>'20230412064426'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(29588078103310974742)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(29581498636133996781)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'	C001 RULE_NAME,',
'	C002 SOURCE_SEGMENT1,',
'	C003 SOURCE_SEGMENT2,',
'	C004 SOURCE_SEGMENT3,',
'	C005 SOURCE_SEGMENT4,',
'	C006 SOURCE_SEGMENT5,',
'	C007 SOURCE_SEGMENT6,',
'	C008 SOURCE_SEGMENT7,',
'	C009 SOURCE_SEGMENT8,',
'	C010 SOURCE_SEGMENT9,',
'	C011 SOURCE_SEGMENT10,',
'	C012 TARGET_SEGMENT,',
'    C013 FLAG',
'FROM APEX_COLLECTIONS C',
'WHERE C.COLLECTION_NAME=''XL1''',
'AND SEQ_ID > 1;'))
,p_plug_source_type=>'NATIVE_IG'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(10384233059799375)
,p_name=>'FLAG'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FLAG'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Flag'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>260
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(17515361109429512772)
,p_name=>'SOURCE_SEGMENT1'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT1'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Source Segment1'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>150
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(17515361262146512773)
,p_name=>'SOURCE_SEGMENT2'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT2'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Source Segment2'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>160
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(17515361344060512774)
,p_name=>'SOURCE_SEGMENT3'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT3'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Source Segment3'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>170
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(17515361426525512775)
,p_name=>'SOURCE_SEGMENT4'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT4'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Source Segment4'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>180
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(17515361586653512776)
,p_name=>'SOURCE_SEGMENT5'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT5'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Source Segment5'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>190
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(17515361667686512777)
,p_name=>'SOURCE_SEGMENT6'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT6'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Source Segment6'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>200
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(17515361789463512778)
,p_name=>'SOURCE_SEGMENT7'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT7'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Source Segment7'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>210
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(17515361867475512779)
,p_name=>'SOURCE_SEGMENT8'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT8'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Source Segment8'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>220
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(17515361915647512780)
,p_name=>'SOURCE_SEGMENT9'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT9'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Source Segment9'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>230
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(17515362073749512781)
,p_name=>'SOURCE_SEGMENT10'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT10'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Source Segment10'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>240
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(17515362140793512782)
,p_name=>'TARGET_SEGMENT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TARGET_SEGMENT'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Target Segment'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>250
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(29588078427722974745)
,p_name=>'RULE_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'RULE_NAME'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Rule Name'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>20
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_interactive_grid(
 p_id=>wwv_flow_api.id(29588078266705974743)
,p_internal_uid=>29584194583551212579
,p_is_editable=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_show_nulls_as=>'-'
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>false
,p_toolbar_buttons=>null
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_api.create_ig_report(
 p_id=>wwv_flow_api.id(29589864200742448970)
,p_interactive_grid_id=>wwv_flow_api.id(29588078266705974743)
,p_static_id=>'120775262'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_api.create_ig_report_view(
 p_id=>wwv_flow_api.id(29589864338598448970)
,p_report_id=>wwv_flow_api.id(29589864200742448970)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(10481502707221628)
,p_view_id=>wwv_flow_api.id(29589864338598448970)
,p_display_seq=>27
,p_column_id=>wwv_flow_api.id(10384233059799375)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(17515396999136517938)
,p_view_id=>wwv_flow_api.id(29589864338598448970)
,p_display_seq=>16
,p_column_id=>wwv_flow_api.id(17515361109429512772)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(17515398347488517940)
,p_view_id=>wwv_flow_api.id(29589864338598448970)
,p_display_seq=>17
,p_column_id=>wwv_flow_api.id(17515361262146512773)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(17515399719624517943)
,p_view_id=>wwv_flow_api.id(29589864338598448970)
,p_display_seq=>18
,p_column_id=>wwv_flow_api.id(17515361344060512774)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(17515401183877517945)
,p_view_id=>wwv_flow_api.id(29589864338598448970)
,p_display_seq=>19
,p_column_id=>wwv_flow_api.id(17515361426525512775)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(17515402594733517948)
,p_view_id=>wwv_flow_api.id(29589864338598448970)
,p_display_seq=>20
,p_column_id=>wwv_flow_api.id(17515361586653512776)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(17515404026694517950)
,p_view_id=>wwv_flow_api.id(29589864338598448970)
,p_display_seq=>21
,p_column_id=>wwv_flow_api.id(17515361667686512777)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(17515405437668517960)
,p_view_id=>wwv_flow_api.id(29589864338598448970)
,p_display_seq=>22
,p_column_id=>wwv_flow_api.id(17515361789463512778)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(17515406834797517963)
,p_view_id=>wwv_flow_api.id(29589864338598448970)
,p_display_seq=>23
,p_column_id=>wwv_flow_api.id(17515361867475512779)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(17515408290175517965)
,p_view_id=>wwv_flow_api.id(29589864338598448970)
,p_display_seq=>24
,p_column_id=>wwv_flow_api.id(17515361915647512780)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(17515409660201517968)
,p_view_id=>wwv_flow_api.id(29589864338598448970)
,p_display_seq=>25
,p_column_id=>wwv_flow_api.id(17515362073749512781)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(17517820596679532594)
,p_view_id=>wwv_flow_api.id(29589864338598448970)
,p_display_seq=>26
,p_column_id=>wwv_flow_api.id(17515362140793512782)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(29589865371554448973)
,p_view_id=>wwv_flow_api.id(29589864338598448970)
,p_display_seq=>2
,p_column_id=>wwv_flow_api.id(29588078427722974745)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(29589821247184839415)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_plug_template=>wwv_flow_api.id(29581509178198996785)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_api.id(29588155676105941086)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(29581532445315996801)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(29589821374845839415)
,p_plug_name=>'Vendor Cost Data Upload'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(29581478301449996770)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(29589821454972839415)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(29581479231267996771)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5555321685660498)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(29589821374845839415)
,p_button_name=>'P3_LOAD'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(29581551877927996815)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Load'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5556444728660500)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(29589821454972839415)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(29581551877927996815)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5556805333660501)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(29589821454972839415)
,p_button_name=>'NEXT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(29581551941619996815)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(5559393021660508)
,p_branch_name=>'Go To Page 4'
,p_branch_action=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(5556805333660501)
,p_branch_sequence=>20
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(5559037100660507)
,p_branch_name=>'Go To Page 3 '
,p_branch_action=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:RP,::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(5556444728660500)
,p_branch_sequence=>30
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5555762576660499)
,p_name=>'P3_BROWSE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(29589821374845839415)
,p_prompt=>'Please select the excel file:'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(29581551353425996813)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'NATIVE'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(5558007826660505)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(5556444728660500)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(5558521368660506)
,p_event_id=>wwv_flow_api.id(5558007826660505)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11026671708215473)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'username varchar2(200) := APEX_UTIL.GET_SESSION_STATE(''USER_NAME'');',
'begin ',
':P_USER_NAME := username; ',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(5557676255660504)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'PLUGIN_NL.AMIS.SCHEFFER.PROCESS.EXCEL2COLLECTION'
,p_process_name=>'ParseItemsDataFromXLSX'
,p_attribute_01=>'P3_BROWSE'
,p_attribute_02=>'XL1'
,p_attribute_03=>'1'
,p_attribute_04=>';'
,p_attribute_05=>'"'
,p_attribute_07=>'Y'
,p_attribute_08=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(5555321685660498)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(5557220449660503)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'LoadParsedItemsData'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    value_id number;',
'    LV_RULE_NAME_CNT number;',
'    V_RULE_NAME_CHECK varchar2(200);',
'    LV_TARGET_SEG_CNT NUMBER;',
'    lv_error_msg varchar2(2000) ;',
'    lv_error varchar2(50)  := ''false'';',
'    V_TARGET_SEG_CHECK number; ',
'    V_DUPLICATE_CHECK number;',
'    count_success number := 0;',
'',
'	CURSOR C1_Y IS',
'		SELECT ',
'			C001 RULE_NAME,',
'			C002 SOURCE_SEGMENT1,',
'			C003 SOURCE_SEGMENT2,',
'			C004 SOURCE_SEGMENT3,',
'			C005 SOURCE_SEGMENT4,',
'			C006 SOURCE_SEGMENT5,',
'			C007 SOURCE_SEGMENT6,',
'			C008 SOURCE_SEGMENT7,',
'			C009 SOURCE_SEGMENT8,',
'			C010 SOURCE_SEGMENT9,',
'			C011 SOURCE_SEGMENT10,',
'			C012 TARGET_SEGMENT,',
'            C013 FLAG',
'		FROM APEX_COLLECTIONS C',
'			WHERE C.COLLECTION_NAME=''XL1''',
'			AND SEQ_ID>1',
'            AND C.C013 = ''Y'';',
'	',
'	CURSOR C1_N IS',
'		SELECT ',
'			C001 RULE_NAME,',
'			C002 SOURCE_SEGMENT1,',
'			C003 SOURCE_SEGMENT2,',
'			C004 SOURCE_SEGMENT3,',
'			C005 SOURCE_SEGMENT4,',
'			C006 SOURCE_SEGMENT5,',
'			C007 SOURCE_SEGMENT6,',
'			C008 SOURCE_SEGMENT7,',
'			C009 SOURCE_SEGMENT8,',
'			C010 SOURCE_SEGMENT9,',
'			C011 SOURCE_SEGMENT10,',
'			C012 TARGET_SEGMENT,',
'            C013 FLAG',
'		FROM APEX_COLLECTIONS C',
'			WHERE C.COLLECTION_NAME=''XL1''',
'			AND SEQ_ID>1',
'            AND C.C013 = ''N'';',
'			',
'	rl_id NUMBER := 999;',
'BEGIN',
'	count_success := 0;',
'    :P_SUCCESS_COUNT := 0;',
'    delete from WSC_GL_CONSOLIDATION_RULE_ERR_T where username = :P_USER_NAME;',
'    commit;',
'	for REC_C1 in C1_N loop',
'   -- count_success := count_success + 1;',
'	/*************************************************************/',
'	value_id := WSC_GL_COA_SAGMENT_VALUE_SEQ.nextval;',
'        ',
'        select WSC_UNIVERSAL_PKG.WSC_COA_VALUE_SEGMENT_EXISTS_RULE_NAME(REC_C1.RULE_NAME) into LV_RULE_NAME_CNT  from dual;',
'       ',
'        IF (LV_RULE_NAME_CNT = 0) ',
'		THEN',
'			lv_error_msg := lv_error_msg || '' -> '' || REC_C1.RULE_NAME || '' :: RULE_NAME value is invalid. Please verify.'';',
'			lv_error := ''True'';',
'        ELSE',
'        	SELECT distinct RULE_NAME,rule_id',
'			INTO V_RULE_NAME_CHECK , rl_id',
'			FROM WSC_GL_COA_MAPPING_RULES_T',
'			WHERE UPPER(RULE_NAME) = UPPER(TRIM(REC_C1.RULE_NAME));',
'        ',
'            -- SELECT distinct rule_id INTO rl_id',
'		    -- FROM WSC_GL_COA_MAPPING_RULES_T',
'		    -- WHERE UPPER(RULE_NAME) = UPPER(TRIM(REC_C1.RULE_NAME));',
'		END IF;',
'        ',
'        if((REC_C1.SOURCE_SEGMENT1 is null)and(REC_C1.SOURCE_SEGMENT2 is null) and (REC_C1.SOURCE_SEGMENT3 is null )and (REC_C1.SOURCE_SEGMENT4 is null) and (REC_C1.SOURCE_SEGMENT5 is null) and (REC_C1.SOURCE_SEGMENT6 is null) and (REC_C1.SOURCE_SEGM'
||'ENT7 is null) and (REC_C1.SOURCE_SEGMENT8 is null) and (REC_C1.SOURCE_SEGMENT9 is null) and (REC_C1.SOURCE_SEGMENT10 is null))',
'            then',
'                lv_error_msg :=  '' Atleast one source segment should have a value.'';',
'                lv_error := ''True'';',
'        end if;',
'		',
'		',
'		if(lv_error =''True'')',
'		then',
'            INSERT INTO WSC_GL_CONSOLIDATION_RULE_ERR_T(RULE_NAME,',
'                RULE_ID,',
'                value_id,',
'                SOURCE_SEGMENT1,',
'                SOURCE_SEGMENT2,',
'                SOURCE_SEGMENT3,',
'                SOURCE_SEGMENT4,',
'                SOURCE_SEGMENT5,',
'                SOURCE_SEGMENT6,',
'                SOURCE_SEGMENT7,',
'                SOURCE_SEGMENT8,',
'                SOURCE_SEGMENT9,',
'                SOURCE_SEGMENT10,',
'                TARGET_SEGMENT,',
'                ERROR_DESC,',
'				USERNAME',
'            )',
'            VALUES(REC_C1.RULE_NAME,',
'                rl_id,',
'                value_id,',
'                REC_C1.SOURCE_SEGMENT1,',
'                REC_C1.SOURCE_SEGMENT2,',
'                REC_C1.SOURCE_SEGMENT3,',
'                REC_C1.SOURCE_SEGMENT4,',
'                REC_C1.SOURCE_SEGMENT5,',
'                REC_C1.SOURCE_SEGMENT6,',
'                REC_C1.SOURCE_SEGMENT7,',
'                REC_C1.SOURCE_SEGMENT8,',
'                REC_C1.SOURCE_SEGMENT9,',
'                REC_C1.SOURCE_SEGMENT10,',
'                REC_C1.TARGET_SEGMENT,',
'                lv_error_msg,',
'				:P_USER_NAME',
'            );',
'            ',
'	else',
'        count_success := count_success + 1;',
'	    UPDATE WSC_GL_COA_SEGMENT_VALUE_T set ',
'		   RULE_NAME = V_RULE_NAME_CHECK,',
'			RULE_ID = rl_id,',
'			value_id = value_id ,',
'			SOURCE_SEGMENT1 = REC_C1.SOURCE_SEGMENT1,',
'			SOURCE_SEGMENT2 = REC_C1.SOURCE_SEGMENT2,',
'			SOURCE_SEGMENT3 = REC_C1.SOURCE_SEGMENT3,',
'			SOURCE_SEGMENT4 = REC_C1.SOURCE_SEGMENT4,',
'			SOURCE_SEGMENT5 = REC_C1.SOURCE_SEGMENT5,',
'			SOURCE_SEGMENT6 = REC_C1.SOURCE_SEGMENT6,',
'			SOURCE_SEGMENT7 = REC_C1.SOURCE_SEGMENT7,',
'			SOURCE_SEGMENT8 = REC_C1.SOURCE_SEGMENT8,',
'			SOURCE_SEGMENT9 = REC_C1.SOURCE_SEGMENT9,',
'			SOURCE_SEGMENT10 = REC_C1.SOURCE_SEGMENT10,',
'			TARGET_SEGMENT = REC_C1.TARGET_SEGMENT,',
'			USER_NAME = :P_USER_NAME,',
'            FLAG =''N'',',
'            created_by = :P_USER_NAME,',
'            last_updated_by = :P_USER_NAME',
'		',
' 		where',
'		((REC_C1.SOURCE_SEGMENT1 is not null and SOURCE_SEGMENT1 = REC_C1.SOURCE_SEGMENT1) OR REC_C1.SOURCE_SEGMENT1 is null) ',
'		AND',
'		((REC_C1.SOURCE_SEGMENT2 is not null and SOURCE_SEGMENT2 = REC_C1.SOURCE_SEGMENT2) OR REC_C1.SOURCE_SEGMENT2 is null)',
'		AND',
'		((REC_C1.SOURCE_SEGMENT3 is not null and SOURCE_SEGMENT3 = REC_C1.SOURCE_SEGMENT3) OR REC_C1.SOURCE_SEGMENT3 is null)',
'		AND',
'		((REC_C1.SOURCE_SEGMENT4 is not null and SOURCE_SEGMENT4 = REC_C1.SOURCE_SEGMENT4) OR REC_C1.SOURCE_SEGMENT4 is null)',
'		AND',
'		((REC_C1.SOURCE_SEGMENT5 is not null and SOURCE_SEGMENT5 = REC_C1.SOURCE_SEGMENT5) OR REC_C1.SOURCE_SEGMENT5 is null)',
'		AND',
'		((REC_C1.SOURCE_SEGMENT6 is not null and SOURCE_SEGMENT6 = REC_C1.SOURCE_SEGMENT6) OR REC_C1.SOURCE_SEGMENT6 is null)',
'		AND',
'		((REC_C1.SOURCE_SEGMENT7 is not null and SOURCE_SEGMENT7 = REC_C1.SOURCE_SEGMENT7) OR REC_C1.SOURCE_SEGMENT7 is null)',
'		AND',
'		((REC_C1.SOURCE_SEGMENT8 is not null and SOURCE_SEGMENT8 = REC_C1.SOURCE_SEGMENT8) OR REC_C1.SOURCE_SEGMENT8 is null)',
'		AND',
'		((REC_C1.SOURCE_SEGMENT9 is not null and SOURCE_SEGMENT9 = REC_C1.SOURCE_SEGMENT9) OR REC_C1.SOURCE_SEGMENT9 is null)',
'		AND',
'		((REC_C1.SOURCE_SEGMENT10 is not null and SOURCE_SEGMENT10 = REC_C1.SOURCE_SEGMENT10) OR REC_C1.SOURCE_SEGMENT10 is null)',
'        AND',
'        (RULE_ID = (select rule_id from WSC_GL_COA_MAPPING_RULES_T where rule_name = REC_C1.RULE_NAME and rownum = 1));',
'        end if; ',
'        lv_error := ''false'';',
'		V_RULE_NAME_CHECK := null;',
'        lv_error_msg := null;',
'	end loop;',
'	for REC_C1 in C1_Y loop ',
'        ',
'		value_id := WSC_GL_COA_SAGMENT_VALUE_SEQ.nextval;',
'        ',
'        select WSC_UNIVERSAL_PKG.WSC_COA_VALUE_SEGMENT_EXISTS_RULE_NAME(REC_C1.RULE_NAME) into LV_RULE_NAME_CNT  from dual;',
'       ',
'        IF (LV_RULE_NAME_CNT = 0) ',
'		THEN',
'			lv_error_msg := lv_error_msg || '' -> '' || REC_C1.RULE_NAME || '' :: RULE_NAME value is invalid. Please verify.'';',
'			lv_error := ''True'';',
'        ELSE',
'        	SELECT distinct RULE_NAME,rule_id',
'			INTO V_RULE_NAME_CHECK , rl_id',
'			FROM WSC_GL_COA_MAPPING_RULES_T',
'			WHERE UPPER(RULE_NAME) = UPPER(TRIM(REC_C1.RULE_NAME));',
'        ',
'            -- SELECT distinct rule_id INTO rl_id',
'		    -- FROM WSC_GL_COA_MAPPING_RULES_T',
'		    -- WHERE UPPER(RULE_NAME) = UPPER(TRIM(REC_C1.RULE_NAME));',
'		END IF;',
'        ',
'        if((REC_C1.SOURCE_SEGMENT1 is null)and(REC_C1.SOURCE_SEGMENT2 is null) and (REC_C1.SOURCE_SEGMENT3 is null )and (REC_C1.SOURCE_SEGMENT4 is null) and (REC_C1.SOURCE_SEGMENT5 is null)',
'            and (REC_C1.SOURCE_SEGMENT6 is null) and (REC_C1.SOURCE_SEGMENT7 is null) and (REC_C1.SOURCE_SEGMENT8 is null) and (REC_C1.SOURCE_SEGMENT9 is null) and (REC_C1.SOURCE_SEGMENT10 is null))',
'            then',
'                lv_error_msg :=  '' Atleast one source segment should have a value.'';',
'                lv_error := ''True'';',
'        end if;',
'		',
'        select WSC_UNIVERSAL_PKG.WSC_COA_VALUE_SEG_IS_NUMBER(REC_C1.TARGET_SEGMENT) into LV_TARGET_SEG_CNT from dual;',
'        IF (LV_TARGET_SEG_CNT = 0) ',
'		THEN',
'			lv_error_msg := lv_error_msg || '' -> '' || REC_C1.TARGET_SEGMENT ||  '' :: TARGET_SEGMENT must have a numeric value.'';',
'			lv_error := ''True'';',
'		END IF;',
'        ',
'      ',
'            select WSC_UNIVERSAL_PKG.WSC_COA_VALUE_SEG_DUPLICATE(REC_C1.RULE_NAME, ',
'                REC_C1.SOURCE_SEGMENT1,',
'                REC_C1.SOURCE_SEGMENT2,',
'                REC_C1.SOURCE_SEGMENT3,',
'                REC_C1.SOURCE_SEGMENT4,',
'                REC_C1.SOURCE_SEGMENT5,',
'                REC_C1.SOURCE_SEGMENT6,',
'                REC_C1.SOURCE_SEGMENT7,',
'                REC_C1.SOURCE_SEGMENT8,',
'                REC_C1.SOURCE_SEGMENT9,',
'                REC_C1.SOURCE_SEGMENT10) into V_DUPLICATE_CHECK from dual;',
'            IF (V_DUPLICATE_CHECK = 1) ',
'		THEN',
'            lv_error_msg :=  ''Duplicate Value is not allowed.'';',
'			lv_error := ''True'';',
'		END IF;',
'        ',
'        if(lv_error =''True'')',
'		then',
'            INSERT INTO WSC_GL_CONSOLIDATION_RULE_ERR_T(RULE_NAME,',
'                RULE_ID,',
'                value_id,',
'                SOURCE_SEGMENT1,',
'                SOURCE_SEGMENT2,',
'                SOURCE_SEGMENT3,',
'                SOURCE_SEGMENT4,',
'                SOURCE_SEGMENT5,',
'                SOURCE_SEGMENT6,',
'                SOURCE_SEGMENT7,',
'                SOURCE_SEGMENT8,',
'                SOURCE_SEGMENT9,',
'                SOURCE_SEGMENT10,',
'                TARGET_SEGMENT,',
'                ERROR_DESC,',
'				USERNAME',
'            )',
'            VALUES(REC_C1.RULE_NAME,',
'                rl_id,',
'                value_id,',
'                REC_C1.SOURCE_SEGMENT1,',
'                REC_C1.SOURCE_SEGMENT2,',
'                REC_C1.SOURCE_SEGMENT3,',
'                REC_C1.SOURCE_SEGMENT4,',
'                REC_C1.SOURCE_SEGMENT5,',
'                REC_C1.SOURCE_SEGMENT6,',
'                REC_C1.SOURCE_SEGMENT7,',
'                REC_C1.SOURCE_SEGMENT8,',
'                REC_C1.SOURCE_SEGMENT9,',
'                REC_C1.SOURCE_SEGMENT10,',
'                REC_C1.TARGET_SEGMENT,',
'                lv_error_msg,',
'				:P_USER_NAME',
'            );',
'            ',
'	else',
'        count_success := count_success + 1;',
'	    INSERT INTO WSC_GL_COA_SEGMENT_VALUE_T(RULE_NAME,',
'			RULE_ID,',
'			value_id,',
'			SOURCE_SEGMENT1,',
'			SOURCE_SEGMENT2,',
'			SOURCE_SEGMENT3,',
'			SOURCE_SEGMENT4,',
'			SOURCE_SEGMENT5,',
'			SOURCE_SEGMENT6,',
'			SOURCE_SEGMENT7,',
'			SOURCE_SEGMENT8,',
'			SOURCE_SEGMENT9,',
'			SOURCE_SEGMENT10,',
'			TARGET_SEGMENT,',
'			USER_NAME,',
'            FLAG,',
'            created_by,',
'            last_updated_by',
'		)',
'		VALUES(V_RULE_NAME_CHECK,',
'			rl_id,',
'			value_id,',
'			trim(REC_C1.SOURCE_SEGMENT1),',
'            trim(REC_C1.SOURCE_SEGMENT2),',
'            trim(REC_C1.SOURCE_SEGMENT3),',
'            trim(REC_C1.SOURCE_SEGMENT4),',
'            trim(REC_C1.SOURCE_SEGMENT5),',
'            trim(REC_C1.SOURCE_SEGMENT6),',
'            trim(REC_C1.SOURCE_SEGMENT7),',
'            trim(REC_C1.SOURCE_SEGMENT8),',
'            trim(REC_C1.SOURCE_SEGMENT9),',
'            trim(REC_C1.SOURCE_SEGMENT10),',
'            trim(REC_C1.TARGET_SEGMENT),',
'            :P_USER_NAME,',
'            REC_C1.FLAG,',
'            :P_USER_NAME,',
'            :P_USER_NAME',
'		);',
'        end if;',
'        lv_error := ''false'';',
'		V_RULE_NAME_CHECK := null;',
'        lv_error_msg := null;',
'	end loop;',
'     :P_SUCCESS_COUNT := count_success;',
'    COMMIT;',
'    	',
'EXCEPTION',
'	WHEN OTHERS THEN',
'      dbms_output.put_line(''error'');  ',
'      commit; ',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
