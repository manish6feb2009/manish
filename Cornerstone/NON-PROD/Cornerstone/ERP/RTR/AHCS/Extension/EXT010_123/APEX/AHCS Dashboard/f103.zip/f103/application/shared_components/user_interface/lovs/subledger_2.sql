prompt --application/shared_components/user_interface/lovs/subledger_2
begin
--   Manifest
--     SUBLEDGER_2
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>1605307059538539
,p_default_application_id=>103
,p_default_id_offset=>2298761677084397
,p_default_owner=>'FININT'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(3444998487117809)
,p_lov_name=>'SUBLEDGER_2'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''EBS AP'' a, ''EBS AP'' b from dual',
'union all',
'select ''EBS AR'' a, ''EBS AR'' b from dual',
'union all',
'select ''EBS FA'' a, ''EBS FA'' b from dual',
'union all',
'select ''ERP POC'' a, ''ERP_POC'' b from dual',
'union all',
'select ''CENTRAL'' a, ''CENTRAL'' b from dual',
'union all',
'select ''MF AP'' a, ''MF AP'' b from dual',
'union all',
'select ''MF AR'' a, ''MF AR'' b from dual',
'union all',
'select ''MF INVENTORY'' a, ''MF INV'' b from dual',
'union all',
'select ''PS FA'' a, ''PS FA'' b from dual',
'union all',
'select ''CLOUDPAY'' a, ''CLOUDPAY'' b from dual',
'union all',
'select ''ECLPS'' a, ''ECLIPSE'' b from dual',
'union all',
'select ''LEASES'' a, ''LEASES'' b from dual',
'union all',
'select ''SXEUS'' a, ''SXE'' b from dual',
'union all',
'select ''APS Treasury'' a, ''TW'' b from dual',
'union all ',
'select ''CONCUR'' a, ''CONCUR'' b from dual ',
'union all ',
'select ''ORACLE LSI'' a,''Oracle LSI'' b from dual'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'B'
,p_display_column_name=>'A'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
);
wwv_flow_api.component_end;
end;
/
