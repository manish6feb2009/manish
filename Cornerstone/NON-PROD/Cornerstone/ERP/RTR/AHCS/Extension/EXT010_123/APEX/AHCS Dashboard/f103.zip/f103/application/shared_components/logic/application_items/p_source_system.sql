prompt --application/shared_components/logic/application_items/p_source_system
begin
--   Manifest
--     APPLICATION ITEM: P_SOURCE_SYSTEM
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>1605307059538539
,p_default_application_id=>103
,p_default_id_offset=>2298761677084397
,p_default_owner=>'FININT'
);
wwv_flow_api.create_flow_item(
 p_id=>wwv_flow_api.id(5648916924926160)
,p_name=>'P_SOURCE_SYSTEM'
,p_protection_level=>'N'
);
wwv_flow_api.component_end;
end;
/
