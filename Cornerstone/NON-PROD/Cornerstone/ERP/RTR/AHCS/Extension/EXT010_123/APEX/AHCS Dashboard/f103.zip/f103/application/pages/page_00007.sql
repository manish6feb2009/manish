prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>1605307059538539
,p_default_application_id=>103
,p_default_id_offset=>2298761677084397
,p_default_owner=>'FININT'
);
wwv_flow_api.create_page(
 p_id=>7
,p_user_interface_id=>wwv_flow_api.id(8554886317286990)
,p_name=>'IMP_ACC_ERROR'
,p_alias=>'IMP-ACC-ERROR'
,p_step_title=>'IMP_ACC_ERROR'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_last_updated_by=>'nobody'
,p_last_upd_yyyymmddhh24miss=>'20230821092157'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4521354152313931)
,p_plug_name=>'IMP_Error'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(8463467211286747)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- SELECT ',
'--   ''D'' RECORD_TYPE, ',
'-- --   TO_CHAR(S.INTERFACE_ID) INTERFACE_ID,',
'--   decode(S.INTERFACE_ID,''SALE'',''SII'',''CASH'',''CRI'',''LSIR'',''LSI'',',
'--   ''SPER'',''SPR'',''ARIN'',''ARI'',''IFRT'',''FII'',''COQI'',''CQI'',''OFRT'',''FTI'',',
'--   ''INTR'',''ICI'',''INVT'',''ISI'',''SPEC'',''SPC'',substr(S.INTERFACE_ID,1,3)) ',
'--     INTERFACE_ID,',
'--   TO_CHAR(',
'--     LPAD(S.LEGACY_HEADER_ID, 9, 0)',
'--   ) HEADER_ID, ',
'--   TO_CHAR(S.LEGACY_LINE_NUMBER) LINE_NUMBER, ',
'--   ''303'' ERROR_CODE, ',
'--   TO_CHAR(S.ATTRIBUTE3) TRANSACTION_NUMBER, ',
'--   TO_CHAR(S.COMPANY_NUM) COMPANY_NUMBER, ',
'--   TO_CHAR(S.PAY_CODE) PAYCODE, ',
'--   TO_CHAR(S.GL_CODE) ACCOUNT_NUMBER, ',
'--   TO_CHAR(S.DR) AMOUNT, ',
'--   TO_CHAR(',
'--     S.ATTRIBUTE11, ',
'--     ''YYYY-MM-DD''',
'--   ) TRANSACTION_DATE, ',
'--   CONCAT(',
'--     ''IMPORT_ACC_ERROR-'', ',
'--     TO_CHAR(C.IMPORT_ACC_ID)',
'--   ) ERROR_MESSAGE, ',
'--   TO_CHAR(S.LEDGER_NAME) LEDGER_NAME ',
'-- FROM ',
'--   WSC_AHCS_INT_STATUS_T S, ',
'--   WSC_AHCS_INT_CONTROL_LINE_T C ',
'-- WHERE ',
'--   S.batch_id = :BATCH_ID',
'--   and S.accounting_status = ''IMP_ACC_ERROR'' ',
'--   and (',
'--     S.INTERFACE_ID IN (',
'--       ''APIN'', ''ARIN'', ''AQIN'', ''ADIN'', ''CAIN'', ',
'--       ''LSIP'', ''LSIR'', ''CASH'', ''SALE'', ''SPER'', ',
'--       ''AIIB'', ''COQI'', ''DAIN'', ''IBIN'', ''IFRT'', ',
'--       ''INTR'', ''INVT'', ''IRIN'', ''OFRT'', ''SPEC'', ',
'--       ''BKIN''',
'--     ) ',
'--     or S.APPLICATION = ''PS FA''',
'--   ) ',
'--   AND C.GROUP_ID = S.GROUP_ID ',
'--   AND C.BATCH_ID = S.BATCH_ID ',
'--   AND C.LEDGER_NAME = S.LEDGER_NAME ',
'-- union all ',
'-- SELECT ',
'--   ''D'', ',
'-- --   TO_CHAR(S.INTERFACE_ID), ',
'--   decode(S.INTERFACE_ID,''SALE'',''SII'',''CASH'',''CRI'',''LSIR'',''LSI'',',
'--   ''SPER'',''SPR'',''ARIN'',''ARI'',''IFRT'',''FII'',''COQI'',''CQI'',''OFRT'',''FTI'',',
'--   ''INTR'',''ICI'',''INVT'',''ISI'',''SPEC'',''SPC'',substr(S.INTERFACE_ID,1,3)) ',
'--     INTERFACE_ID,',
'--   TO_CHAR(',
'--     LPAD(S.LEGACY_HEADER_ID, 9, 0)',
'--   ), ',
'--   TO_CHAR(S.LEGACY_LINE_NUMBER), ',
'--   ''303'', ',
'--   TO_CHAR(S.ATTRIBUTE3), ',
'--   TO_CHAR(S.COMPANY_NUM), ',
'--   TO_CHAR(S.PAY_CODE), ',
'--   TO_CHAR(S.GL_CODE), ',
'--   TO_CHAR(S.DR), ',
'--   TO_CHAR(',
'--     S.ATTRIBUTE11, ',
'--     ''YYYY-MM-DD''',
'--   ), ',
'--   CONCAT(',
'--     ''IMPORT_ACC_ERROR-'', ',
'--     TO_CHAR(C.IMPORT_ACC_ID)',
'--   ), ',
'--   TO_CHAR(S.LEDGER_NAME) ',
'-- FROM ',
'--   WSC_AHCS_INT_STATUS_T S, ',
'--   WSC_AHCS_INT_CONTROL_T C ',
'-- WHERE ',
'--   S.batch_id =  :BATCH_ID',
'--   and S.accounting_status = ''IMP_ACC_ERROR'' ',
'--   and S.APPLICATION IN (',
'--     ''CLOUDPAY'', ''ECLIPSE'', ''SXE'', ''LEASES'', ''CONCUR'',',
'--     ''TW''',
'--   ) ',
'--   AND C.BATCH_ID = S.BATCH_ID',
'',
'--   UNION ALL ',
'-- SELECT ',
'--   DISTINCT ''H'', ',
'--   decode(S.INTERFACE_ID,''SALE'',''SII'',''CASH'',''CRI'',''LSIR'',''LSI'',',
'--   ''SPER'',''SPR'',''ARIN'',''ARI'',''IFRT'',''FII'',''COQI'',''CQI'',''OFRT'',''FTI'',',
'--   ''INTR'',''ICI'',''INVT'',''ISI'',''SPEC'',''SPC'',substr(S.INTERFACE_ID,1,3)) ',
'--     INTERFACE_ID,',
'--   TO_CHAR(',
'--     LPAD(S.LEGACY_HEADER_ID, 9, 0)',
'--   ), ',
'--   NULL, ',
'--   ''303'', ',
'--   TO_CHAR(S.ATTRIBUTE3), ',
'--   TO_CHAR(S.COMPANY_NUM), ',
'--   TO_CHAR(S.PAY_CODE), ',
'--   TO_CHAR(S.GL_CODE), ',
'--   NULL, ',
'--   TO_CHAR(',
'--     S.ATTRIBUTE11, ',
'--     ''YYYY-MM-DD''',
'--   ) TRANSACTION_DATE, ',
'--   CONCAT(',
'--     ''IMPORT_ACC_ERROR-'', ',
'--     TO_CHAR(C.IMPORT_ACC_ID)',
'--   ), ',
'--   TO_CHAR(S.LEDGER_NAME) ',
'-- FROM ',
'--   WSC_AHCS_INT_STATUS_T S, ',
'--   WSC_AHCS_INT_CONTROL_LINE_T C ',
'-- WHERE ',
'--   S.batch_id = : batch_id ',
'--   and S.accounting_status = ''IMP_ACC_ERROR'' ',
'--   and (',
'--     S.INTERFACE_ID IN (',
'--       ''APIN'', ''ARIN'', ''AQIN'', ''ADIN'', ''CAIN'', ',
'--       ''LSIP'', ''LSIR'', ''CASH'', ''SALE'', ''SPER'', ',
'--       ''AIIB'', ''COQI'', ''DAIN'', ''IBIN'', ''IFRT'', ',
'--       ''INTR'', ''INVT'', ''IRIN'', ''OFRT'', ''SPEC'', ',
'--       ''BKIN''',
'--     ) ',
'--     or S.APPLICATION = ''PS FA''',
'--   ) ',
'--   AND C.GROUP_ID = S.GROUP_ID ',
'--   AND C.BATCH_ID = S.BATCH_ID ',
'--   AND C.LEDGER_NAME = S.LEDGER_NAME ',
'-- UNION ALL ',
'-- SELECT ',
'--   DISTINCT ''H'', ',
'--   decode(S.INTERFACE_ID,''SALE'',''SII'',''CASH'',''CRI'',''LSIR'',''LSI'',',
'--   ''SPER'',''SPR'',''ARIN'',''ARI'',''IFRT'',''FII'',''COQI'',''CQI'',''OFRT'',''FTI'',',
'--   ''INTR'',''ICI'',''INVT'',''ISI'',''SPEC'',''SPC'',substr(S.INTERFACE_ID,1,3)) ',
'--     INTERFACE_ID,',
'--   TO_CHAR(',
'--     LPAD(S.LEGACY_HEADER_ID, 9, 0)',
'--   ), ',
'--   NULL, ',
'--   ''303'', ',
'--   TO_CHAR(S.ATTRIBUTE3), ',
'--   TO_CHAR(S.COMPANY_NUM), ',
'--   TO_CHAR(S.PAY_CODE), ',
'--   TO_CHAR(S.GL_CODE), ',
'--   NULL, ',
'--   TO_CHAR(',
'--     S.ATTRIBUTE11, ',
'--     ''YYYY-MM-DD''',
'--   ) TRANSACTION_DATE, ',
'--   CONCAT(',
'--     ''IMPORT_ACC_ERROR-'', ',
'--     TO_CHAR(C.IMPORT_ACC_ID)',
'--   ), ',
'--   TO_CHAR(S.LEDGER_NAME) ',
'-- FROM ',
'--   WSC_AHCS_INT_STATUS_T S, ',
'--   WSC_AHCS_INT_CONTROL_T C ',
'-- WHERE ',
'--   S.batch_id = : batch_id ',
'--   and S.accounting_status = ''IMP_ACC_ERROR'' ',
'--   and S.APPLICATION IN (',
'--     ''CLOUDPAY'', ''ECLIPSE'', ''SXE'', ''LEASES'', ',
'--     ''TW'', ''CONCUR''',
'--   ) ',
'--   AND C.BATCH_ID = S.BATCH_ID',
'',
'',
'',
'',
'',
'',
'',
'select * from (SELECT ',
'      * ',
'    FROM (',
'',
'SELECT ',
'  ''D'' RECORD_TYPE, ',
'--   TO_CHAR(S.INTERFACE_ID) INTERFACE_ID,',
'  decode(S.INTERFACE_ID,''SALE'',''SII'',''CASH'',''CRI'',''LSIR'',''LSI'',',
'  ''SPER'',''SPR'',''ARIN'',''ARI'',''IFRT'',''FII'',''COQI'',''CQI'',''OFRT'',''FTI'',',
'  ''INTR'',''ICI'',''INVT'',''ISI'',''SPEC'',''SPC'',substr(S.INTERFACE_ID,1,3)) ',
'    INTERFACE_ID,',
'  TO_CHAR(',
'    LPAD(S.LEGACY_HEADER_ID, 9, 0)',
'  ) HEADER_ID, ',
'  TO_CHAR(S.LEGACY_LINE_NUMBER) LINE_NUMBER, ',
'  ''303'' ERROR_CODE, ',
'  TO_CHAR(S.ATTRIBUTE3) TRANSACTION_NUMBER, ',
'  TO_CHAR(S.COMPANY_NUM) COMPANY_NUMBER, ',
'  TO_CHAR(S.PAY_CODE) PAYCODE, ',
'  TO_CHAR(S.GL_CODE) ACCOUNT_NUMBER, ',
'  TO_CHAR(S.DR) AMOUNT, ',
'  TO_CHAR(',
'    S.ATTRIBUTE11, ',
'    ''YYYY-MM-DD''',
'  ) TRANSACTION_DATE, ',
'  CONCAT(',
'    ''IMPORT_ACC_ERROR-'', ',
'    TO_CHAR(C.IMPORT_ACC_ID)',
'  ) ERROR_MESSAGE, ',
'  TO_CHAR(S.LEDGER_NAME) LEDGER_NAME ',
'FROM ',
'  WSC_AHCS_INT_STATUS_T S, ',
'  WSC_AHCS_INT_CONTROL_LINE_T C ',
'WHERE ',
'  S.batch_id = :BATCH_ID',
'  and S.accounting_status = ''IMP_ACC_ERROR'' ',
'  and (',
'    S.INTERFACE_ID IN (',
'      ''APIN'', ''ARIN'', ''AQIN'', ''ADIN'', ''CAIN'', ',
'      ''LSIP'', ''LSIR'', ''CASH'', ''SALE'', ''SPER'', ',
'      ''AIIB'', ''COQI'', ''DAIN'', ''IBIN'', ''IFRT'', ',
'      ''INTR'', ''INVT'', ''IRIN'', ''OFRT'', ''SPEC'', ',
'      ''BKIN'', ''JTI''',
'    ) ',
'    or S.APPLICATION in (''LEASES'',''CONCUR'')',
'  ) ',
'  AND C.GROUP_ID = S.GROUP_ID ',
'  AND C.BATCH_ID = S.BATCH_ID ',
'  AND C.LEDGER_NAME = S.LEDGER_NAME ',
'union all ',
'SELECT ',
'  ''D'', ',
'--   TO_CHAR(S.INTERFACE_ID), ',
'  decode(S.INTERFACE_ID,''SALE'',''SII'',''CASH'',''CRI'',''LSIR'',''LSI'',',
'  ''SPER'',''SPR'',''ARIN'',''ARI'',''IFRT'',''FII'',''COQI'',''CQI'',''OFRT'',''FTI'',',
'  ''INTR'',''ICI'',''INVT'',''ISI'',''SPEC'',''SPC'',substr(S.INTERFACE_ID,1,3)) ',
'    INTERFACE_ID,',
'  TO_CHAR(',
'    LPAD(S.LEGACY_HEADER_ID, 9, 0)',
'  ), ',
'  TO_CHAR(S.LEGACY_LINE_NUMBER), ',
'  ''303'', ',
'  TO_CHAR(S.ATTRIBUTE3), ',
'  TO_CHAR(S.COMPANY_NUM), ',
'  TO_CHAR(S.PAY_CODE), ',
'  TO_CHAR(S.GL_CODE), ',
'  TO_CHAR(S.DR), ',
'  TO_CHAR(',
'    S.ATTRIBUTE11, ',
'    ''YYYY-MM-DD''',
'  ), ',
'  CONCAT(',
'    ''IMPORT_ACC_ERROR-'', ',
'    TO_CHAR(C.IMPORT_ACC_ID)',
'  ), ',
'  TO_CHAR(S.LEDGER_NAME) ',
'FROM ',
'  WSC_AHCS_INT_STATUS_T S, ',
'  WSC_AHCS_INT_CONTROL_T C ',
'WHERE ',
'  S.batch_id =  :BATCH_ID',
'  and S.accounting_status = ''IMP_ACC_ERROR'' ',
'  and S.APPLICATION IN (',
'    ''CLOUDPAY'', ''ECLIPSE'', ''SXE'', ''PS FA'',',
'    ''TW''',
'  ) ',
'  AND C.BATCH_ID = S.BATCH_ID',
'',
'  UNION ALL ',
'SELECT ',
'  DISTINCT ''H'', ',
'  decode(S.INTERFACE_ID,''SALE'',''SII'',''CASH'',''CRI'',''LSIR'',''LSI'',',
'  ''SPER'',''SPR'',''ARIN'',''ARI'',''IFRT'',''FII'',''COQI'',''CQI'',''OFRT'',''FTI'',',
'  ''INTR'',''ICI'',''INVT'',''ISI'',''SPEC'',''SPC'',substr(S.INTERFACE_ID,1,3)) ',
'    INTERFACE_ID,',
'  TO_CHAR(',
'    LPAD(S.LEGACY_HEADER_ID, 9, 0)',
'  ), ',
'  NULL, ',
'  ''303'', ',
'  TO_CHAR(S.ATTRIBUTE3), ',
'  TO_CHAR(S.COMPANY_NUM), ',
'  TO_CHAR(S.PAY_CODE), ',
'  TO_CHAR(S.GL_CODE), ',
'  NULL, ',
'  TO_CHAR(',
'    S.ATTRIBUTE11, ',
'    ''YYYY-MM-DD''',
'  ) TRANSACTION_DATE, ',
'  CONCAT(',
'    ''IMPORT_ACC_ERROR-'', ',
'    TO_CHAR(C.IMPORT_ACC_ID)',
'  ), ',
'  TO_CHAR(S.LEDGER_NAME) ',
'FROM ',
'  WSC_AHCS_INT_STATUS_T S, ',
'  WSC_AHCS_INT_CONTROL_LINE_T C ',
'WHERE ',
'  S.batch_id = : batch_id ',
'  and S.accounting_status = ''IMP_ACC_ERROR'' ',
'  and (',
'    S.INTERFACE_ID IN (',
'      ''APIN'', ''ARIN'', ''AQIN'', ''ADIN'', ''CAIN'', ',
'      ''LSIP'', ''LSIR'', ''CASH'', ''SALE'', ''SPER'', ',
'      ''AIIB'', ''COQI'', ''DAIN'', ''IBIN'', ''IFRT'', ',
'      ''INTR'', ''INVT'', ''IRIN'', ''OFRT'', ''SPEC'', ',
'      ''BKIN'', ''JTI''',
'    ) ',
'    or S.APPLICATION in (''LEASES'',''CONCUR'')',
'  ) ',
'  AND C.GROUP_ID = S.GROUP_ID ',
'  AND C.BATCH_ID = S.BATCH_ID ',
'  AND C.LEDGER_NAME = S.LEDGER_NAME ',
'UNION ALL ',
'SELECT ',
'  DISTINCT ''H'', ',
'  decode(S.INTERFACE_ID,''SALE'',''SII'',''CASH'',''CRI'',''LSIR'',''LSI'',',
'  ''SPER'',''SPR'',''ARIN'',''ARI'',''IFRT'',''FII'',''COQI'',''CQI'',''OFRT'',''FTI'',',
'  ''INTR'',''ICI'',''INVT'',''ISI'',''SPEC'',''SPC'',substr(S.INTERFACE_ID,1,3)) ',
'    INTERFACE_ID,',
'  TO_CHAR(',
'    LPAD(S.LEGACY_HEADER_ID, 9, 0)',
'  ), ',
'  NULL, ',
'  ''303'', ',
'  TO_CHAR(S.ATTRIBUTE3), ',
'  TO_CHAR(S.COMPANY_NUM), ',
'  TO_CHAR(S.PAY_CODE), ',
'  TO_CHAR(S.GL_CODE), ',
'  NULL, ',
'  TO_CHAR(',
'    S.ATTRIBUTE11, ',
'    ''YYYY-MM-DD''',
'  ) TRANSACTION_DATE, ',
'  CONCAT(',
'    ''IMPORT_ACC_ERROR-'', ',
'    TO_CHAR(C.IMPORT_ACC_ID)',
'  ), ',
'  TO_CHAR(S.LEDGER_NAME) ',
'FROM ',
'  WSC_AHCS_INT_STATUS_T S, ',
'  WSC_AHCS_INT_CONTROL_T C ',
'WHERE ',
'  S.batch_id = :batch_id ',
'  and S.accounting_status = ''IMP_ACC_ERROR'' ',
'  and S.APPLICATION IN (',
'    ''CLOUDPAY'', ''ECLIPSE'', ''SXE'', ',
'    ''TW'', ''PS FA''',
'  ) ',
'  AND C.BATCH_ID = S.BATCH_ID',
')',
'ORDER BY ',
'      ',
'      HEADER_ID, ',
'RECORD_TYPE DESC',
',',
'      to_number(LINE_NUMBER)',
'      )'))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'BATCH_ID'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'IMP_Error'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(4521572043313933)
,p_name=>'RECORD_TYPE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'RECORD_TYPE'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Record Type'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>10
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>1
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(4521635232313934)
,p_name=>'INTERFACE_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'INTERFACE_ID'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Interface Id'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>20
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>12
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(4521764207313935)
,p_name=>'HEADER_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'HEADER_ID'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Header Id'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>36
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(4521893280313936)
,p_name=>'LINE_NUMBER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LINE_NUMBER'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Line Number'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>40
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(4521993633313937)
,p_name=>'ERROR_CODE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ERROR_CODE'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Error Code'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>3
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(4522089189313938)
,p_name=>'TRANSACTION_NUMBER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TRANSACTION_NUMBER'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Transaction Number'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>200
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(4522135218313939)
,p_name=>'COMPANY_NUMBER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COMPANY_NUMBER'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Company Number'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>15
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(4522282869313940)
,p_name=>'PAYCODE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PAYCODE'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Paycode'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>80
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>30
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(4522315661313941)
,p_name=>'ACCOUNT_NUMBER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ACCOUNT_NUMBER'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Account Number'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>30
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(4522407691313942)
,p_name=>'AMOUNT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'AMOUNT'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Amount'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>100
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>40
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(4522527928313943)
,p_name=>'TRANSACTION_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TRANSACTION_DATE'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Transaction Date'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>110
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>10
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(4522614401313944)
,p_name=>'ERROR_MESSAGE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ERROR_MESSAGE'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Error Message'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>120
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>817
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(4522717415313945)
,p_name=>'LEDGER_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LEDGER_NAME'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Ledger Name'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>130
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>50
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_interactive_grid(
 p_id=>wwv_flow_api.id(4521418165313932)
,p_internal_uid=>4521418165313932
,p_is_editable=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_api.create_ig_report(
 p_id=>wwv_flow_api.id(5152370606472035)
,p_interactive_grid_id=>wwv_flow_api.id(4521418165313932)
,p_static_id=>'51524'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_api.create_ig_report_view(
 p_id=>wwv_flow_api.id(5152578478472035)
,p_report_id=>wwv_flow_api.id(5152370606472035)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(5153008419472037)
,p_view_id=>wwv_flow_api.id(5152578478472035)
,p_display_seq=>1
,p_column_id=>wwv_flow_api.id(4521572043313933)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(5153908371472040)
,p_view_id=>wwv_flow_api.id(5152578478472035)
,p_display_seq=>2
,p_column_id=>wwv_flow_api.id(4521635232313934)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(5154851980472044)
,p_view_id=>wwv_flow_api.id(5152578478472035)
,p_display_seq=>3
,p_column_id=>wwv_flow_api.id(4521764207313935)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(5155702998472047)
,p_view_id=>wwv_flow_api.id(5152578478472035)
,p_display_seq=>4
,p_column_id=>wwv_flow_api.id(4521893280313936)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(5156604002472051)
,p_view_id=>wwv_flow_api.id(5152578478472035)
,p_display_seq=>5
,p_column_id=>wwv_flow_api.id(4521993633313937)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(5157556602472054)
,p_view_id=>wwv_flow_api.id(5152578478472035)
,p_display_seq=>6
,p_column_id=>wwv_flow_api.id(4522089189313938)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>134.5156
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(5158405825472058)
,p_view_id=>wwv_flow_api.id(5152578478472035)
,p_display_seq=>7
,p_column_id=>wwv_flow_api.id(4522135218313939)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(5159329371472062)
,p_view_id=>wwv_flow_api.id(5152578478472035)
,p_display_seq=>8
,p_column_id=>wwv_flow_api.id(4522282869313940)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(5160257025472066)
,p_view_id=>wwv_flow_api.id(5152578478472035)
,p_display_seq=>9
,p_column_id=>wwv_flow_api.id(4522315661313941)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(5161157916472071)
,p_view_id=>wwv_flow_api.id(5152578478472035)
,p_display_seq=>10
,p_column_id=>wwv_flow_api.id(4522407691313942)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(5162088391472075)
,p_view_id=>wwv_flow_api.id(5152578478472035)
,p_display_seq=>11
,p_column_id=>wwv_flow_api.id(4522527928313943)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(5162966147472079)
,p_view_id=>wwv_flow_api.id(5152578478472035)
,p_display_seq=>12
,p_column_id=>wwv_flow_api.id(4522614401313944)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(5163825435472084)
,p_view_id=>wwv_flow_api.id(5152578478472035)
,p_display_seq=>13
,p_column_id=>wwv_flow_api.id(4522717415313945)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(4522823796313946)
,p_name=>'BATCH_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(4521354152313931)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.component_end;
end;
/
