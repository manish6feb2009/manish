prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>1605307059538539
,p_default_application_id=>103
,p_default_id_offset=>2298761677084397
,p_default_owner=>'FININT'
);
wwv_flow_api.create_page(
 p_id=>4
,p_user_interface_id=>wwv_flow_api.id(8554886317286990)
,p_name=>'DASHBOARD 2'
,p_alias=>'AHCS-DASHBOARD-D2'
,p_step_title=>'Subledger Level Processing View'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_browser_cache=>'N'
,p_last_updated_by=>'nobody'
,p_last_upd_yyyymmddhh24miss=>'20231011121520'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7006516325431223)
,p_plug_name=>'Parameters'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(8465443656286755)
,p_plug_display_sequence=>20
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10719081466405342)
,p_plug_name=>'Subledger Level Processing View'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(8465443656286755)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(11268978744701041)
,p_plug_name=>'New1'
,p_parent_plug_id=>wwv_flow_api.id(10719081466405342)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(8463467211286747)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NVL(B.AHCS_APPLICATION_NAME,A.APPLICATION) APPLICATION,',
'       A.ACCOUNTING_PERIOD,',
'       A.INTERFACE_PROC_STATUS,',
'       A.CREATE_ACC_STATUS,',
'       A.TOTAL_CR,',
'       A.TOTAL_DR,',
'       A.NUM_ROWS,',
'       decode(A.DUMMY,''none'',''none'',''apg'') DUMMY1,',
'       A.DUMMY,',
'       A.DUMMY4,',
'       decode(A.CREATE_ACC_STATUS,''Import Pending'',''Download'',''Import Error'',''Download'',null) IMPORT_DOWNLOAD,',
'       to_char(trunc(last_day(to_date(A.ACCOUNTING_PERIOD,''MON-YY''))-1, ''mm''),''MM-DD-YYYY'') FIRST_DAY,',
'       to_char(last_day(to_date(A.ACCOUNTING_PERIOD,''MON-YY'')),''MM-DD-YYYY'') LAST_DAY',
'  from WSC_AHCS_DASHBOARD2_T A FULL OUTER JOIN WSC_AHCS_INT_AHCS_SOURCES_LKP_T B ON A.application = B.LEAGACY_APPLICATION_NAME',
'   where APPLICATION = NVL(:SUBLEDGER, APPLICATION) AND INTERFACE_PROC_STATUS = NVL(:INTERFACE_PROCESSING_STATUS, INTERFACE_PROC_STATUS)',
'AND NVL(CREATE_ACC_STATUS,1) =NVL(NVL(:CREATE_ACCOUNTING_STATUS, CREATE_ACC_STATUS),1) and NVL(ACCOUNTING_PERIOD,1)=NVL(NVL(:ACCOUNTING_PERIOD,ACCOUNTING_PERIOD),1)'))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'SUBLEDGER,INTERFACE_PROCESSING_STATUS,CREATE_ACCOUNTING_STATUS,ACCOUNTING_PERIOD'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'New1'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_footer=>'<b>Notes : </b>Amount is shown in Entered Currency for Leases, CloudPay and Concur. <br>Skipped Records are applicable for Central, CloudPay and Concur, check Lean spec for details.'
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(2355248544840907)
,p_name=>'DUMMY1'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DUMMY1'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>130
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(2547696432288501)
,p_name=>'APEX$ROW_ACTION'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>30
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(2547725710288502)
,p_name=>'APEX$ROW_SELECTOR'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>20
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(3243301405057801)
,p_name=>'DUMMY4'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DUMMY4'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_LINK'
,p_heading=>'CA Error Download'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>140
,p_value_alignment=>'CENTER'
,p_link_target=>'&P_URL./Custom/WESCO+Custom/AHCS/Reports/Wesco_GBL_AHCS_RPT006_Error_Report.xdo?_xmode=4&P_Application=&APPLICATION.&P_Acc_Date_From=&FIRST_DAY.&P_Acc_Date_To=&LAST_DAY.&P_Ledger=Global%20Primary%20LS&P_Error=Y'
,p_link_text=>'Download'
,p_link_attributes=>'style="display:&DUMMY4.;"target="_blank"'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_escape_on_http_output=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(3243412663057802)
,p_name=>'FIRST_DAY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FIRST_DAY'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>150
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(3243566045057803)
,p_name=>'LAST_DAY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LAST_DAY'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>160
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(3507969559286810)
,p_name=>'APPLICATION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'APPLICATION'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Application'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>180
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>200
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(7372877657194428)
,p_name=>'IMPORT_DOWNLOAD'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'IMPORT_DOWNLOAD'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_LINK'
,p_heading=>'Import Error / Pending Download'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>170
,p_value_alignment=>'LEFT'
,p_link_target=>'f?p=&APP_ID.:4:&SESSION.:APPLICATION_PROCESS=WSC_AHCS_DASHBOARD_IMPORT_ERROR:&DEBUG.:CR,:P_SUBLEDGER,P_ACC_STATUS,P_ACCOUNTING_PERIOD,P_SOURCE_SYSTEM:&APPLICATION.,&CREATE_ACC_STATUS.,&ACCOUNTING_PERIOD.,&SOURCE_SYSTEM.'
,p_link_text=>'&IMPORT_DOWNLOAD.'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_escape_on_http_output=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(11269302170701044)
,p_name=>'ACCOUNTING_PERIOD'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ACCOUNTING_PERIOD'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Accounting Period'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>15
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(11269452812701045)
,p_name=>'INTERFACE_PROC_STATUS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'INTERFACE_PROC_STATUS'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Interface Processing Status'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>200
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(11269514727701046)
,p_name=>'CREATE_ACC_STATUS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CREATE_ACC_STATUS'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Create Accounting Status'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>100
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(11269643696701047)
,p_name=>'TOTAL_CR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TOTAL_CR'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Total Credit'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>80
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'right'
,p_format_mask=>'999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(11481657553112798)
,p_name=>'TOTAL_DR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TOTAL_DR'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Total Debit'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>90
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'right'
,p_format_mask=>'999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(11481740730112799)
,p_name=>'NUM_ROWS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NUM_ROWS'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Number of Lines'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>100
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'right'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(11481761940112800)
,p_name=>'DUMMY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DUMMY'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>110
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(11482210111112804)
,p_name=>'DUMMY2'
,p_source_type=>'NONE'
,p_item_type=>'NATIVE_LINK'
,p_heading=>'OIC Error Download'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>120
,p_value_alignment=>'CENTER'
,p_link_target=>'f?p=&APP_ID.:4:&SESSION.:APPLICATION_PROCESS=WSC_AHCS_DASHBOARD_ERROR:&DEBUG.:CR,:P_SUBLEDGER,P_STATUS,P_ACC_STATUS,P_ACCOUNTING_PERIOD,P_SOURCE_SYSTEM:&APPLICATION.,&INTERFACE_PROC_STATUS.,&CREATE_ACC_STATUS.,&ACCOUNTING_PERIOD.,&SOURCE_SYSTEM.'
,p_link_text=>'Download'
,p_link_attributes=>'style="display:&DUMMY1.;"'
,p_use_as_row_header=>false
,p_enable_hide=>true
,p_escape_on_http_output=>true
);
wwv_flow_api.create_interactive_grid(
 p_id=>wwv_flow_api.id(11269107088701042)
,p_internal_uid=>8970345411616645
,p_is_editable=>true
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SET'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_toolbar_buttons=>'SEARCH_COLUMN:SEARCH_FIELD:ACTIONS_MENU:SAVE'
,p_enable_save_public_report=>true
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_api.create_ig_report(
 p_id=>wwv_flow_api.id(11487204488113259)
,p_interactive_grid_id=>wwv_flow_api.id(11269107088701042)
,p_static_id=>'91885'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_api.create_ig_report_view(
 p_id=>wwv_flow_api.id(11487397849113260)
,p_report_id=>wwv_flow_api.id(11487204488113259)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(2554185778288980)
,p_view_id=>wwv_flow_api.id(11487397849113260)
,p_display_seq=>0
,p_column_id=>wwv_flow_api.id(2547696432288501)
,p_is_visible=>true
,p_is_frozen=>true
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(2791572953684632)
,p_view_id=>wwv_flow_api.id(11487397849113260)
,p_display_seq=>10
,p_column_id=>wwv_flow_api.id(2355248544840907)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(3249490244065599)
,p_view_id=>wwv_flow_api.id(11487397849113260)
,p_display_seq=>11
,p_column_id=>wwv_flow_api.id(3243301405057801)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>180
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(3250380042065607)
,p_view_id=>wwv_flow_api.id(11487397849113260)
,p_display_seq=>12
,p_column_id=>wwv_flow_api.id(3243412663057802)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(3251255026065611)
,p_view_id=>wwv_flow_api.id(11487397849113260)
,p_display_seq=>13
,p_column_id=>wwv_flow_api.id(3243566045057803)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(3896300066820151)
,p_view_id=>wwv_flow_api.id(11487397849113260)
,p_display_seq=>1
,p_column_id=>wwv_flow_api.id(3507969559286810)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>83
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(7581769254533750)
,p_view_id=>wwv_flow_api.id(11487397849113260)
,p_display_seq=>14
,p_column_id=>wwv_flow_api.id(7372877657194428)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>150
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(11488849027113265)
,p_view_id=>wwv_flow_api.id(11487397849113260)
,p_display_seq=>2
,p_column_id=>wwv_flow_api.id(11269302170701044)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>129
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(11489746745113268)
,p_view_id=>wwv_flow_api.id(11487397849113260)
,p_display_seq=>3
,p_column_id=>wwv_flow_api.id(11269452812701045)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>178
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(11490599427113271)
,p_view_id=>wwv_flow_api.id(11487397849113260)
,p_display_seq=>4
,p_column_id=>wwv_flow_api.id(11269514727701046)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>166
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(11491546102113274)
,p_view_id=>wwv_flow_api.id(11487397849113260)
,p_display_seq=>6
,p_column_id=>wwv_flow_api.id(11269643696701047)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>105
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(11492435316113277)
,p_view_id=>wwv_flow_api.id(11487397849113260)
,p_display_seq=>5
,p_column_id=>wwv_flow_api.id(11481657553112798)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>98
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(11493333833113280)
,p_view_id=>wwv_flow_api.id(11487397849113260)
,p_display_seq=>7
,p_column_id=>wwv_flow_api.id(11481740730112799)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>130
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(11494174012113283)
,p_view_id=>wwv_flow_api.id(11487397849113260)
,p_display_seq=>8
,p_column_id=>wwv_flow_api.id(11481761940112800)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(11500776955135832)
,p_view_id=>wwv_flow_api.id(11487397849113260)
,p_display_seq=>10
,p_column_id=>wwv_flow_api.id(11482210111112804)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>160
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7007349256431231)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(7006516325431223)
,p_button_name=>'Search'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(8530555504286924)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Search'
,p_button_position=>'BELOW_BOX'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2356431470840919)
,p_name=>'P4_NEW'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(11268978744701041)
,p_source=>'select value from wsc_ahcs_refresh_t where data_entity_name=''DEV_URL'';'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7006658115431224)
,p_name=>'SUBLEDGER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(7006516325431223)
,p_prompt=>'Subledger'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:EBS AP;EBS AP,EBS AR;EBS AR,EBS FA;EBS FA,ERP POC;ERP POC,CENTRAL;Central,MF AP;MF AP,MF AR;MF AR,PS FA;PS FA,CLOUDPAY;CLOUDPAY,ECLPS;ECLPS,LEASES;LEASES,SXEUS;SXEUS,APS Treasury;APS Treasury,MF INVENTORY;MF INVENTORY,ORACLE LSI;Oracle LSI,CON'
||'CUR;CONCUR'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(8527793298286916)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7006703828431225)
,p_name=>'ACCOUNTING_PERIOD'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(7006516325431223)
,p_prompt=>'Accounting Period'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT a.months',
'  ||''-''',
'  ||b.years',
'FROM',
'  (SELECT TO_CHAR(add_months(TRUNC(SYSDATE, ''YYYY''), LEVEL - 1), ''MON'') months',
'  FROM dual',
'    CONNECT BY LEVEL <= 12',
'  ) a,',
'  (SELECT SUBSTR(EXTRACT(YEAR FROM SYSDATE-730) + (LEVEL-1),3) years',
'  FROM dual',
'    CONNECT BY LEVEL <=5',
'  ) b',
'ORDER BY b.years,',
'  to_char(to_date(a.months,''MON''),''MM'')',
''))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(8527793298286916)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET_FILTER'
,p_attribute_03=>'N'
,p_attribute_04=>'Y'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7006848508431226)
,p_name=>'INTERFACE_PROCESSING_STATUS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(7006516325431223)
,p_prompt=>'Interface Processing Status'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Reprocessing Error;Reprocessing Error,Re-extract Error;Re-extract Error,Success;Success,Skipped;Skipped'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(8527793298286916)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7006879622431227)
,p_name=>'CREATE_ACCOUNTING_STATUS'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(7006516325431223)
,p_prompt=>'Create Accounting Status'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Import Pending;Import Pending,Accounting Pending;Accounting Pending,Draft Accounted;Draft Accounted,Final Accounted;Final Accounted,Import Error;Import Error,Error;Error,N/A;NA'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(8527793298286916)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10792632210039636)
,p_name=>'LAST_REFRESH_DATE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(10719081466405342)
,p_prompt=>'Last Refresh Date'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Select to_char(LAST_REFRESH_DATE at time zone ''EST'',''YYYY-MM-DD HH24:MI:SS'')||'' EST'' from WSC_AHCS_REFRESH_T WHERE DATA_ENTITY_NAME=''WSC_AHCS_DASHBOARD2_REFRESH'';',
'',
'Select to_char(CAST(FROM_TZ(CAST(LAST_REFRESH_DATE AS TIMESTAMP), ''UTC'') ',
'at time zone ''America/New_York'' AS Date),''YYYY-MM-DD HH24:MI:SS'')||'' EST'' ',
'from WSC_AHCS_REFRESH_T WHERE DATA_ENTITY_NAME=''WSC_AHCS_DASHBOARD2_REFRESH'''))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_column=>11
,p_field_template=>wwv_flow_api.id(8528004246286916)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(10790184270039612)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(7007349256431231)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(10959208055568327)
,p_event_id=>wwv_flow_api.id(10790184270039612)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(11268978744701041)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(10956457820568299)
,p_name=>'New_1'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P4_NEW'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(10956553026568300)
,p_event_id=>wwv_flow_api.id(10956457820568299)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P4_NEW:=:P_STATUS;'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(10960530978568340)
,p_name=>'New_2'
,p_event_sequence=>30
,p_condition_element_type=>'COLUMN'
,p_condition_element=>'DUMMY'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(10960591733568341)
,p_event_id=>wwv_flow_api.id(10960530978568340)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'COLUMN'
,p_affected_elements=>'DUMMY1'
,p_server_condition_type=>'FUNCTION_BODY'
,p_server_condition_expr1=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Begin',
'       Return True;',
'    ',
'End;'))
,p_server_condition_expr2=>'PLSQL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(2354719720840902)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'username varchar2(200) := APEX_UTIL.GET_SESSION_STATE(''USER_NAME'');',
'begin :P_USER_NAME := username; ',
'select value into :P_URL from wsc_ahcs_refresh_t where data_entity_name=''DEV_URL'';',
'-- select substr(value,1, instr(value,''/'',1,3)) into :P_URL from wsc_ahcs_refresh_t where data_entity_name=''SIT2_URL'';',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(2547883772288503)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(11268978744701041)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'New1 - Save Interactive Grid Data'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(2354837047840903)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_user_name varchar2(200);',
'v_jwt_token  varchar2(4000);',
'',
'BEGIN',
'-- null;',
'-- APEX_CUSTOM_AUTH.SET_USER(''WESCO_USER'');',
' --APEX_UTIL.SET_SESSION_STATE(''USER_NAME'',''WESCO_USER'');',
'',
'IF  APEX_UTIL.GET_SESSION_STATE(''USER_NAME'') IS NULL THEN',
'   ',
'  xx_apex_user_security_pkg.main(v_jwt_token,v_user_name,null);  ',
'  ',
'   ',
'    APEX_UTIL.SET_SESSION_STATE(''USER_NAME'',v_user_name);',
'    APEX_UTIL.SET_SESSION_STATE(''JWT_TOKEN'',v_jwt_token);',
'   ',
'    IF APEX_UTIL.GET_SESSION_STATE(''USER_NAME'') IS NULL THEN',
'        APEX_UTIL.REDIRECT_URL(''f?p=&APP_ID.:9999:&APP_SESSION.'');',
'        -- null;',
'    ',
'   ELSE',
'        APEX_CUSTOM_AUTH.SET_USER(APEX_UTIL.GET_SESSION_STATE(''USER_NAME''));',
'      ',
'        ',
'   END IF;',
'   ',
'ELSE',
'   APEX_CUSTOM_AUTH.SET_USER(APEX_UTIL.GET_SESSION_STATE(''USER_NAME''));  ',
'   ',
'   ',
'END IF;',
' ',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
