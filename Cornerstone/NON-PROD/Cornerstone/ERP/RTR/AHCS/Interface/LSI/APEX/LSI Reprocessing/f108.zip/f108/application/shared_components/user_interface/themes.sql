prompt --application/shared_components/user_interface/themes
begin
--   Manifest
--     THEME: 108
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1701052144005286
,p_default_application_id=>108
,p_default_id_offset=>16491536708563557
,p_default_owner=>'FININT'
);
wwv_flow_api.create_theme(
 p_id=>wwv_flow_api.id(26797995938726073)
,p_theme_id=>42
,p_theme_name=>'Universal Theme'
,p_theme_internal_name=>'UNIVERSAL_THEME'
,p_ui_type_name=>'DESKTOP'
,p_navigation_type=>'L'
,p_nav_bar_type=>'LIST'
,p_reference_id=>4070917134413059350
,p_is_locked=>false
,p_default_page_template=>wwv_flow_api.id(26692915471725986)
,p_default_dialog_template=>wwv_flow_api.id(26676432386725975)
,p_error_template=>wwv_flow_api.id(26677850265725976)
,p_printer_friendly_template=>wwv_flow_api.id(26692915471725986)
,p_breadcrumb_display_point=>'REGION_POSITION_01'
,p_sidebar_display_point=>'REGION_POSITION_02'
,p_login_template=>wwv_flow_api.id(26677850265725976)
,p_default_button_template=>wwv_flow_api.id(26795179108726064)
,p_default_region_template=>wwv_flow_api.id(26730122453726012)
,p_default_chart_template=>wwv_flow_api.id(26730122453726012)
,p_default_form_template=>wwv_flow_api.id(26730122453726012)
,p_default_reportr_template=>wwv_flow_api.id(26730122453726012)
,p_default_tabform_template=>wwv_flow_api.id(26730122453726012)
,p_default_wizard_template=>wwv_flow_api.id(26730122453726012)
,p_default_menur_template=>wwv_flow_api.id(26739519880726019)
,p_default_listr_template=>wwv_flow_api.id(26730122453726012)
,p_default_irr_template=>wwv_flow_api.id(26728175846726011)
,p_default_report_template=>wwv_flow_api.id(26757627270726033)
,p_default_label_template=>wwv_flow_api.id(26792731682726061)
,p_default_menu_template=>wwv_flow_api.id(26796572880726065)
,p_default_calendar_template=>wwv_flow_api.id(26796651496726066)
,p_default_list_template=>wwv_flow_api.id(26790834649726059)
,p_default_nav_list_template=>wwv_flow_api.id(26781808516726053)
,p_default_top_nav_list_temp=>wwv_flow_api.id(26781808516726053)
,p_default_side_nav_list_temp=>wwv_flow_api.id(26780018461726051)
,p_default_nav_list_position=>'SIDE'
,p_default_dialogbtnr_template=>wwv_flow_api.id(26700092831725993)
,p_default_dialogr_template=>wwv_flow_api.id(26699108644725992)
,p_default_option_label=>wwv_flow_api.id(26792731682726061)
,p_default_required_label=>wwv_flow_api.id(26793958285726062)
,p_default_page_transition=>'NONE'
,p_default_popup_transition=>'NONE'
,p_default_navbar_list_template=>wwv_flow_api.id(26782826140726053)
,p_file_prefix => nvl(wwv_flow_application_install.get_static_theme_file_prefix(42),'#IMAGE_PREFIX#themes/theme_42/21.1/')
,p_files_version=>64
,p_icon_library=>'FONTAPEX'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#IMAGE_PREFIX#libraries/apex/#MIN_DIRECTORY#widget.stickyWidget#MIN#.js?v=#APEX_VERSION#',
'#THEME_IMAGES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_css_file_urls=>'#THEME_IMAGES#css/Core#MIN#.css?v=#APEX_VERSION#'
);
wwv_flow_api.component_end;
end;
/
