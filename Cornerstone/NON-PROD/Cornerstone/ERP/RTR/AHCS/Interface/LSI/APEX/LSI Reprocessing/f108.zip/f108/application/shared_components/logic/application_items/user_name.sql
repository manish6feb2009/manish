prompt --application/shared_components/logic/application_items/user_name
begin
--   Manifest
--     APPLICATION ITEM: USER_NAME
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1701052144005286
,p_default_application_id=>108
,p_default_id_offset=>16491536708563557
,p_default_owner=>'FININT'
);
wwv_flow_api.create_flow_item(
 p_id=>wwv_flow_api.id(29664239238061537)
,p_name=>'USER_NAME'
,p_protection_level=>'I'
);
wwv_flow_api.component_end;
end;
/
