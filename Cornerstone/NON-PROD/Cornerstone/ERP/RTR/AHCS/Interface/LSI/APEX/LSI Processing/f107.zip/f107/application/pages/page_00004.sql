prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1701052144005286
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'FININT'
);
wwv_flow_api.create_page(
 p_id=>4
,p_user_interface_id=>wwv_flow_api.id(10328153034162532)
,p_name=>'Test LSI Repro'
,p_alias=>'TEST-LSI-REPRO'
,p_step_title=>'Test LSI Repro'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_last_updated_by=>'WESCO_SIT1_DEVELOPER'
,p_last_upd_yyyymmddhh24miss=>'20220610071951'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(23416675956380772)
,p_plug_name=>'Adhoc Process Start'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(10238585745162455)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12203533724325272)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(23416675956380772)
,p_button_name=>'Adhoc_submit'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(10303642400162507)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Submit'
,p_button_position=>'BELOW_BOX'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11216227204055527)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(23416675956380772)
,p_button_name=>'Adhoc_submit_1'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(10303642400162507)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Submit'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11216561558055530)
,p_name=>'4_FROM_DATE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(23416675956380772)
,p_prompt=>'From  Date'
,p_display_as=>'NATIVE_DATE_PICKER_JET'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(10300945509162504)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12203909000325272)
,p_name=>'4_HINT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(23416675956380772)
,p_source=>'Please provide from date and to date for a starting the LSI process'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(10300945509162504)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12204332590325273)
,p_name=>'4_FLOW'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(23416675956380772)
,p_prompt=>'Flow'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:AP/AR;AP/AR,GL;GL'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(10301240069162504)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12205130533325273)
,p_name=>'4_TO_DATE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(23416675956380772)
,p_prompt=>'To Date'
,p_display_as=>'NATIVE_DATE_PICKER_JET'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(10300945509162504)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(12206477597325275)
,p_name=>'SUBMIT_ACTION'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(12203533724325272)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(12206961999325275)
,p_event_id=>wwv_flow_api.id(12206477597325275)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'WSC_LSI_PKG.wsc_ahcs_lsi_kickoff(:FLOW,to_char(to_date(:FROM_DATE,''mm/dd/yyyy''),''dd-mm-yyyy''),',
'to_char(to_date(:TO_DATE,''mm/dd/yyyy''),''dd-mm-yyyy''));',
'-- null;',
'-- ',
'-- insert into wsc_tbl_time_t(a,b,c) values(''test'',sysdate,1);',
'end;'))
,p_attribute_02=>'FLOW,FROM_DATE,TO_DATE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'N'
,p_client_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_client_condition_expression=>'apex.page.validate() '
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(11216398319055528)
,p_name=>'FLOW_ACTION'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'4_FLOW'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(11216467297055529)
,p_event_id=>wwv_flow_api.id(11216398319055528)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($v("4_FLOW")==''GL'') {',
'    // $("label[for=FROM_DATE]").text("*FROM DATE")',
'    // $("label[for=TO_DATE]").text("*TO DATE")  ',
'    var item = $("#4_FROM_DATE");',
'    item.prop("required",true);',
'    item.closest(".t-Form-fieldContainer").addClass("is-required");',
'    var item = $("#4_TO_DATE");',
'    item.prop("required",true);',
'    item.closest(".t-Form-fieldContainer").addClass("is-required");',
'',
'} ',
'else if ($v("4_FLOW")==''AP/AR'') {',
'    // $("label[for=FROM_DATE]").text("FROM DATE")',
'    // $("label[for=TO_DATE]").text("TO DATE")',
'    var item = $("#4_FROM_DATE");',
'    item.prop("required",false);',
'    item.closest(".t-Form-fieldContainer").removeClass("is-required");',
'    var item = $("#4_TO_DATE");',
'    item.prop("required",false);',
'    item.closest(".t-Form-fieldContainer").removeClass("is-required");',
'',
'}'))
);
wwv_flow_api.component_end;
end;
/
