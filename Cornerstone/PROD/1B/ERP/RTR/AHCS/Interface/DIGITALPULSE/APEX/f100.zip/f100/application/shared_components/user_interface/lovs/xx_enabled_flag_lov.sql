prompt --application/shared_components/user_interface/lovs/xx_enabled_flag_lov
begin
--   Manifest
--     XX_ENABLED_FLAG_LOV
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>2065831728883124
,p_default_application_id=>100
,p_default_id_offset=>14758838573580759
,p_default_owner=>'DGTL_PLS'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(34905758045838076572)
,p_lov_name=>'XX_ENABLED_FLAG_LOV'
,p_lov_query=>'.'||wwv_flow_api.id(34905758045838076572)||'.'
,p_location=>'STATIC'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(34905758401236076573)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Yes'
,p_lov_return_value=>'Y'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(34905758739198076573)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'No'
,p_lov_return_value=>'N'
);
wwv_flow_api.component_end;
end;
/
