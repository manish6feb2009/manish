prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>2065831728883124
,p_default_application_id=>100
,p_default_id_offset=>14758838573580759
,p_default_owner=>'DGTL_PLS'
);
wwv_flow_api.create_page(
 p_id=>3
,p_user_interface_id=>wwv_flow_api.id(33326459299734847953)
,p_name=>'Systems'
,p_step_title=>'Systems'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_last_updated_by=>'SEC_DP_USER'
,p_last_upd_yyyymmddhh24miss=>'20200721064248'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6322437894313022679)
,p_plug_name=>'Systems'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(33326380712036847901)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'       ''icon'' AS CARD_TYPE, ',
'       DECODE(ROWNUM, 1, ''fa-globe'', 2, ''fa-gear'', ''fa-user'') AS CARD_ICON, ',
'       NULL AS CARD_ICON_COLOR, ',
'       NULL AS CARD_HEADER_STYLE,',
'       system_name AS CARD_TITLE, ',
'       (select ''Success : ''||DECODE(total,0,0,Round(success*100/total,2))||''%'' from(',
'  select ',
'      (select count(integration_status) FROM XX_IMD_INTEGRATION_RUN_T XRT',
'   , XX_IMD_INTEGRATION_MASTER_T XMT',
'   where XRT.INTEGRATION_MASTER_ID= XMT.ID',
'   and (XMT.SOURCE_SYSTEM = xist.system_code',
'	  OR XMT.TARGET_SYSTEM = xist.system_code)) total,',
'       (select count(integration_status) FROM XX_IMD_INTEGRATION_RUN_T XRT',
'   , XX_IMD_INTEGRATION_MASTER_T XMT',
'   where XRT.INTEGRATION_MASTER_ID= XMT.ID',
'   and (XMT.SOURCE_SYSTEM = xist.system_code',
'	  OR XMT.TARGET_SYSTEM = xist.system_code)',
'      and xrt.integration_status=''SUCCESS'' ) success ',
'   from dual)) AS CARD_VALUE, ',
'       system_desc AS CARD_FOOTER, ',
'       apex_util.prepare_url (''f?p='' || :app_id || '':4:'' || :app_session|| '':::4:P4_SOURCE_SYSTEM:''||system_code) AS CARD_LINK, ',
'       NULL AS CARD_CHART_DATA, ',
'       NULL AS CARD_CHART_CONFIG ',
'FROM   xx_imd_system_t xist'))
,p_plug_source_type=>'PLUGIN_APEX.MATERIAL.CARDS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{',
'  "cardWidth": 4,',
'  "refresh": 0',
'}'))
,p_attribute_02=>'N'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{',
'  "ALLOWED_ATTR": [',
'    "accesskey",',
'    "align",',
'    "alt",',
'    "always",',
'    "autocomplete",',
'    "autoplay",',
'    "border",',
'    "cellpadding",',
'    "cellspacing",',
'    "charset",',
'    "class",',
'    "dir",',
'    "height",',
'    "href",',
'    "id",',
'    "lang",',
'    "name",',
'    "rel",',
'    "required",',
'    "src",',
'    "style",',
'    "summary",',
'    "tabindex",',
'    "target",',
'    "title",',
'    "type",',
'    "value",',
'    "width"',
'  ],',
'  "ALLOWED_TAGS": [',
'    "a",',
'    "address",',
'    "b",',
'    "blockquote",',
'    "br",',
'    "caption",',
'    "code",',
'    "dd",',
'    "div",',
'    "dl",',
'    "dt",',
'    "em",',
'    "figcaption",',
'    "figure",',
'    "h1",',
'    "h2",',
'    "h3",',
'    "h4",',
'    "h5",',
'    "h6",',
'    "hr",',
'    "i",',
'    "img",',
'    "label",',
'    "li",',
'    "nl",',
'    "ol",',
'    "p",',
'    "pre",',
'    "s",',
'    "span",',
'    "strike",',
'    "strong",',
'    "sub",',
'    "sup",',
'    "table",',
'    "tbody",',
'    "td",',
'    "th",',
'    "thead",',
'    "tr",',
'    "u",',
'    "ul"',
'  ]',
'}'))
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6322437985767022680)
,p_plug_name=>'Systems'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(33326380712036847901)
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with data1 as ',
'(',
'select DECODE(total,0,0,Round(success*100/total,2)) value_per,DECODE(total,0,0,Round(running*100/total,2)) val_run,total,DECODE(total,0,0,100-Round(success*100/total,2)-Round(running*100/total,2)) val_err,system_name,system_desc,system_code from(',
'  select system_name,system_desc,system_code,',
'      (select count(integration_status) FROM XX_IMD_INTEGRATION_RUN_T XRT',
'   , XX_IMD_INTEGRATION_MASTER_T XMT',
'   where XRT.INTEGRATION_MASTER_ID= XMT.ID',
'   and (XMT.SOURCE_SYSTEM = xist.system_code',
'	  OR XMT.TARGET_SYSTEM = xist.system_code)) total,',
'       (select count(integration_status) FROM XX_IMD_INTEGRATION_RUN_T XRT',
'   , XX_IMD_INTEGRATION_MASTER_T XMT',
'   where XRT.INTEGRATION_MASTER_ID= XMT.ID',
'   and (XMT.SOURCE_SYSTEM = xist.system_code',
'	  OR XMT.TARGET_SYSTEM = xist.system_code)',
'      and xrt.integration_status=''SUCCESS'' ) success ,',
' (select count(integration_status) FROM XX_IMD_INTEGRATION_RUN_T XRT',
'   , XX_IMD_INTEGRATION_MASTER_T XMT',
'   where XRT.INTEGRATION_MASTER_ID= XMT.ID',
'   and (XMT.SOURCE_SYSTEM = xist.system_code',
'	  OR XMT.TARGET_SYSTEM = xist.system_code)',
'      and xrt.integration_status=''RUNNING'' ) running',
'   from xx_imd_system_t xist))',
'SELECT',
'       ''chart-pie'' AS CARD_TYPE, ',
'       ''fa-pie-chart'' AS CARD_ICON, ',
'       NULL AS CARD_ICON_COLOR,',
'       ''background:#121212''AS CARD_HEADER_STYLE,',
'	   data1.system_name AS CARD_TITLE, ',
'       ''Total Runs : ''||data1.total AS CARD_VALUE,  ',
'       data1.system_desc AS CARD_FOOTER, ',
'       apex_util.prepare_url (''f?p='' || :app_id || '':4:'' || :app_session|| '':::4:P4_SOURCE_SYSTEM:''||system_code) AS CARD_LINK, ',
'       ''{',
'          "labels": ["''|| value_per ||'' %","''||val_err||''%","''||val_run||''%"],',
'          "series": [''|| value_per ||'',''||val_err||'',''||val_run||'']',
'       }'' AS CARD_CHART_DATA,',
'       ''{',
'          "total": 100,',
'          "donut": false,',
'          "donutWidth": 240,',
'          "sliceWidth": 15',
'        }'' AS CARD_CHART_CONFIG',
'FROM data1'))
,p_plug_source_type=>'PLUGIN_APEX.MATERIAL.CARDS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{',
'  "cardWidth": 4,',
'  "refresh": 0',
'}'))
,p_attribute_02=>'N'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{',
'  "ALLOWED_ATTR": [',
'    "accesskey",',
'    "align",',
'    "alt",',
'    "always",',
'    "autocomplete",',
'    "autoplay",',
'    "border",',
'    "cellpadding",',
'    "cellspacing",',
'    "charset",',
'    "class",',
'    "dir",',
'    "height",',
'    "href",',
'    "id",',
'    "lang",',
'    "name",',
'    "rel",',
'    "required",',
'    "src",',
'    "style",',
'    "summary",',
'    "tabindex",',
'    "target",',
'    "title",',
'    "type",',
'    "value",',
'    "width"',
'  ],',
'  "ALLOWED_TAGS": [',
'    "a",',
'    "address",',
'    "b",',
'    "blockquote",',
'    "br",',
'    "caption",',
'    "code",',
'    "dd",',
'    "div",',
'    "dl",',
'    "dt",',
'    "em",',
'    "figcaption",',
'    "figure",',
'    "h1",',
'    "h2",',
'    "h3",',
'    "h4",',
'    "h5",',
'    "h6",',
'    "hr",',
'    "i",',
'    "img",',
'    "label",',
'    "li",',
'    "nl",',
'    "ol",',
'    "p",',
'    "pre",',
'    "s",',
'    "span",',
'    "strike",',
'    "strong",',
'    "sub",',
'    "sup",',
'    "table",',
'    "tbody",',
'    "td",',
'    "th",',
'    "thead",',
'    "tr",',
'    "u",',
'    "ul"',
'  ]',
'}'))
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(34202212157048676463)
,p_name=>'Systems Monitoring'
,p_template=>wwv_flow_api.id(33326380712036847901)
,p_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--basic:t-Cards--3cols:t-Cards--animColorFill'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT apex_util.prepare_url (''f?p='' || :app_id || '':4:'' || :app_session|| '':::4:P4_SOURCE_SYSTEM:''||system_code) card_link,       ',
'       system_name card_title,',
'       system_desc card_text,',
'       system_add_details card_subtext,',
'       system_code card_initials',
'  FROM xx_imd_system_t '))
,p_display_condition_type=>'NEVER'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(33326396520019847911)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(34202212255078676464)
,p_query_column_id=>1
,p_column_alias=>'CARD_LINK'
,p_column_display_sequence=>1
,p_column_heading=>'Card Link'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(34202212384260676465)
,p_query_column_id=>2
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>2
,p_column_heading=>'Card Title'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(34202212434863676466)
,p_query_column_id=>3
,p_column_alias=>'CARD_TEXT'
,p_column_display_sequence=>3
,p_column_heading=>'Card Text'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(34202212555396676467)
,p_query_column_id=>4
,p_column_alias=>'CARD_SUBTEXT'
,p_column_display_sequence=>4
,p_column_heading=>'Card Subtext'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(34202212651288676468)
,p_query_column_id=>5
,p_column_alias=>'CARD_INITIALS'
,p_column_display_sequence=>5
,p_column_heading=>'Card Initials'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(42369455122125367364)
,p_plug_name=>'System - Monthly Job Run'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(33326380712036847901)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT to_char(START_TIME,''MON'') AS label,',
'       NVL((select COUNT(i.TRACK) from XX_IMD_INTEGRATION_RUN_T t,XX_IMD_INTEGRATION_MASTER_T i',
'        WHERE t.integration_master_id = i.id AND i.SOURCE_SYSTEM = ''PT'' ',
'	   AND to_char(t.start_time,''MON'') = to_char(p.start_time,''MON'')',
'	   ),0) AS VALUE,',
'       ''Project Tracker'' AS series ',
'  FROM XX_IMD_INTEGRATION_RUN_T p',
'UNION',
'SELECT DISTINCT to_char(START_TIME,''MON'') AS label,',
'       NVL((select COUNT(i.TRACK) from XX_IMD_INTEGRATION_RUN_T t,XX_IMD_INTEGRATION_MASTER_T i',
'        WHERE t.integration_master_id = i.id AND i.SOURCE_SYSTEM = ''BT'' ',
'	   AND to_char(t.start_time,''MON'') = to_char(p.start_time,''MON'')',
'	   ),0) AS VALUE,',
'       ''Bill Trust'' AS series ',
'  FROM XX_IMD_INTEGRATION_RUN_T p',
'UNION',
'SELECT DISTINCT to_char(START_TIME,''MON'') AS label,',
'       NVL((select COUNT(i.TRACK) from XX_IMD_INTEGRATION_RUN_T t,XX_IMD_INTEGRATION_MASTER_T i',
'        WHERE t.integration_master_id = i.id AND i.SOURCE_SYSTEM = ''IF''',
'	   AND to_char(t.start_time,''MON'') = to_char(p.start_time,''MON'')',
'	   ),0) AS VALUE,',
'       ''Informatica'' AS series ',
'  FROM XX_IMD_INTEGRATION_RUN_T p',
'UNION',
'SELECT DISTINCT to_char(START_TIME,''MON'') AS label,',
'       NVL((select COUNT(i.TRACK) from XX_IMD_INTEGRATION_RUN_T t,XX_IMD_INTEGRATION_MASTER_T i',
'        WHERE t.integration_master_id = i.id AND i.SOURCE_SYSTEM = ''MES''',
'	   AND to_char(t.start_time,''MON'') = to_char(p.start_time,''MON'')',
'	   ),0) AS VALUE,',
'       ''Mes'' AS series ',
'  FROM XX_IMD_INTEGRATION_RUN_T p ',
'  UNION',
'SELECT DISTINCT to_char(START_TIME,''MON'') AS label,',
'       NVL((select COUNT(i.TRACK) from XX_IMD_INTEGRATION_RUN_T t,XX_IMD_INTEGRATION_MASTER_T i',
'        WHERE t.integration_master_id = i.id AND i.SOURCE_SYSTEM = ''SAL''',
'	   AND to_char(t.start_time,''MON'') = to_char(p.start_time,''MON'')',
'	   ),0) AS VALUE,',
'       ''Salsa'' AS series ',
'  FROM XX_IMD_INTEGRATION_RUN_T p '))
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
);
wwv_flow_api.create_jet_chart(
 p_id=>wwv_flow_api.id(42369455701776367369)
,p_region_id=>wwv_flow_api.id(42369455122125367364)
,p_chart_type=>'bar'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'none'
,p_hover_behavior=>'none'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(42369455762490367370)
,p_chart_id=>wwv_flow_api.id(42369455701776367369)
,p_seq=>10
,p_name=>'New'
,p_location=>'REGION_SOURCE'
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(42369455995176367372)
,p_chart_id=>wwv_flow_api.id(42369455701776367369)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(42369455874705367371)
,p_chart_id=>wwv_flow_api.id(42369455701776367369)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(42369456022583367373)
,p_plug_name=>'System - Daily Job Run'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(33326380712036847901)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT to_char(START_TIME,''DD-MON'') AS label,',
'       NVL((select COUNT(i.TRACK) from XX_IMD_INTEGRATION_RUN_T t,XX_IMD_INTEGRATION_MASTER_T i',
'        WHERE t.integration_master_id = i.id AND i.SOURCE_SYSTEM = ''PT'' ',
'	   AND to_char(t.start_time,''DD'') = to_char(p.start_time,''DD'')',
'	   ),0) AS VALUE,',
'       ''Project Tracker'' AS series ',
'  FROM XX_IMD_INTEGRATION_RUN_T p',
'  WHERE TO_CHAR(p.start_time, ''MON'')= TO_CHAR(SYSDATE,''MON'')',
'UNION',
'SELECT DISTINCT to_char(START_TIME,''DD-MON'') AS label,',
'       NVL((select COUNT(i.TRACK) from XX_IMD_INTEGRATION_RUN_T t,XX_IMD_INTEGRATION_MASTER_T i',
'        WHERE t.integration_master_id = i.id AND i.SOURCE_SYSTEM = ''BT'' ',
'	   AND to_char(t.start_time,''DD'') = to_char(p.start_time,''DD'')',
'	   ),0) AS VALUE,',
'       ''Bill Trust'' AS series ',
'  FROM XX_IMD_INTEGRATION_RUN_T p',
'  WHERE TO_CHAR(p.start_time, ''MON'')= TO_CHAR(SYSDATE,''MON'')',
'UNION',
'SELECT DISTINCT to_char(START_TIME,''DD-MON'') AS label,',
'       NVL((select COUNT(i.TRACK) from XX_IMD_INTEGRATION_RUN_T t,XX_IMD_INTEGRATION_MASTER_T i',
'        WHERE t.integration_master_id = i.id AND i.SOURCE_SYSTEM = ''IF''',
'	   AND to_char(t.start_time,''DD'') = to_char(p.start_time,''DD'')',
'	   ),0) AS VALUE,',
'       ''Informatica'' AS series ',
'  FROM XX_IMD_INTEGRATION_RUN_T p',
'  WHERE TO_CHAR(p.start_time, ''MON'')= TO_CHAR(SYSDATE,''MON'')',
'UNION',
'SELECT DISTINCT to_char(START_TIME,''DD-MON'') AS label,',
'       NVL((select COUNT(i.TRACK) from XX_IMD_INTEGRATION_RUN_T t,XX_IMD_INTEGRATION_MASTER_T i',
'        WHERE t.integration_master_id = i.id AND i.SOURCE_SYSTEM = ''MES''',
'	   AND to_char(t.start_time,''DD'') = to_char(p.start_time,''DD'')',
'	   ),0) AS VALUE,',
'       ''Mes'' AS series ',
'  FROM XX_IMD_INTEGRATION_RUN_T p',
'  WHERE TO_CHAR(p.start_time, ''MON'')= TO_CHAR(SYSDATE,''MON'')',
'  UNION',
'SELECT DISTINCT to_char(START_TIME,''DD-MON'') AS label,',
'       NVL((select COUNT(i.TRACK) from XX_IMD_INTEGRATION_RUN_T t,XX_IMD_INTEGRATION_MASTER_T i',
'        WHERE t.integration_master_id = i.id AND i.SOURCE_SYSTEM = ''SAL''',
'	   AND to_char(t.start_time,''DD'') = to_char(p.start_time,''DD'')',
'	   ),0) AS VALUE,',
'       ''Salsa'' AS series ',
'  FROM XX_IMD_INTEGRATION_RUN_T p ',
'  WHERE TO_CHAR(p.start_time, ''MON'')= TO_CHAR(SYSDATE,''MON'')'))
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
);
wwv_flow_api.create_jet_chart(
 p_id=>wwv_flow_api.id(42369456130735367374)
,p_region_id=>wwv_flow_api.id(42369456022583367373)
,p_chart_type=>'bar'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'none'
,p_hover_behavior=>'none'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(42369456220328367375)
,p_chart_id=>wwv_flow_api.id(42369456130735367374)
,p_seq=>10
,p_name=>'Daily System Job Run'
,p_location=>'REGION_SOURCE'
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(5819988954005423154)
,p_chart_id=>wwv_flow_api.id(42369456130735367374)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(5819989109379423155)
,p_chart_id=>wwv_flow_api.id(42369456130735367374)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(42369456637511367379)
,p_plug_name=>'Module - Month Job Run'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(33326380712036847901)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT to_char(START_TIME,''MON'') AS label,',
'       NVL((select COUNT(t.TRACK) from XX_IMD_INTEGRATION_RUN_T t',
'        WHERE t.TRACK = ''P2P'' ',
'	   AND to_char(t.start_time,''MON'') = to_char(p.start_time,''MON'')',
'	   ),0) AS VALUE,',
'       ''Procure to Pay'' AS series ',
'  FROM XX_IMD_INTEGRATION_RUN_T p',
'UNION',
'SELECT DISTINCT to_char(START_TIME,''MON'') AS label,',
'       NVL((select COUNT(t.TRACK) from XX_IMD_INTEGRATION_RUN_T t',
'        WHERE t.TRACK = ''O2C'' ',
'	   AND to_char(t.start_time,''MON'') = to_char(p.start_time,''MON'')',
'	   ),0) AS VALUE,',
'       ''Order to Cash'' AS series ',
'  FROM XX_IMD_INTEGRATION_RUN_T p',
'UNION',
'SELECT DISTINCT to_char(START_TIME,''MON'') AS label,',
'       NVL((select COUNT(t.TRACK) from XX_IMD_INTEGRATION_RUN_T t',
'        WHERE t.TRACK = ''R2R'' ',
'	   AND to_char(t.start_time,''MON'') = to_char(p.start_time,''MON'')',
'	   ),0) AS VALUE,',
'       ''Record to Report'' AS series ',
'  FROM XX_IMD_INTEGRATION_RUN_T p',
'UNION',
'SELECT DISTINCT to_char(START_TIME,''MON'') AS label,',
'       NVL((select COUNT(t.TRACK) from XX_IMD_INTEGRATION_RUN_T t,XX_IMD_INTEGRATION_MASTER_T i',
'        WHERE t.TRACK = ''F2D'' ',
'	   AND to_char(t.start_time,''MON'') = to_char(p.start_time,''MON'')',
'	   ),0) AS VALUE,',
'       ''Forecast to Delivery'' AS series ',
'  FROM XX_IMD_INTEGRATION_RUN_T p  '))
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
);
wwv_flow_api.create_jet_chart(
 p_id=>wwv_flow_api.id(42369456815229367380)
,p_region_id=>wwv_flow_api.id(42369456637511367379)
,p_chart_type=>'bar'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'none'
,p_hover_behavior=>'none'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(42369456835699367381)
,p_chart_id=>wwv_flow_api.id(42369456815229367380)
,p_seq=>10
,p_name=>'New'
,p_location=>'REGION_SOURCE'
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(42369456955315367382)
,p_chart_id=>wwv_flow_api.id(42369456815229367380)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(42369457078625367383)
,p_chart_id=>wwv_flow_api.id(42369456815229367380)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(42369457156708367384)
,p_plug_name=>'Module - Daily Job Run'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(33326380712036847901)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT to_char(START_TIME,''DD-MON'') AS label,',
'       NVL((select COUNT(t.TRACK) from XX_IMD_INTEGRATION_RUN_T t',
'        WHERE t.TRACK = ''P2P'' ',
'	   AND to_char(t.start_time,''DD'') = to_char(p.start_time,''DD'')',
'       AND to_char(p.START_TIME,''MON'') = TO_CHAR(SYSDATE,''MON'')     ',
'	   ),0) AS VALUE,',
'       ''Procure to Pay'' AS series ',
'  FROM XX_IMD_INTEGRATION_RUN_T p',
'UNION',
'SELECT DISTINCT to_char(START_TIME,''DD-MON'') AS label,',
'       NVL((select COUNT(t.TRACK) from XX_IMD_INTEGRATION_RUN_T t',
'        WHERE t.TRACK = ''O2C'' ',
'	   AND to_char(t.start_time,''DD'') = to_char(p.start_time,''DD'')',
'       AND to_char(p.START_TIME,''MON'') = TO_CHAR(SYSDATE,''MON'')  ',
'	   ),0) AS VALUE,',
'       ''Order to Cash'' AS series ',
'  FROM XX_IMD_INTEGRATION_RUN_T p',
'UNION',
'SELECT DISTINCT to_char(START_TIME,''DD-MON'') AS label,',
'       NVL((select COUNT(t.TRACK) from XX_IMD_INTEGRATION_RUN_T t',
'        WHERE t.TRACK = ''R2R'' ',
'	   AND to_char(t.start_time,''DD'') = to_char(p.start_time,''DD'')',
'	   ),0) AS VALUE,',
'       ''Record to Report'' AS series ',
'  FROM XX_IMD_INTEGRATION_RUN_T p',
'UNION',
'SELECT DISTINCT to_char(START_TIME,''DD-MON'') AS label,',
'       NVL((select COUNT(t.TRACK) from XX_IMD_INTEGRATION_RUN_T t,XX_IMD_INTEGRATION_MASTER_T i',
'        WHERE t.TRACK = ''F2D'' ',
'	   AND to_char(t.start_time,''DD'') = to_char(p.start_time,''DD'')',
'       AND to_char(p.START_TIME,''MON'') = TO_CHAR(SYSDATE,''MON'')  ',
'	   ),0) AS VALUE,',
'       ''Forecast to Delivery'' AS series ',
'  FROM XX_IMD_INTEGRATION_RUN_T p  '))
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
);
wwv_flow_api.create_jet_chart(
 p_id=>wwv_flow_api.id(42369457253925367385)
,p_region_id=>wwv_flow_api.id(42369457156708367384)
,p_chart_type=>'bar'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'none'
,p_hover_behavior=>'none'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(42369457364771367386)
,p_chart_id=>wwv_flow_api.id(42369457253925367385)
,p_seq=>10
,p_name=>'New'
,p_location=>'REGION_SOURCE'
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(5819989168978423156)
,p_chart_id=>wwv_flow_api.id(42369457253925367385)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(5819989297971423157)
,p_chart_id=>wwv_flow_api.id(42369457253925367385)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(22751810791825523)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'',
'',
'v_name varchar2(200);',
'v_token  varchar2(4000);',
'',
'BEGIN',
'',
'',
'',
'IF APEX_UTIL.GET_SESSION_STATE(''USER_NAME'') IS NULL THEN',
'        APEX_UTIL.REDIRECT_URL(''f?p=&APP_ID.:9999:&APP_SESSION.'');',
'   ELSE',
'        APEX_CUSTOM_AUTH.SET_USER(APEX_UTIL.GET_SESSION_STATE(''USER_NAME''));',
'   END IF;',
'',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
