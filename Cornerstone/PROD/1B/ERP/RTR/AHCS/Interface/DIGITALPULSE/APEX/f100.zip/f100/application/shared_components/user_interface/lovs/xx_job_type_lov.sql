prompt --application/shared_components/user_interface/lovs/xx_job_type_lov
begin
--   Manifest
--     XX_JOB_TYPE_LOV
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>2065831728883124
,p_default_application_id=>100
,p_default_id_offset=>14758838573580759
,p_default_owner=>'DGTL_PLS'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(34906675599932497753)
,p_lov_name=>'XX_JOB_TYPE_LOV'
,p_lov_query=>'.'||wwv_flow_api.id(34906675599932497753)||'.'
,p_location=>'STATIC'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(34906675844241497754)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Program'
,p_lov_return_value=>'P'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(34906676223729497754)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Request Set'
,p_lov_return_value=>'S'
);
wwv_flow_api.component_end;
end;
/
