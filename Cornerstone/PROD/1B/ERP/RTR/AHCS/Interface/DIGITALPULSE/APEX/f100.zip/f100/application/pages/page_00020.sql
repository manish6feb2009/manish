prompt --application/pages/page_00020
begin
--   Manifest
--     PAGE: 00020
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>2065831728883124
,p_default_application_id=>100
,p_default_id_offset=>14758838573580759
,p_default_owner=>'DGTL_PLS'
);
wwv_flow_api.create_page(
 p_id=>20
,p_user_interface_id=>wwv_flow_api.id(33326459299734847953)
,p_name=>'Integration Activity'
,p_step_title=>'Integration Activity'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_last_updated_by=>'SEC_DP_USER'
,p_last_upd_yyyymmddhh24miss=>'20200611103501'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(42169798219705099381)
,p_plug_name=>'Integration Activity'
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(33326380712036847901)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       INTEGRATION_RUN_ID,',
'       ACTIVITY_NAME,',
'       ACTIVITY_DESC,',
'       ACTIVITY_DATE,',
'       ACTIVITY_STATUS,',
'       TOUCHPOINT_NAME',
'  from XX_IMD_INTEGRATION_ACTIVITY_T',
'where INTEGRATION_RUN_ID = :P20_RUN_ID',
'order by activity_date desc'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(42169798335402099381)
,p_name=>'Integration Activity'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'VPARASHAR@DELOITTE.COM'
,p_internal_uid=>36621110918001158135
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(42169798729254099382)
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(42169799175844099383)
,p_db_column_name=>'INTEGRATION_RUN_ID'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Integration Run Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(42169799593699099383)
,p_db_column_name=>'ACTIVITY_NAME'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Activity Name'
,p_column_link=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:RP:P31_NEW:#ID#'
,p_column_linktext=>'#ACTIVITY_NAME#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(42169799938046099383)
,p_db_column_name=>'ACTIVITY_DESC'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Activity Desc'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(42169800383474099384)
,p_db_column_name=>'ACTIVITY_DATE'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Activity Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(42169800759114099384)
,p_db_column_name=>'ACTIVITY_STATUS'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Activity Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6091184257664361513)
,p_db_column_name=>'TOUCHPOINT_NAME'
,p_display_order=>16
,p_column_identifier=>'N'
,p_column_label=>'Touchpoint Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(42174290391910236001)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'366256030'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:INTEGRATION_RUN_ID:ACTIVITY_NAME:ACTIVITY_DESC:ACTIVITY_DATE:ACTIVITY_STATUS:TOUCHPOINT_NAME'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(42169828303859115154)
,p_plug_name=>'Filter'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(33326355631923847887)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6091184191550361512)
,p_name=>'P20_RUN_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(42169828303859115154)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(42169828382909115155)
,p_name=>'P20_NEW'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(42169828303859115154)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(6203458406362053107)
,p_name=>'New'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(6203458528866053108)
,p_event_id=>wwv_flow_api.id(6203458406362053107)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''a[href*=":27:"]'').each(function(index) {',
'   ',
'   lnk1 = $(this).html();',
'   lnk = $(this).attr(''href'');',
'   $(this).parent()',
'          .parent(''tr'').attr(''edge-href'', lnk1)',
'    .click(function(){',
'      window.location=$(this).attr(''data-href'');',
'    })',
'    .mouseover(function(){',
'      $(this).css(''cursor'', ''pointer'');',
'    })',
'    .mouseleave(function(){',
'      $(this).css(''cursor'', ''default'');',
'    })',
'});'))
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(22752018439825526)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'',
'',
'v_name varchar2(200);',
'v_token  varchar2(4000);',
'',
'BEGIN',
'',
'    APEX_CUSTOM_AUTH.SET_USER(APEX_UTIL.GET_SESSION_STATE(''USER_NAME''));',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
