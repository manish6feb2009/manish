prompt --application/pages/page_00038
begin
--   Manifest
--     PAGE: 00038
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>2065831728883124
,p_default_application_id=>100
,p_default_id_offset=>14758838573580759
,p_default_owner=>'DGTL_PLS'
);
wwv_flow_api.create_page(
 p_id=>38
,p_user_interface_id=>wwv_flow_api.id(33326459299734847953)
,p_name=>'Long Running Jobs Details'
,p_alias=>'LONG-RUNNING-JOBS-DETAILS'
,p_step_title=>'Long Running Jobs Details'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_last_updated_by=>'WESCO_DP_SIT1_DEVELOPER'
,p_last_upd_yyyymmddhh24miss=>'20220124131751'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(34207653488971546948)
,p_plug_name=>'Long Running Jobs'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(33326379582771847900)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7174855387987281821)
,p_plug_name=>'Long Running Jobs'
,p_parent_plug_id=>wwv_flow_api.id(34207653488971546948)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(33326379582771847900)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  a.request_id, A.PROGRAM_NAME AS description, a.status, a.submitted_by, a.submit_time, a.start_time, a.end_time, a.ticket_number',
'FROM XX_IMD_JOB_RUN_T a',
'WHERE A.JOB_TYPE=''L'' ',
'  AND A.STATUS = NVL(:P38_STATUS,A.STATUS)',
'  AND (extract(hour from systimestamp - cast (START_TIME as timestamp)) + 24 * ',
'	  extract(day from systimestamp - cast (START_TIME as timestamp ))) <= NVL(:P34_NEW,100000000)',
'  /*AND a.program_name = b.job_name*/',
'  AND nvl(A.TRACK,''xx'') = NVL(:P38_TRACK,nvl(A.TRACK,''xx''))',
'  AND nvl(A.PHASE_CODE,''xx'') = nvl(:P38_MODULE,nvl(A.phase_code,''xx''))',
'  AND A.PROGRAM_NAME = NVL(:P38_PROGRAM_NAME,A.PROGRAM_NAME)'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P38_PROGRAM_NAME,P38_TIME,P38_TRACK,P38_MODULE,P38_STATUS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(7174855569522281823)
,p_max_row_count=>'1000000'
,p_max_rows_per_page=>'10'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'VPARASHAR@DELOITTE.COM'
,p_internal_uid=>7174855569522281823
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5443655930870501)
,p_db_column_name=>'REQUEST_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Request Id'
,p_column_type=>'STRING'
,p_static_id=>'REQUESTID_LRJ1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5444097362870502)
,p_db_column_name=>'DESCRIPTION'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Description'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5444494151870502)
,p_db_column_name=>'STATUS'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5444869590870502)
,p_db_column_name=>'SUBMITTED_BY'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Submitted By'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5445271205870502)
,p_db_column_name=>'SUBMIT_TIME'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Submit Time'
,p_column_type=>'DATE'
,p_format_mask=>'DD-MON-YYYY HH24:MI:SS'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5445662636870503)
,p_db_column_name=>'START_TIME'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Start Time'
,p_column_type=>'DATE'
,p_format_mask=>'DD-MON-YYYY HH24:MI:SS'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5446079508870503)
,p_db_column_name=>'END_TIME'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'End Time'
,p_column_type=>'DATE'
,p_format_mask=>'DD-MON-YYYY HH24:MI:SS'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5446458864870503)
,p_db_column_name=>'TICKET_NUMBER'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Ticket Number'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_static_id=>'ticket1'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(7294481196461920584)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'54468'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'REQUEST_ID:DESCRIPTION:STATUS:SUBMITTED_BY:SUBMIT_TIME:START_TIME:END_TIME:TICKET_NUMBER'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5447225976870504)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(7174855387987281821)
,p_button_name=>'Refresh_1'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(33326436807038847939)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Refresh'
,p_button_position=>'ABOVE_BOX'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5447608578870504)
,p_name=>'P38_PROGRAM_NAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(7174855387987281821)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5448042267870505)
,p_name=>'P38_TIME'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(7174855387987281821)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5448446712870505)
,p_name=>'P38_TRACK'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(7174855387987281821)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5448848412870505)
,p_name=>'P38_MODULE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(7174855387987281821)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5449297150870505)
,p_name=>'P38_STATUS'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(7174855387987281821)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(5450014314870506)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(5447225976870504)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(5450502439870507)
,p_event_id=>wwv_flow_api.id(5450014314870506)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    XX_APEX_GET_ESS_DET_SEC_PKG.get_reqID(null,null);',
'end ;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(5451031801870507)
,p_event_id=>wwv_flow_api.id(5450014314870506)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(7174855387987281821)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(5449664505870506)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'',
'',
'v_name varchar2(200);',
'v_token  varchar2(4000);',
'',
'BEGIN',
'',
'   ',
'   IF APEX_UTIL.GET_SESSION_STATE(''USER_NAME'') IS NULL THEN',
'        APEX_UTIL.REDIRECT_URL(''f?p=&APP_ID.:41:&APP_SESSION.'');',
'   ELSE',
'        APEX_CUSTOM_AUTH.SET_USER(APEX_UTIL.GET_SESSION_STATE(''USER_NAME''));',
'   END IF;',
'',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
