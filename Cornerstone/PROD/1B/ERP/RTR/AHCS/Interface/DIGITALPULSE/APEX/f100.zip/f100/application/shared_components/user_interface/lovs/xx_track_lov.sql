prompt --application/shared_components/user_interface/lovs/xx_track_lov
begin
--   Manifest
--     XX_TRACK_LOV
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>2065831728883124
,p_default_application_id=>100
,p_default_id_offset=>14758838573580759
,p_default_owner=>'DGTL_PLS'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(34906688363376504765)
,p_lov_name=>'XX_TRACK_LOV'
,p_lov_query=>'.'||wwv_flow_api.id(34906688363376504765)||'.'
,p_location=>'STATIC'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(34906688655082504766)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Procure To Pay'
,p_lov_return_value=>'P2P'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(34906689020552504766)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Order To Cash'
,p_lov_return_value=>'O2C'
);
wwv_flow_api.component_end;
end;
/
