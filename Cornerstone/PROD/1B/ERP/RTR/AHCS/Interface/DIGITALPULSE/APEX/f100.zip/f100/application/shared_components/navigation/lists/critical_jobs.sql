prompt --application/shared_components/navigation/lists/critical_jobs
begin
--   Manifest
--     LIST: Critical Jobs
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>2065831728883124
,p_default_application_id=>100
,p_default_id_offset=>14758838573580759
,p_default_owner=>'DGTL_PLS'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(34789294223949349887)
,p_name=>'Critical Jobs'
,p_list_type=>'SQL_QUERY'
,p_list_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NULL, ',
'       ''Requested By : ''|| submitted_by label, ',
'       NULL target, ',
'       NULL CARD_TEXT,',
'       ''YES'' is_current, ',
'       ''fa-bar-chart'' image, ',
'       ''width="5" height="5"'' image_attrib, ',
'       Program_Name image_alt,',
'case when Track=''P2P'' then ''P2P'' else ''O2C'' end as',
'Track',
'FROM  XX_IMD_JOB_RUN_T',
'ORDER BY PROGRAM_NAME'))
,p_list_status=>'PUBLIC'
);
wwv_flow_api.component_end;
end;
/
