prompt --application/shared_components/user_interface/theme_style
begin
--   Manifest
--     THEME STYLE: 100
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>2065831728883124
,p_default_application_id=>100
,p_default_id_offset=>14758838573580759
,p_default_owner=>'DGTL_PLS'
);
wwv_flow_api.create_theme_style(
 p_id=>wwv_flow_api.id(17228131125633845)
,p_theme_id=>42
,p_name=>'ID_dark'
,p_is_current=>true
,p_is_public=>true
,p_is_accessible=>true
,p_theme_roller_input_file_urls=>'#THEME_IMAGES#less/theme/Vita.less'
,p_theme_roller_config=>'{"customCSS":".t-HeroRegion-wrap\n{\npadding: 8px 8px 8px 16px;\n}\n.t-HeroRegion-icon{\nwidth:32px;\nheight:32px;\n}\n\n\t\n.t-HeroRegion-title{\nfont-size:2rem;\n}\n.t-Report--altRowsDefault .t-Report-report tr:nth-child(odd) .t-Report-cell{\nbackg'
||'round-color:#121212;\n}\n.t-Report-cell, .t-Report-colHead,.a-IRR-header{\nbackground-color:#121212;\n}\n.t-Report-colHead a,.a-IRR-header a {\n     color: #9c9c9c;\n}\n.t-Report-colHead,.a-IRR-header{\nfont-size:1.4rem;\n}\n\n.t-Report-cell,.a-IRR-h'
||'eader{\nline-height:2.4rem;\n}\ntd[headers=\"SUCCESS\"] a{\n  color:#7CB342 !important;\n  font-size:2.0rem;\n}\ntd[headers=\"TOTAL\"] a{\n  color:#1E88E5 !important;\n  font-size:2.0rem;\n}\ntd[headers=\"ERROR\"] a{\n  color:#F4511E !important;\n  f'
||'ont-size:2.0rem;\n}\ntd[headers=\"RUNNING\"] a{\n  color:#FFEB3B !important;\n  font-size:2.0rem;\n}\n.a-IRR-toolbar{\nbackground-color:#212121;\n}\n.a-IRR-table tr td{\nbackground-color:#121212;\n\n}\n\ntr[edge-href=\"SUCCESS\"] td:first-child {\n\n'
||'  border-left-color: #7CB342 !important;\n    border-left-width: 3px;\n}\n\ntr[edge-href=\"ERROR\"] td:first-child {\n\n  border-left-color: #F4511E !important;\n    border-left-width: 3px;\n}\n\ntr[edge-href=\"RUNNING\"] td:first-child {\n\n  border'
||'-left-color: #FFEB3B !important;\n    border-left-width: 3px;\n}\n\n\n.a-IRR-header{\nvertical-align:middle;\n}\n.a-IRR-table tr td a,.a-IRR-rowSelector label{\ncolor:#f4f4f4;\n}\n.t-Button--hot:not(.t-Button--simple){background-color:#E65100}\n.t-Bu'
||'tton--hot:not(.t-Button--simple):hover{background-color:#EF6C00}\n.a-Button,.a-Button:focus{\nbackground-color:#7CB342 ;\n}\n.a-Button:hover{\nbackground-color:#558B2F ;\n}\n.t-TreeNav .a-TreeView-node--topLevel .a-TreeView-row.is-current, .t-TreeNav'
||' .a-TreeView-node--topLevel .a-TreeView-row.is-selected, .t-TreeNav .a-TreeView-node--topLevel .a-TreeView-row.is-current--top.is-selected\n{\nbackground-color:#4b4b4b\n}\n.a-IRR-table tr:hover td{\n//background-color:#292929;\n}\n.a-IRR-search-field'
||'{\ncolor:#000000;\n}\n\na.Recon {\n    color: white; background-color: #5A827F; padding: 5px 11px; border: 2px solid #5a827f\n    \n    \n}\n\ntd[headers=\"ticket\"] a{\n  color:#1E88E5 !important;\n  text-decoration:underline\n}\n\ntd[headers=\"REQU'
||'ESTID_LRJ\"] a{\n  color:#1E88E5 !important;\n  text-decoration:underline\n}\n\ntd[headers=\"ticket1\"] a{\n  color:#1E88E5 !important;\n  text-decoration:underline\n}\n\ntd[headers=\"REQUESTID_LRJ1\"] a{\n  color:#1E88E5 !important;\n  text-decorati'
||'on:underline\n}\n\n.ct-series-a path{\n//stroke:rgb(60, 175, 133)  !important;\n  fill:rgb(60, 175, 133)  !important;\n  fill-opacity:1 !important;\n}\n.ct-series-b path{\n//stroke:rgb(233,91,84)  !important;\n  fill-opacity:1 !important;\n  fill:rgb'
||'(233,91,84)  !important;\n}\n\n.ct-series-c path{\n//stroke:rgb(48, 159, 219)   !important;\n  fill:rgb(48, 159, 219)  !important;\n  fill-opacity:1 !important;\n}\n\n.at-card .card-content .category{\nfont-size: 22px;\n    font-weight: 500;\n    col'
||'or: #121212 !important;\n\n}\n\n.at-card .title{\nmargin-top: 5px !important;\n  //color:#FFFFFF;\n    font-size: 18px;\n  \n}\n.at-card{\nbackground:#fafafa !important;\n}\n\n.at-card .card-footer .stats{\ncolor:#121212 !important;\n}\n\n.ui-dialog '
||'.ui-dialog-content.a-PopupLOV-dialog{\nbackground:#212121;\n}\n\n.ct-label {\n    fill: rgb(255, 255, 255) !important;\n    color: rgba(0,0,0,.4);\n    font-size: .75rem;\n    line-height: 1;\n\n}\n\n.comingsoon{\nbackground-image:url(\"../../../../.'
||'./../../xx_imd_dashboard/r/77101/files/static/v4/comingsoon6.png\") !important;\nbackground-size:cover;\n}","vars":{}}'
,p_theme_roller_output_file_url=>'#THEME_DB_IMAGES#5526640371214933119.css'
,p_theme_roller_read_only=>false
);
wwv_flow_api.create_theme_style(
 p_id=>wwv_flow_api.id(33326438576417847941)
,p_theme_id=>42
,p_name=>'Vista'
,p_css_file_urls=>'#THEME_IMAGES#css/Vista#MIN#.css?v=#APEX_VERSION#'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_read_only=>true
,p_reference_id=>4007676303523989775
);
wwv_flow_api.create_theme_style(
 p_id=>wwv_flow_api.id(33326438743028847941)
,p_theme_id=>42
,p_name=>'Vita'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>true
,p_theme_roller_input_file_urls=>'#THEME_IMAGES#less/theme/Vita.less'
,p_theme_roller_output_file_url=>'#THEME_IMAGES#css/Vita#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>2719875314571594493
);
wwv_flow_api.create_theme_style(
 p_id=>wwv_flow_api.id(33326438953820847941)
,p_theme_id=>42
,p_name=>'Vita - Dark'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_IMAGES#less/theme/Vita-Dark.less'
,p_theme_roller_output_file_url=>'#THEME_IMAGES#css/Vita-Dark#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>3543348412015319650
);
wwv_flow_api.create_theme_style(
 p_id=>wwv_flow_api.id(33326439173723847941)
,p_theme_id=>42
,p_name=>'Vita - Red'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_IMAGES#less/theme/Vita-Red.less'
,p_theme_roller_output_file_url=>'#THEME_IMAGES#css/Vita-Red#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>1938457712423918173
);
wwv_flow_api.create_theme_style(
 p_id=>wwv_flow_api.id(33326439385431847941)
,p_theme_id=>42
,p_name=>'Vita - Slate'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_IMAGES#less/theme/Vita-Slate.less'
,p_theme_roller_output_file_url=>'#THEME_IMAGES#css/Vita-Slate#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>3291983347983194966
);
wwv_flow_api.component_end;
end;
/
