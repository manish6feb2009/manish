prompt --application/shared_components/user_interface/lovs/xx_integration_type
begin
--   Manifest
--     XX_INTEGRATION_TYPE
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>2065831728883124
,p_default_application_id=>100
,p_default_id_offset=>14758838573580759
,p_default_owner=>'DGTL_PLS'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(37705219944875075316)
,p_lov_name=>'XX_INTEGRATION_TYPE'
,p_lov_query=>'.'||wwv_flow_api.id(37705219944875075316)||'.'
,p_location=>'STATIC'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(37705220250431075318)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Inbound'
,p_lov_return_value=>'INBOUND'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(37705220640098075318)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Outbound'
,p_lov_return_value=>'OUTBOUND'
);
wwv_flow_api.component_end;
end;
/
