prompt --application/pages/page_00008
begin
--   Manifest
--     PAGE: 00008
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>2065831728883124
,p_default_application_id=>100
,p_default_id_offset=>14758838573580759
,p_default_owner=>'DGTL_PLS'
);
wwv_flow_api.create_page(
 p_id=>8
,p_user_interface_id=>wwv_flow_api.id(33326459299734847953)
,p_name=>'Administration'
,p_step_title=>'Administration'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_last_updated_by=>'VPARASHAR@DELOITTE.COM'
,p_last_upd_yyyymmddhh24miss=>'20191101130710'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(34202212933926676471)
,p_name=>'Administration'
,p_template=>wwv_flow_api.id(33326380712036847901)
,p_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--basic:t-Cards--displayIcons:t-Cards--3cols:t-Cards--desc-2ln:t-Cards--animColorFill'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apex_util.prepare_url(''f?p=''||:APP_ID||'':13:''||:APP_SESSION||'':::13'') card_link,',
'       ''Integration Master'' card_title,',
'       ''Integration Master''      card_text,',
'       --nvl(c.status,''Unknown Status'')||'', ''||',
'       ''List of All Integrations'' card_subtext,',
'        ''IM'' card_initials',
'from dual           ',
'union',
'select apex_util.prepare_url(''f?p=''||:APP_ID||'':18:''||:APP_SESSION||'':::18'') card_link,',
'       ''Job Master'' card_title,',
'       ''Job Master''      card_text,',
'       --nvl(c.status,''Unknown Status'')||'', ''||',
'       ''List of All Jobs'' card_subtext,',
'        ''IM'' card_initials',
'from dual  ',
'union',
'select apex_util.prepare_url(''f?p=''||:APP_ID||'':23:''||:APP_SESSION||'':::23'') card_link,',
'       ''Systems'' card_title,',
'       ''Systems''      card_text,',
'       --nvl(c.status,''Unknown Status'')||'', ''||',
'       ''List of All Systems'' card_subtext,',
'        ''IM'' card_initials',
'from dual         ',
'union',
'select apex_util.prepare_url(''f?p=''||:APP_ID||'':21:''||:APP_SESSION||'':::21'') card_link,',
'       ''Tracks'' card_title,',
'       ''Tracks''      card_text,',
'       --nvl(c.status,''Unknown Status'')||'', ''||',
'       ''List of All Tracks'' card_subtext,',
'        ''IM'' card_initials',
'from dual        ',
'union',
'select apex_util.prepare_url(''f?p=''||:APP_ID||'':28:''||:APP_SESSION||'':::28'') card_link,',
'       ''Modules'' card_title,',
'       ''Modules'' card_text,',
'       --nvl(c.status,''Unknown Status'')||'', ''||',
'       ''List of All Modules'' card_subtext,',
'        ''IM'' card_initials        ',
'from dual      '))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(33326396520019847911)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(34202213028828676472)
,p_query_column_id=>1
,p_column_alias=>'CARD_LINK'
,p_column_display_sequence=>1
,p_column_heading=>'Card Link'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(34202213138206676473)
,p_query_column_id=>2
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>2
,p_column_heading=>'Card Title'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(34202213271120676474)
,p_query_column_id=>3
,p_column_alias=>'CARD_TEXT'
,p_column_display_sequence=>3
,p_column_heading=>'Card Text'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(34202213414529676475)
,p_query_column_id=>4
,p_column_alias=>'CARD_SUBTEXT'
,p_column_display_sequence=>4
,p_column_heading=>'Card Subtext'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(34202213497120676476)
,p_query_column_id=>5
,p_column_alias=>'CARD_INITIALS'
,p_column_display_sequence=>5
,p_column_heading=>'Card Initials'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.component_end;
end;
/
