prompt --application/pages/page_00012
begin
--   Manifest
--     PAGE: 00012
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>2065831728883124
,p_default_application_id=>100
,p_default_id_offset=>14758838573580759
,p_default_owner=>'DGTL_PLS'
);
wwv_flow_api.create_page(
 p_id=>12
,p_user_interface_id=>wwv_flow_api.id(33326459299734847953)
,p_name=>'Critical Jobs Details'
,p_page_mode=>'MODAL'
,p_step_title=>'Critical Jobs Details'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_last_updated_by=>'VPARASHAR@DELOITTE.COM'
,p_last_upd_yyyymmddhh24miss=>'20191030202752'
);
wwv_flow_api.component_end;
end;
/
