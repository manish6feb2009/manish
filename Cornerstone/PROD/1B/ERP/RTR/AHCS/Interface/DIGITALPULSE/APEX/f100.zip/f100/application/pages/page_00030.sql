prompt --application/pages/page_00030
begin
--   Manifest
--     PAGE: 00030
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>2065831728883124
,p_default_application_id=>100
,p_default_id_offset=>14758838573580759
,p_default_owner=>'DGTL_PLS'
);
wwv_flow_api.create_page(
 p_id=>30
,p_user_interface_id=>wwv_flow_api.id(33326459299734847953)
,p_name=>'Job List'
,p_step_title=>'Job List'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_last_updated_by=>'WESCO_DP_SIT1_DEVELOPER'
,p_last_upd_yyyymmddhh24miss=>'20220202061707'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(16851003828343999)
,p_plug_name=>'Job List'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(33326379582771847900)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PROGRAM_NAME AS DESCRIPTION,TOTAL,SUCCESS,ERROR,WARNING,RANK() OVER(ORDER BY ERROR DESC) AS RNK FROM',
'(SELECT * FROM  ',
'(select XXJR.PROGRAM_NAME,XXJR.STATUS,',
'(SELECT COUNT(1) FROM XX_IMD_JOB_RUN_T WHERE program_name = xxjr.program_name',
'   AND (job_type=''C'' OR job_type=''O'')',
'   AND (extract(hour from systimestamp - cast (START_TIME as timestamp)) + 24 * ',
'	  extract(day from systimestamp - cast (START_TIME as timestamp ))) <= NVL(:P30_NEW,100000000)',
') AS TOTAL',
'from XX_IMD_JOB_RUN_T xxjr',
'where (extract(hour from systimestamp - cast (XXJR.START_TIME as timestamp)) + 24 * ',
'	  extract(day from systimestamp - cast (XXJR.START_TIME as timestamp ))) <= NVL(:P30_NEW,100000000)',
'  AND nvl(xxjr.TRACK,''xx'') = NVL(:P30_TRACK,nvl(xxjr.TRACK,''xx''))',
'  AND nvl(xxjr.PHASE_CODE,''xx'') = nvl(:P30_MODULE,nvl(xxjr.phase_code,''xx''))',
'  AND (xxjr.job_type=''C'' OR xxjr.job_type=''O'')',
') ',
'PIVOT (',
'  count(STATUS) FOR STATUS IN (''SUCCESS'' AS SUCCESS, ''ERROR'' AS ERROR, ''WARNING'' AS WARNING)',
')',
')',
'ORDER BY  6  DESC'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P30_NEW,P30_TRACK,P30_MODULE'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(16851107722343999)
,p_name=>'Job List'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'SEC_DP_USER'
,p_internal_uid=>4793440726750794
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16851548713344004)
,p_db_column_name=>'DESCRIPTION'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Description'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16851950439344005)
,p_db_column_name=>'TOTAL'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Total'
,p_column_link=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:RP:P6_PROGRAM_NAME,P6_TIME,P6_TRACK,P6_MODULE,P6_STATUS:#DESCRIPTION#,&P30_NEW.,&P30_TRACK.,&P30_MODULE.,'
,p_column_linktext=>'#TOTAL#'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16852324414344006)
,p_db_column_name=>'SUCCESS'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Success'
,p_column_link=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::P6_PROGRAM_NAME,P6_TIME,P6_TRACK,P6_MODULE,P6_STATUS:#DESCRIPTION#,&P30_NEW.,&P30_TRACK.,&P30_MODULE.,SUCCESS'
,p_column_linktext=>'#SUCCESS#'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16852677027344006)
,p_db_column_name=>'ERROR'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Error'
,p_column_link=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:RP:P6_PROGRAM_NAME,P6_TIME,P6_TRACK,P6_MODULE,P6_STATUS:#DESCRIPTION#,&P30_NEW.,&P30_TRACK.,&P30_MODULE.,ERROR'
,p_column_linktext=>'#ERROR#'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16853146827344007)
,p_db_column_name=>'WARNING'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Warning'
,p_column_link=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:RP:P6_PROGRAM_NAME,P6_TIME,P6_TRACK,P6_MODULE,P6_STATUS:#DESCRIPTION#,&P30_NEW.,&P30_TRACK.,&P30_MODULE.,WARNING'
,p_column_linktext=>'#WARNING#'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16853514558344007)
,p_db_column_name=>'RNK'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Rnk'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(16863871479496334)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'48063'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DESCRIPTION:TOTAL:SUCCESS:ERROR:WARNING:RNK'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16832882795380222)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(16851003828343999)
,p_button_name=>'Refresh'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(33326436807038847939)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Refresh'
,p_button_position=>'TOP'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16832579300380219)
,p_name=>'P30_NEW'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(16851003828343999)
,p_prompt=>'Period'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:Last 1 Hr;1,Last 2 Hr;2,Last 4 Hr;4,01 Day;24,07 Days;168,30 Days;720'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'All'
,p_lov_null_value=>'1000000000'
,p_cHeight=>1
,p_colspan=>2
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(33326435693473847937)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16832700088380220)
,p_name=>'P30_TRACK'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(16851003828343999)
,p_prompt=>'Track'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'SELECT TRACK AS A,TRACK as B FROM (SELECT DISTINCT TRACK FROM xx_imd_job_run_t)'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'All'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_grid_column=>5
,p_field_template=>wwv_flow_api.id(33326435693473847937)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16832864378380221)
,p_name=>'P30_MODULE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(16851003828343999)
,p_prompt=>'Module'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select PHASE_CODE as a, phase_code as b FROM (SELECT DISTINCT PHASE_CODE FROM xx_imd_job_run_t where TRACK= NVL(:P30_TRACK,PHASE_CODE))'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'All'
,p_lov_cascade_parent_items=>'P30_TRACK'
,p_ajax_items_to_submit=>'P30_TRACK'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_grid_column=>7
,p_field_template=>wwv_flow_api.id(33326435693473847937)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(16832985616380223)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(16832882795380222)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(16833140279380224)
,p_event_id=>wwv_flow_api.id(16832985616380223)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    XX_APEX_GET_ESS_DET_SEC_PKG.get_reqID_crit(null,null);',
'end ;',
'',
'begin',
'    XX_APEX_GET_ESS_DET_SEC_PKG.get_reqID_outbound(null,null);',
'end ;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(16833245611380225)
,p_event_id=>wwv_flow_api.id(16832985616380223)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(16851003828343999)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(3186188732471201)
,p_name=>'New_1'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P30_NEW'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(3186224897471202)
,p_event_id=>wwv_flow_api.id(3186188732471201)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(16851003828343999)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(3186390016471203)
,p_name=>'New_2'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P30_TRACK'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(3186409825471204)
,p_event_id=>wwv_flow_api.id(3186390016471203)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(16851003828343999)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(3186521668471205)
,p_name=>'New_3'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P30_MODULE'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(3186600758471206)
,p_event_id=>wwv_flow_api.id(3186521668471205)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(16851003828343999)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(16833977270380233)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'',
'',
'v_name varchar2(200);',
'v_token  varchar2(4000);',
'',
'BEGIN',
'',
'   ',
'   IF APEX_UTIL.GET_SESSION_STATE(''USER_NAME'') IS NULL THEN',
'        APEX_UTIL.REDIRECT_URL(''f?p=&APP_ID.:41:&APP_SESSION.'');',
'   ELSE',
'        APEX_CUSTOM_AUTH.SET_USER(APEX_UTIL.GET_SESSION_STATE(''USER_NAME''));',
'   END IF;',
'',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
