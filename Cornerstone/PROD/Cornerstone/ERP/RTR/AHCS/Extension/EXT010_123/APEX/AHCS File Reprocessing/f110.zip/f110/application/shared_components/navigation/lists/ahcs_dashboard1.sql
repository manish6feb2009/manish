prompt --application/shared_components/navigation/lists/ahcs_dashboard1
begin
--   Manifest
--     LIST: AHCS Dashboard1
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>1472436735558998
,p_default_application_id=>110
,p_default_id_offset=>7749063226623577
,p_default_owner=>'FININT'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(15465905364309580)
,p_name=>'AHCS Dashboard1'
,p_list_status=>'PUBLIC'
,p_required_patch=>wwv_flow_imp.id(14007101954826214)
);
wwv_flow_imp.component_end;
end;
/
