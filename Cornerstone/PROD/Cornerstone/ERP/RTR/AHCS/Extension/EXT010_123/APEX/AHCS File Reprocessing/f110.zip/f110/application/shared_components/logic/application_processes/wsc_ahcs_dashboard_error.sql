prompt --application/shared_components/logic/application_processes/wsc_ahcs_dashboard_error
begin
--   Manifest
--     APPLICATION PROCESS: WSC_AHCS_DASHBOARD_ERROR
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>1472436735558998
,p_default_application_id=>110
,p_default_id_offset=>7749063226623577
,p_default_owner=>'FININT'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(14913514912990501)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'WSC_AHCS_DASHBOARD_ERROR'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    L_BLOB           BLOB;',
'    L_CLOB           CLOB;',
'    L_DEST_OFFSET    INTEGER := 1;',
'    L_SRC_OFFSET     INTEGER := 1;',
'    L_LANG_CONTEXT   INTEGER := DBMS_LOB.DEFAULT_LANG_CTX;',
'    L_WARNING        INTEGER;',
'    L_LENGTH         INTEGER;',
'   P_SYSTEM_NAME_APP  varchar2(50)  := null;',
'BEGIN',
' ',
'   DBMS_LOB.CREATETEMPORARY(L_BLOB, FALSE);',
'    --get CLOB',
'   WSC_AHCS_DASHBOARD.wsc_ahcs_dashboard_error( L_CLOB,:P_SUBLEDGER,:P_STATUS,:P_ACC_STATUS,:P_ACCOUNTING_PERIOD, :P_SOURCE_SYSTEM);',
'  ',
'   ',
'    ',
'    -- tranform the input CLOB into a BLOB of the desired charset',
'    DBMS_LOB.CONVERTTOBLOB( DEST_LOB     => L_BLOB,',
'                            SRC_CLOB     => L_CLOB,',
'                            AMOUNT       => DBMS_LOB.LOBMAXSIZE,',
'                            DEST_OFFSET  => L_DEST_OFFSET,',
'                            SRC_OFFSET   => L_SRC_OFFSET,',
'                            BLOB_CSID    => NLS_CHARSET_ID(''WE8MSWIN1252''),',
'                            LANG_CONTEXT => L_LANG_CONTEXT,',
'                            WARNING      => L_WARNING',
'                          );',
'',
'   ',
'    L_LENGTH := DBMS_LOB.GETLENGTH(L_BLOB);  ',
'',
'    HTP.FLUSH;',
'    HTP.INIT;',
'',
'    OWA_UTIL.MIME_HEADER( ''text/csv'', FALSE);',
'',
'    HTP.P(''Content-length: '' || L_LENGTH);',
'    HTP.P(''Content-Disposition: attachment; filename="ERROR_REPORT.csv"'');',
'    HTP.P(''Set-Cookie: fileDownload=true; path=/'');',
'',
'    OWA_UTIL.HTTP_HEADER_CLOSE;',
'',
'    WPG_DOCLOAD.DOWNLOAD_FILE( L_BLOB );',
'',
'  EXCEPTION',
'    WHEN OTHERS THEN',
'      DBMS_LOB.FREETEMPORARY(L_BLOB);',
'      RAISE;',
'END;'))
,p_process_clob_language=>'PLSQL'
);
wwv_flow_imp.component_end;
end;
/
