prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>1472436735558998
,p_default_application_id=>110
,p_default_id_offset=>7749063226623577
,p_default_owner=>'FININT'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>'AHCS File Reprocessing'
,p_alias=>'AHCS-FILE-REPROCESSING'
,p_step_title=>'AHCS File Reprocessing'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'13'
,p_last_updated_by=>'WESCO_DEV_DEVELOPER'
,p_last_upd_yyyymmddhh24miss=>'20230502155220'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7805784995380089)
,p_plug_name=>'AHCS File Reprocessing'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(13915745205825935)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7974215913243998)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(13913768760825927)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>6
,p_plug_display_column=>3
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from (select * from (select  waict.file_name, to_char(actual_start_date at time zone ',
'''EST'',''YYYY-MM-DD HH24:MI:SS'') actual_start_date ,waict.status ',
'from user_scheduler_job_run_details usjrd, wsc_ahcs_int_control_t waict',
'where trunc(usjrd.actual_start_date) > trunc(sysdate)-30',
'and upper(substr(usjrd.job_name, instr(usjrd.job_name,''_'',1,2)+1, instr(usjrd.job_name,''_'',-1,4)-1 -',
' instr(usjrd.job_name,''_'',1,2))) = upper(replace(replace(waict.file_name, '' '', ''''), ''-'', ''_'')) ',
'and usjrd.job_name like (''%REPROCESSING%'')',
'union all',
'select waict.file_name,',
'to_char(CURRENT_TIMESTAMP at time zone ',
'''EST'',''YYYY-MM-DD HH24:MI:SS''),',
'waict.status ',
'from dba_scheduler_running_jobs usjrd, wsc_ahcs_int_control_t waict',
'where upper(substr(usjrd.job_name, instr(usjrd.job_name,''_'',1,2)+1, instr(usjrd.job_name,''_'',-1,4)-1 - ',
'instr(usjrd.job_name,''_'',1,2))) = upper(replace(replace(waict.file_name, '' '', ''''), ''-'', ''_'')) ',
'and usjrd.job_name like (''%REPROCESSING%'')) order by actual_start_date desc)',
'',
'-- select * from (select * from (select  waict.file_name, actual_start_date,waict.status ',
'-- from user_scheduler_job_run_details usjrd, wsc_ahcs_int_control_t waict',
'-- where trunc(usjrd.actual_start_date) > trunc(sysdate)-30',
'-- and upper(substr(usjrd.job_name, instr(usjrd.job_name,''_'',1,2)+1, instr(usjrd.job_name,''_'',-1,4)-1 -',
'--  instr(usjrd.job_name,''_'',1,2))) = upper(replace(replace(waict.file_name, '' '', ''''), ''-'', ''_'')) ',
'-- and usjrd.job_name like (''%REPROCESSING%'')',
'-- union all',
'-- select waict.file_name, sysdate,waict.status ',
'-- from dba_scheduler_running_jobs usjrd, wsc_ahcs_int_control_t waict',
'-- where upper(substr(usjrd.job_name, instr(usjrd.job_name,''_'',1,2)+1, instr(usjrd.job_name,''_'',-1,4)-1 - ',
'-- instr(usjrd.job_name,''_'',1,2))) = upper(replace(replace(waict.file_name, '' '', ''''), ''-'', ''_'')) ',
'-- and usjrd.job_name like (''%REPROCESSING%'')) order by actual_start_date desc)'))
,p_plug_source_type=>'NATIVE_IG'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'New'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7974729143244003)
,p_name=>'FILE_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FILE_NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'File Name'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>10
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>500
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7974890379244004)
,p_name=>'ACTUAL_START_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ACTUAL_START_DATE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Actual Start Date (EST)'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>20
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>19
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7974911192244005)
,p_name=>'STATUS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STATUS'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Status'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>200
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(7974651655244002)
,p_internal_uid=>2524350105704822
,p_is_editable=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>false
,p_toolbar_buttons=>null
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(7991795542711476)
,p_interactive_grid_id=>wwv_flow_imp.id(7974651655244002)
,p_static_id=>'25415'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(7991909237711476)
,p_report_id=>wwv_flow_imp.id(7991795542711476)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(7992423123711481)
,p_view_id=>wwv_flow_imp.id(7991909237711476)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(7974729143244003)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(7993395570711487)
,p_view_id=>wwv_flow_imp.id(7991909237711476)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(7974890379244004)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(7994222098711490)
,p_view_id=>wwv_flow_imp.id(7991909237711476)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(7974911192244005)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7806119260380093)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(7805784995380089)
,p_button_name=>'Reprocess'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(13980857053826104)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Reprocess'
,p_grid_new_row=>'Y'
,p_grid_column_span=>3
,p_grid_column=>3
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7973966094243995)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(7805784995380089)
,p_button_name=>'Refresh'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(13980857053826104)
,p_button_image_alt=>'Refresh'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7805828554380090)
,p_name=>'SUBLEDGER_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(7805784995380089)
,p_prompt=>'Application'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''EBS AP'' a, ''EBS AP'' b from dual',
'union all',
'select ''EBS AR'' a, ''EBS AR'' b from dual',
'union all',
'select ''EBS FA'' a, ''EBS FA'' b from dual',
'union all',
'select ''ERP POC'' a, ''ERP POC'' b from dual',
'union all',
'select ''CENTRAL'' a, ''Central'' b from dual',
'union all',
'select ''MF AP'' a, ''MF AP'' b from dual',
'union all',
'select ''MF AR'' a, ''MF AR'' b from dual',
'union all',
'select ''MF INVENTORY'' a, ''MF INVENTORY'' b from dual',
'union all',
'select ''PS FA'' a, ''PS FA'' b from dual',
'union all',
'select ''CLOUDPAY'' a, ''CLOUDPAY'' b from dual',
'union all',
'select ''ECLPS'' a, ''ECLPS'' b from dual',
'union all',
'select ''LEASES'' a, ''LEASES'' b from dual',
'union all',
'select ''SXEUS'' a, ''SXEUS'' b from dual',
'union all',
'select ''APS Treasury'' a, ''APS Treasury'' b from dual',
'union all',
'select ''CONCUR'' a, ''CONCUR'' b from dual'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(13978426674826096)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7805936361380091)
,p_name=>'FILE_NAME_2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(7805784995380089)
,p_prompt=>'File Name'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select   wad.file_name a, wad.file_name b from WSC_AHCS_DASHBOARD1_V wad',
'where 1=1',
'and wad.application = :SUBLEDGER_1',
'and wad.ERROR_REPROCESS_RECORDS > 0'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'SUBLEDGER_1'
,p_ajax_items_to_submit=>'SUBLEDGER_1'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(13978426674826096)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(7806493111380096)
,p_validation_name=>'New'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from dba_scheduler_running_jobs where job_name like case',
'when :SUBLEDGER_1 = ''EBS AP'' then',
'    ''%AP_REPROCESSING%''',
'when :SUBLEDGER_1 = ''EBS AR'' then',
'    ''%AR_REPROCESSING%''',
'when :SUBLEDGER_1 = ''EBS FA'' then',
'    ''%FA_REPROCESSING%''',
'when :SUBLEDGER_1 = ''ERP POC'' then',
'     ''%POC_REPROCESSING%''',
'when :SUBLEDGER_1 = ''CENTRAL'' then',
'    ''%CENTRAL_REPROCESSING%''',
'when :SUBLEDGER_1 = ''MF AP'' then',
'    ''%MFAP_REPROCESSING%''',
'when :SUBLEDGER_1 = ''MF AR'' then',
'    ''%MFAR_REPROCESSING%''',
'when :SUBLEDGER_1 = ''LEASES'' then',
'    ''%LEASES_REPROCESSING%''',
'when :SUBLEDGER_1 = ''CLOUDPAY'' then',
'    ''%CLOUDPAY_REPROCESSING%''',
'when :SUBLEDGER_1 = ''PS FA'' then',
'    ''%PSFA_REPROCESSING%''',
'when :SUBLEDGER_1 = ''TW'' then',
'    ''%TW_REPROCESSING%''',
'when :SUBLEDGER_1 = ''MF INVENTORY'' then',
'    ''%MFINV_REPROCESSING%''',
'when :SUBLEDGER_1 = ''ECLPS'' then',
'    ''%ECLIPSE_REPROCESSING%''',
'when :SUBLEDGER_1 = ''CONCUR'' then',
'    ''%CONCUR_REPROCESSING%''',
'when :SUBLEDGER_1 = ''SXE'' then',
'    ''%SXE_REPROCESSING%''',
'else null',
'    end'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'Some file is being processed. Please wait !'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(7974040129243996)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(7973966094243995)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7974118242243997)
,p_event_id=>wwv_flow_imp.id(7974040129243996)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(7974215913243998)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(7806589446380097)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'WSC_AHCS_REPROCESSING_PKG.reprocessing_async (:file_name_2);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'File submitted for reprocessing'
,p_internal_uid=>7806589446380097
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(7806281381380094)
,p_process_sequence=>10
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'New'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>7806281381380094
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(7806606745380098)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New_2'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_user_name varchar2(200);',
'v_jwt_token  varchar2(4000);',
'',
'BEGIN',
'/*',
'APEX_CUSTOM_AUTH.SET_USER(''WESCO_USER'');',
'APEX_UTIL.SET_SESSION_STATE(''USER_NAME'',''WESCO_USER'');',
'*/',
'IF  APEX_UTIL.GET_SESSION_STATE(''USER_NAME'') IS NULL THEN',
'   ',
'  xx_apex_user_security_pkg.main(v_jwt_token,v_user_name,null);  ',
' ',
'   ',
'    APEX_UTIL.SET_SESSION_STATE(''USER_NAME'',v_user_name);',
'    APEX_UTIL.SET_SESSION_STATE(''JWT_TOKEN'',v_jwt_token);',
'   ',
'    IF APEX_UTIL.GET_SESSION_STATE(''USER_NAME'') IS NULL THEN',
'        APEX_UTIL.REDIRECT_URL(''f?p=&APP_ID.:9999:&APP_SESSION.'');',
'        -- null;',
'   ELSE',
'        APEX_CUSTOM_AUTH.SET_USER(APEX_UTIL.GET_SESSION_STATE(''USER_NAME''));',
'        ',
'   END IF;',
'   ',
'ELSE',
'   APEX_CUSTOM_AUTH.SET_USER(APEX_UTIL.GET_SESSION_STATE(''USER_NAME''));  ',
'   ',
'END IF;',
'',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>7806606745380098
);
wwv_flow_imp.component_end;
end;
/
