prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>1472436735558998
,p_default_application_id=>110
,p_default_id_offset=>7749063226623577
,p_default_owner=>'FININT'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Welcome to AHCS Dashboard'
,p_alias=>'HOME1'
,p_step_title=>'Welcome to AHCS Dashboard'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'11'
,p_last_updated_by=>'WESCO_UAT_DEVELOPER'
,p_last_upd_yyyymmddhh24miss=>'20220523053320'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14024409479826528)
,p_plug_name=>'Welcome to AHCS Dashboard'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(13915745205825935)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'BELOW'
,p_menu_id=>wwv_flow_imp.id(13858095109825796)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(13982247000826106)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7473576621032590)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(14024409479826528)
,p_button_name=>'Dashboard1'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(13980857053826104)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'OIC Dashboard View'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7473671893032591)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(14024409479826528)
,p_button_name=>'Dashboard2'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(13980857053826104)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Subledger Dashboard View'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp.component_end;
end;
/
