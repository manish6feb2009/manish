prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1701052144005286
,p_default_application_id=>120
,p_default_id_offset=>0
,p_default_owner=>'FININT'
);
wwv_flow_api.create_page(
 p_id=>2
,p_user_interface_id=>wwv_flow_api.id(15978005807702965)
,p_name=>'OIC Purge Dashboard'
,p_alias=>'OIC-PURGE-DASHBOARD'
,p_step_title=>'OIC Purge Dashboard'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.error-message {',
'    display: none;',
'    color: red;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_last_updated_by=>'WESCO_DEV_DEVELOPER'
,p_last_upd_yyyymmddhh24miss=>'20230821150410'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(15991116208712301)
,p_plug_name=>'Upload File'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(15888435455702824)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(15991910944712309)
,p_name=>'Execution History Details'
,p_parent_plug_id=>wwv_flow_api.id(15991116208712301)
,p_template=>wwv_flow_api.id(15888435455702824)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
' SELECT',
'     BATCH_ID,',
' DECODE(SUBLEDGER,',
'            ''TW'', ''APS TREASURY'',',
'            ''CENTRAL'', ''Central'',',
'            ''CLOUDPAY'', ''CloudPay'',',
'            ''CONCUR'', ''CONCUR'',',
'            ''EBS AP'', ''EBS AP'',',
'            ''EBS AR'', ''EBS AR'',',
'            ''EBS FA'', ''EBS FA'',',
'            ''ECLIPSE'', ''ECLPS'',',
'            ''ERP_POC'', ''ERP POC'',',
'            ''LEASES'', ''LEASES'',',
'            ''MF AP'', ''MF AP'',',
'            ''MF AR'', ''MF AR'',',
'            ''MF INV'', ''MF INVENTORY'',',
'            ''Oracle LSI'', ''ORACLE LSI'',',
'            ''PS FA'', ''PS FA'',',
'            ''SXE'', ''SXEUS''',
'     ) AS SUBLEDGER,',
' LEDGER,',
' (select count(1) from WSC_AHCS_TXN_PURGE_LINE_T line where line.batch_id = hdr.batcH_id',
' and line.ledger = hdr.ledger)COUNT_OF_TRANSACTIONS,',
'--  to_char(EXECUTION_DATE, ''YYYY-MM-DD HH24:MI:SS'') as EXECUTION_DATE',
' TO_CHAR(',
'           FROM_TZ(EXECUTION_DATE, ''UTC'') AT TIME ZONE ''America/New_York'', ',
'           ''YYYY-MM-DD HH24:MI:SS''',
'         ) as EXECUTION_DATE, -- need in EST',
' USERNAME,',
' ''Execution Report'' as Accounting_Hub_Maintanance_Execution_Report ',
' FROM',
'     wsc_ahcs_txn_purge_hdr_t hdr',
' where nvl(ledger,1) = decode(:P2_LEDGER_SEARCH,''All'',nvl(ledger,1),:P2_LEDGER_SEARCH)',
'and SUBLEDGER = decode(:P2_SUBLEDGER_SEARCH,''All'',subledger,:P2_SUBLEDGER_SEARCH)',
'--  and hdr.SUBLEDGER = DECODE(:P2_SUBLEDGER_SEARCH,',
'-- ''All'', hdr.subledger,',
'--               ''TW'', ''APS TREASURY'',',
'--             ''CENTRAL'', ''Central'',',
'--             ''CLOUDPAY'', ''CloudPay'',',
'--             ''CONCUR'', ''CONCUR'',',
'--             ''EBS AP'', ''EBS AP'',',
'--             ''EBS AR'', ''EBS AR'',',
'--             ''EBS FA'', ''EBS FA'',',
'--             ''ECLIPSE'', ''ECLPS'',',
'--             ''ERP_POC'', ''ERP POC'',',
'--             ''LEASES'', ''LEASES'',',
'--             ''MF AP'', ''MF AP'',',
'--             ''MF AR'', ''MF AR'',',
'--             ''MF INV'', ''MF INVENTORY'',',
'--             ''Oracle LSI'', ''ORACLE LSI'',',
'--             ''PS FA'', ''PS FA'',',
'--             ''SXE'', ''SXEUS''',
'--        )',
' ORDER BY',
'     1 DESC',
'     ',
'     ',
'-- SELECT distinct',
'--     hdr.BATCH_ID,',
'-- DECODE(hdr.Subledger,',
'--               ''TW'', ''APS TREASURY'',',
'--            ''CENTRAL'', ''Central'',',
'--            ''CLOUDPAY'', ''CloudPay'',',
'--            ''CONCUR'', ''CONCUR'',',
'--            ''EBS AP'', ''EBS AP'',',
'--            ''EBS AR'', ''EBS AR'',',
'--            ''EBS FA'', ''EBS FA'',',
'--            ''ECLIPSE'', ''ECLPS'',',
'--            ''ERP_POC'', ''ERP POC'',',
'--            ''LEASES'', ''LEASES'',',
'--            ''MF AP'', ''MF AP'',',
'--            ''MF AR'', ''MF AR'',',
'--            ''MF INV'', ''MF INVENTORY'',',
'--            ''Oracle LSI'', ''ORACLE LSI'',',
'--            ''PS FA'', ''PS FA'',',
'--            ''SXE'', ''SXEUS''',
'--        ) as SUBLEDGER,',
'-- hdr.LEDGER,',
'-- hdr.COUNT_OF_TRANSACTIONS,',
'-- to_char(hdr.EXECUTION_DATE, ''YYYY-MM-DD HH24:MI:SS'') as EXECUTION_DATE,',
'-- hdr.USERNAME,',
'-- ''Execution Report'' as Accounting_Hub_Maintanance_Execution_Report ',
'-- FROM',
'--     wsc_ahcs_txn_purge_hdr_t hdr, WSC_AHCS_TXN_PURGE_LINE_T line',
'-- where hdr.ledger = decode(:P2_LEDGER_SEARCH,''All'',hdr.ledger,:P2_LEDGER_SEARCH)',
'-- -- and hdr.SUBLEDGER = decode(:P2_SUBLEDGER_SEARCH,''All'',hdr.subledger,:P2_SUBLEDGER_SEARCH)',
'-- and hdr.batch_id = line.batch_id',
'-- and hdr.LEDGER = line.LEDGER',
'-- and hdr.SUBLEDGER = DECODE(:P2_SUBLEDGER_SEARCH,',
'-- ''All'', hdr.subledger,',
'--               ''TW'', ''APS TREASURY'',',
'--            ''CENTRAL'', ''Central'',',
'--            ''CLOUDPAY'', ''CloudPay'',',
'--            ''CONCUR'', ''CONCUR'',',
'--            ''EBS AP'', ''EBS AP'',',
'--            ''EBS AR'', ''EBS AR'',',
'--            ''EBS FA'', ''EBS FA'',',
'--            ''ECLIPSE'', ''ECLPS'',',
'--            ''ERP_POC'', ''ERP POC'',',
'--            ''LEASES'', ''LEASES'',',
'--            ''MF AP'', ''MF AP'',',
'--            ''MF AR'', ''MF AR'',',
'--            ''MF INV'', ''MF INVENTORY'',',
'--            ''Oracle LSI'', ''ORACLE LSI'',',
'--            ''PS FA'', ''PS FA'',',
'--            ''SXE'', ''SXEUS''',
'--        )',
'-- ORDER BY',
'--     1 DESC',
'',
'',
'-- -- SELECT',
'-- --     BATCH_ID,',
'-- -- DECODE(SUBLEDGER,',
'-- --            ''TW'', ''APS TREASURY'',',
'-- --            ''CENTRAL'', ''Central'',',
'-- --            ''CLOUDPAY'', ''CloudPay'',',
'-- --            ''CONCUR'', ''CONCUR'',',
'-- --            ''EBS AP'', ''EBS AP'',',
'-- --            ''EBS AR'', ''EBS AR'',',
'-- --            ''EBS FA'', ''EBS FA'',',
'-- --            ''ECLIPSE'', ''ECLPS'',',
'-- --            ''ERP_POC'', ''ERP POC'',',
'-- --            ''LEASES'', ''LEASES'',',
'-- --            ''MF AP'', ''MF AP'',',
'-- --            ''MF AR'', ''MF AR'',',
'-- --            ''MF INV'', ''MF INVENTORY'',',
'-- --            ''Oracle LSI'', ''ORACLE LSI'',',
'-- --            ''PS FA'', ''PS FA'',',
'-- --            ''SXE'', ''SXEUS''',
'-- --     ) AS SUBLEDGER,',
'-- -- LEDGER,',
'-- -- COUNT_OF_TRANSACTIONS,',
'-- -- to_char(EXECUTION_DATE, ''YYYY-MM-DD HH24:MI:SS'') as EXECUTION_DATE,',
'-- -- USERNAME,',
'-- -- ''Execution Report'' as Accounting_Hub_Maintanance_Execution_Report ',
'-- -- FROM',
'-- --     wsc_ahcs_txn_purge_hdr_t',
'-- -- where ledger = decode(:P2_LEDGER_SEARCH,''All'',ledger,:P2_LEDGER_SEARCH)',
'-- -- and SUBLEDGER = decode(:P2_SUBLEDGER_SEARCH,''All'',subledger,:P2_SUBLEDGER_SEARCH)',
'-- -- ORDER BY',
'-- --     1 DESC'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P2_SUBLEDGER_SEARCH,P2_LEDGER_SEARCH'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(15915977597702847)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(15992011020712310)
,p_query_column_id=>1
,p_column_alias=>'BATCH_ID'
,p_column_display_sequence=>10
,p_column_heading=>'Batch Id'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(16614082027716238)
,p_query_column_id=>2
,p_column_alias=>'SUBLEDGER'
,p_column_display_sequence=>20
,p_column_heading=>'Subledger'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(16614187133716239)
,p_query_column_id=>3
,p_column_alias=>'LEDGER'
,p_column_display_sequence=>30
,p_column_heading=>'Ledger'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(16614230116716240)
,p_query_column_id=>4
,p_column_alias=>'COUNT_OF_TRANSACTIONS'
,p_column_display_sequence=>40
,p_column_heading=>'Count Of Transactions'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(16614363699716241)
,p_query_column_id=>5
,p_column_alias=>'EXECUTION_DATE'
,p_column_display_sequence=>50
,p_column_heading=>'Execution Date (EST)'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(16614435701716242)
,p_query_column_id=>6
,p_column_alias=>'USERNAME'
,p_column_display_sequence=>60
,p_column_heading=>'Username'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(16614783628716245)
,p_query_column_id=>7
,p_column_alias=>'ACCOUNTING_HUB_MAINTANANCE_EXECUTION_REPORT'
,p_column_display_sequence=>70
,p_column_heading=>'Accounting Hub Maintanance Execution Report'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.::P3_BATCH_ID,P3_LEDGER,P3_SUBLEDGER:#BATCH_ID#,#LEDGER#,#SUBLEDGER#'
,p_column_linktext=>'#ACCOUNTING_HUB_MAINTANANCE_EXECUTION_REPORT#'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(15991334187712303)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(15991116208712301)
,p_button_name=>'Submit'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(15953564518702893)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Submit'
,p_button_position=>'BELOW_BOX'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(15994324030712333)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(15991116208712301)
,p_button_name=>'Download_Template'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(15953564518702893)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Download Template'
,p_button_position=>'BELOW_BOX'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7302447522984715)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(15991910944712309)
,p_button_name=>'Search'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(15953564518702893)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Search'
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_column=>5
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7301987328984710)
,p_name=>'P2_SUBLEDGER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(15991116208712301)
,p_prompt=>'Subledger'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ''APS TREASURY'', ''TW'' FROM DUAL',
'UNION ALL',
'SELECT ''Central'', ''CENTRAL'' FROM DUAL',
'UNION ALL',
'SELECT ''CloudPay'', ''CLOUDPAY'' FROM DUAL',
'UNION ALL',
'SELECT ''CONCUR'', ''CONCUR'' FROM DUAL',
'UNION ALL',
'SELECT ''EBS AP'', ''EBS AP'' FROM DUAL',
'UNION ALL',
'SELECT ''EBS AR'', ''EBS AR'' FROM DUAL',
'UNION ALL',
'SELECT ''EBS FA'', ''EBS FA'' FROM DUAL',
'UNION ALL',
'SELECT ''ECLPS'', ''ECLIPSE'' FROM DUAL',
'UNION ALL',
'SELECT ''ERP POC'', ''ERP_POC'' FROM DUAL',
'UNION ALL',
'SELECT ''LEASES'', ''LEASES'' FROM DUAL',
'UNION ALL',
'SELECT ''MF AP'', ''MF AP'' FROM DUAL',
'UNION ALL',
'SELECT ''MF AR'', ''MF AR'' FROM DUAL',
'UNION ALL',
'SELECT ''MF INVENTORY'', ''MF INV'' FROM DUAL',
'UNION ALL',
'SELECT ''ORACLE LSI'', ''Oracle LSI'' FROM DUAL',
'UNION ALL',
'SELECT ''PS FA'', ''PS FA'' FROM DUAL',
'UNION ALL',
'SELECT ''SXEUS'', ''SXE'' FROM DUAL;',
''))
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(15951701941702889)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7302251271984713)
,p_name=>'P2_SUBLEDGER_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(15991910944712309)
,p_item_default=>'All'
,p_prompt=>'Subledger Search'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''All'' a, ''All'' b from dual ',
'union all',
'-- select distinct  source_application a, source_application b from wsc_ahcs_int_control_t order by 1 ;',
'SELECT ''APS TREASURY'' AS Subledger, ''TW'' AS return_value FROM DUAL',
'UNION ALL',
'SELECT ''Central'' AS Subledger, ''CENTRAL'' AS return_value FROM DUAL',
'UNION ALL',
'SELECT ''CloudPay'' AS Subledger, ''CLOUDPAY'' AS return_value FROM DUAL',
'UNION ALL',
'SELECT ''CONCUR'' AS Subledger, ''CONCUR'' AS return_value FROM DUAL',
'UNION ALL',
'SELECT ''EBS AP'' AS Subledger, ''EBS AP'' AS return_value FROM DUAL',
'UNION ALL',
'SELECT ''EBS AR'' AS Subledger, ''EBS AR'' AS return_value FROM DUAL',
'UNION ALL',
'SELECT ''EBS FA'' AS Subledger, ''EBS FA'' AS return_value FROM DUAL',
'UNION ALL',
'SELECT ''ECLPS'' AS Subledger, ''ECLIPSE'' AS return_value FROM DUAL',
'UNION ALL',
'SELECT ''ERP POC'' AS Subledger, ''ERP_POC'' AS return_value FROM DUAL',
'UNION ALL',
'SELECT ''LEASES'' AS Subledger, ''LEASES'' AS return_value FROM DUAL',
'UNION ALL',
'SELECT ''MF AP'' AS Subledger, ''MF AP'' AS return_value FROM DUAL',
'UNION ALL',
'SELECT ''MF AR'' AS Subledger, ''MF AR'' AS return_value FROM DUAL',
'UNION ALL',
'SELECT ''MF INVENTORY'' AS Subledger, ''MF INV'' AS return_value FROM DUAL',
'UNION ALL',
'SELECT ''ORACLE LSI'' AS Subledger, ''Oracle LSI'' AS return_value FROM DUAL',
'UNION ALL',
'SELECT ''PS FA'' AS Subledger, ''PS FA'' AS return_value FROM DUAL',
'UNION ALL',
'SELECT ''SXEUS'' AS Subledger, ''SXE'' AS return_value FROM DUAL;',
''))
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(15951606369702889)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7302390736984714)
,p_name=>'P2_LEDGER_SEARCH'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(15991910944712309)
,p_item_default=>'All'
,p_prompt=>'Ledger Search'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''All'' a, ''All'' b from dual ',
'union all',
'select a,b from (select distinct  ledger_name a, ledger_name b from wsc_gl_legal_entities_t order by 1 );'))
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(15951606369702889)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(15991243430712302)
,p_name=>'P2_FILE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(15991116208712301)
,p_use_cache_before_default=>'NO'
,p_prompt=>'File'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(15951701941702889)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'REQUEST'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16781397871100030)
,p_name=>'P2_ERROR_MSG'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(15991116208712301)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16948891816405105)
,p_name=>'P2_ERROR_MESSAGE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(15991116208712301)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(15994456741712334)
,p_name=>'New_1'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(15994324030712333)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(15994578485712335)
,p_event_id=>wwv_flow_api.id(15994456741712334)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'javascript:window.open(''f?p=&APP_ID.:2:&SESSION.:APPLICATION_PROCESS=WSC_DELETE_DATA:NO'', ''_self'');'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(16614592303716243)
,p_name=>'New_2'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(7302447522984715)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(16614630329716244)
,p_event_id=>wwv_flow_api.id(16614592303716243)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(15991910944712309)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(18065308769412101)
,p_name=>'New'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(15991334187712303)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(18065455424412102)
,p_event_id=>wwv_flow_api.id(18065308769412101)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(15991895532712308)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'username varchar2(200) := APEX_UTIL.GET_SESSION_STATE(''USER_NAME'');',
'begin :P_USER_NAME := username; end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(15991447914712304)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'PLUGIN_NL.AMIS.SCHEFFER.PROCESS.EXCEL2COLLECTION'
,p_process_name=>'SheetSelector'
,p_attribute_01=>'P2_FILE'
,p_attribute_02=>'XL1'
,p_attribute_03=>'1'
,p_attribute_04=>','
,p_attribute_05=>'"'
,p_attribute_07=>'Y'
,p_attribute_08=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(15991558763712305)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PLSQLCODE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor cur_delete_data is select',
'    -- c001 LEDGER,c002 TRANSACTION_NUMBER,to_date(c003,''MM/DD/YYYY'') TRANSACTION_DATE',
'    trim(c001) LEDGER,trim(c002) TRANSACTION_NUMBER,trim(c003) TRANSACTION_DATE',
'    from ',
'        apex_collections c',
'    WHERE',
'            c.collection_name = ''XL1''',
'        AND seq_id > 1;',
'',
'-- cursor cur_delete_data_v2 is select',
'--     c001 LEDGER,c002 TRANSACTION_NUMBER,to_date(c003,''DD-MON-YY'') TRANSACTION_DATE',
'--     from ',
'--         apex_collections c',
'--     WHERE',
'--             c.collection_name = ''XL1''',
'--         AND seq_id > 1;',
'',
'cursor cur_LEDGER_data is select',
'    distinct trim(c001) LEDGER',
'    from ',
'        apex_collections c',
'    WHERE',
'            c.collection_name = ''XL1''',
'        AND seq_id > 1;',
'',
'',
'    LV_BATCH_ID NUMBER;',
'    LV_USERNAME VARCHAR2(100) := :P_USER_NAME;',
'    LV_COUNT_DATA number;',
'    lv_err varchar2(1000);',
'',
'    -- provided_date_str VARCHAR2(20) := ''07/28/2023'';',
'  date_format VARCHAR2(20) := ''MM/DD/YYYY'';',
'  valid_date DATE;',
'begin',
'',
'if upper(substr(:P2_FILE,instr(:P2_FILE,''.'',1)+1,length(:P2_FILE)-instr(:P2_FILE,''.'',1))) <> upper(''CSV'') then',
'    ',
'     APEX_ERROR.ADD_ERROR (',
'            p_message => ''Please Upload CSV Template'',',
'            p_display_location => apex_error.c_inline_in_notification',
'        );',
'         return;',
'end if;',
'if :P2_FILE is null then',
'APEX_ERROR.ADD_ERROR (',
'            p_message => ''Please select a file to upload.'',',
'            p_display_location => apex_error.c_inline_in_notification',
'        );',
'         return;',
'else',
'    ',
'',
'FOR temp_data IN cur_delete_data LOOP',
'if temp_data.LEDGER is null or  temp_data.TRANSACTION_NUMBER is null or  temp_data.TRANSACTION_DATE is null then',
'APEX_ERROR.ADD_ERROR (',
'            p_message => ''Required fields are missing'',',
'            p_display_location => apex_error.c_inline_in_notification',
'        );',
'        return;',
'end if;',
'',
'BEGIN',
'    valid_date := TO_DATE(temp_data.TRANSACTION_DATE, date_format);',
'  EXCEPTION',
'    WHEN OTHERS THEN',
'      APEX_ERROR.ADD_ERROR (',
'            p_message => ''The provided date should be in MM/DD/YYYY format.'',',
'            p_display_location => apex_error.c_inline_in_notification',
'        );',
'        return;',
'  END;',
'',
'end loop;',
'LV_BATCH_ID := WSC_AHCS_PURGE_FILE_BATCH_ID_SEQ.NEXTVAL;',
'/*insert into wsc_tbl_time_t values(''start''||to_char(LV_BATCH_ID)||:P2_SUBLEDGER,sysdate,34343);',
'        commit;*/',
'    begin',
'    FOR temp_data IN cur_ledger_data LOOP',
'        insert into WSC_AHCS_TXN_PURGE_HDR_T (BATCH_ID, SUBLEDGER, LEDGER, EXECUTION_DATE, USERNAME, CREATED_BY,',
'            CREATED_DATE,',
'            LAST_UPDATED_BY,',
'            LAST_UPDATED_DATE) VALUES (LV_BATCH_ID, :P2_SUBLEDGER,temp_data.ledger, sysdate,LV_USERNAME,LV_USERNAME, SYSDATE, LV_USERNAME, SYSDATE);',
'    end loop;',
'    COMMIT;',
'    exception',
'    when others then',
'        dbms_output.put_line(sqlerrm);',
'    end;',
'',
'    ',
'',
'    begin',
'    FOR temp_data IN cur_delete_data LOOP',
'	    insert into WSC_AHCS_TXN_PURGE_LINE_T (BATCH_ID, LINE_ID, LEDGER, TRANSACTION_NUMBER, TRANSACTION_DATE, SUBLEDGER, CREATED_BY, CREATED_DATE,',
'        LAST_UPDATED_BY,',
'        LAST_UPDATED_DATE) VALUES (LV_BATCH_ID,WSC_AHCS_PURGE_FILE_LINE_ID_SEQ.nextval, ',
'        temp_data.LEDGER, temp_data.TRANSACTION_NUMBER, temp_data.TRANSACTION_DATE, :P2_SUBLEDGER,',
'        LV_USERNAME, SYSDATE, LV_USERNAME, SYSDATE);',
'    END LOOP;',
'    COMMIT;',
'    exception',
'    when others then',
'        dbms_output.put_line(sqlerrm);',
'        lv_err := sqlerrm;',
'       /* insert into wsc_tbl_time_t values(lv_err,sysdate,34343);',
'        commit;*/',
'    --     begin',
'    -- FOR temp_data IN cur_delete_data_v2 LOOP',
'	--     insert into WSC_AHCS_TXN_PURGE_LINE_T (BATCH_ID, LINE_ID, LEDGER, TRANSACTION_NUMBER, TRANSACTION_DATE, SUBLEDGER, CREATED_BY, CREATED_DATE,',
'    --     LAST_UPDATED_BY,',
'    --     LAST_UPDATED_DATE) VALUES (LV_BATCH_ID,WSC_AHCS_TXN_PURGE_LINE_ID_SEQ.nextval, ',
'    --     temp_data.LEDGER, temp_data.TRANSACTION_NUMBER, temp_data.TRANSACTION_DATE, :P2_SUBLEDGER,',
'    --     LV_USERNAME, SYSDATE, LV_USERNAME, SYSDATE);',
'    -- END LOOP;',
'    -- COMMIT;',
'    -- exception',
'    -- when others then',
'    --     dbms_output.put_line(sqlerrm);',
'    --     lv_err := sqlerrm;',
'    --             insert into wsc_tbl_time_t values(lv_err,sysdate,43434);',
'    --     commit;',
'    -- end;',
'    end;',
'',
'    -- FOR temp_data IN cur_delete_data LOOP',
'	--     insert into WSC_AHCS_TXN_PURGE_LINE_T (BATCH_ID, LINE_ID, LEDGER, TRANSACTION_NUMBER, TRANSACTION_DATE, SUBLEDGER, CREATED_BY, CREATED_DATE,',
'    --     LAST_UPDATED_BY,',
'    --     LAST_UPDATED_DATE) VALUES (LV_BATCH_ID,WSC_AHCS_TXN_PURGE_LINE_ID_SEQ.nextval, ',
'    --     temp_data.LEDGER, temp_data.TRANSACTION_NUMBER, temp_data.TRANSACTION_DATE, :P2_SUBLEDGER,',
'    --     LV_USERNAME, SYSDATE, LV_USERNAME, SYSDATE);',
'    -- END LOOP;',
'    -- COMMIT;',
'',
'    FOR temp_data IN cur_ledger_data LOOP',
'        update WSC_AHCS_TXN_PURGE_HDR_T set COUNT_OF_TRANSACTIONS = (select count(1) from WSC_AHCS_TXN_PURGE_LINE_T where LEDGER = temp_data.LEDGER',
'        and batch_id = lv_batch_id) where batch_id = lv_batch_id and LEDGER = temp_data.LEDGER;',
'    end loop;',
'    commit;',
'',
'    ',
'    -- wsc_delete_data_pkg.delete_data_system (LV_BATCH_ID);',
'',
'dbms_scheduler.create_job (',
'  job_name   =>  ''WSC_DELETE_RUN_''||to_char(sysdate,''ddmonyyyyhh24miss'')||to_char(lv_batch_id),',
'  job_type   => ''PLSQL_BLOCK'',',
'  job_action => ',
'    ''BEGIN ',
'       WSC_AHCS_TXN_PURGE_PKG.delete_data_system (''||LV_BATCH_ID||'');',
'     END;'',',
'  enabled   =>  TRUE,  ',
'  auto_drop =>  TRUE, ',
'  comments  =>  ''WSC_DELETE_RUN'');',
'/*insert into wsc_tbl_time_t values(''end'',sysdate,34343);',
'        commit;*/',
'',
'end if;',
'end;',
'',
'',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(15991726375712307)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_user_name varchar2(200);',
'v_jwt_token  varchar2(4000);',
'',
'BEGIN',
'',
'-- APEX_CUSTOM_AUTH.SET_USER(''WESCO_USER'');',
'-- APEX_UTIL.SET_SESSION_STATE(''USER_NAME'',''WESCO_USER'');',
'',
'IF  APEX_UTIL.GET_SESSION_STATE(''USER_NAME'') IS NULL THEN',
'   ',
'  xx_apex_user_security_pkg.main(v_jwt_token,v_user_name,null);  ',
'  ',
'  APEX_UTIL.SET_SESSION_STATE(''USER_NAME'',v_user_name);',
'    APEX_UTIL.SET_SESSION_STATE(''JWT_TOKEN'',v_jwt_token);',
'   ',
'    IF APEX_UTIL.GET_SESSION_STATE(''USER_NAME'') IS NULL THEN',
'        APEX_UTIL.REDIRECT_URL(''f?p=&APP_ID.:9999:&APP_SESSION.'');',
'   ELSE',
'        APEX_CUSTOM_AUTH.SET_USER(APEX_UTIL.GET_SESSION_STATE(''USER_NAME''));',
'        ',
'   END IF;',
'   ',
'ELSE',
'   APEX_CUSTOM_AUTH.SET_USER(APEX_UTIL.GET_SESSION_STATE(''USER_NAME''));  ',
'   ',
'END IF;',
'',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
