prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1701052144005286
,p_default_application_id=>120
,p_default_id_offset=>0
,p_default_owner=>'FININT'
);
wwv_flow_api.create_page(
 p_id=>3
,p_user_interface_id=>wwv_flow_api.id(15978005807702965)
,p_name=>'Execution_Report'
,p_alias=>'EXECUTION-REPORT'
,p_step_title=>'Execution Report'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_last_updated_by=>'WESCO_DEV_DEVELOPER'
,p_last_upd_yyyymmddhh24miss=>'20230821091146'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(16614885023716246)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(15886594103702822)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select BATCH_ID,',
'       LINE_ID,',
'       SUBLEDGER,',
'       TRANSACTION_NUMBER,',
'       TRANSACTION_DATE,',
'       LEDGER,',
'       PURGE_ELIGIBLE,',
'       PURGE_STATUS,',
'       PURGE_STATUS_MESSAGE,',
'       CREATED_BY,',
'       CREATED_DATE,',
'       LAST_UPDATED_BY,',
'       LAST_UPDATED_DATE ',
'  from WSC_AHCS_TXN_PURGE_LINE_T',
'  where batch_id = :p3_batch_id ',
'--   and subledger = :P3_SUBLEDGER ',
'  and nvl(ledger,''NA'') = nvl(:P3_LEDGER,''NA'')',
'and subledger =   DECODE(:P3_SUBLEDGER ,',
'''All'', subledger,',
'              ''APS TREASURY'', ''TW'',',
'    ''Central'', ''CENTRAL'',',
'    ''CloudPay'', ''CLOUDPAY'',',
'    ''CONCUR'', ''CONCUR'',',
'    ''EBS AP'', ''EBS AP'',',
'    ''EBS AR'', ''EBS AR'',',
'    ''EBS FA'', ''EBS FA'',',
'    ''ECLPS'', ''ECLIPSE'',',
'    ''ERP POC'', ''ERP_POC'',',
'    ''LEASES'', ''LEASES'',',
'    ''MF AP'', ''MF AP'',',
'    ''MF AR'', ''MF AR'',',
'    ''MF INVENTORY'', ''MF INV'',',
'    ''ORACLE LSI'', ''Oracle LSI'',',
'    ''PS FA'', ''PS FA'',',
'    ''SXEUS'', ''SXE''',
'       )'))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P3_BATCH_ID,P3_SUBLEDGER,P3_LEDGER'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'New'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(16782535565100042)
,p_name=>'BATCH_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BATCH_ID'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(16782649348100043)
,p_name=>'LINE_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LINE_ID'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>20
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(16782779314100044)
,p_name=>'SUBLEDGER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SUBLEDGER'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(16782820174100045)
,p_name=>'TRANSACTION_NUMBER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TRANSACTION_NUMBER'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Transaction Number'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>200
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(16782988332100046)
,p_name=>'TRANSACTION_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TRANSACTION_DATE'
,p_data_type=>'DATE'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_JET'
,p_heading=>'Transaction Date'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>60
,p_value_alignment=>'CENTER'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(16783042314100047)
,p_name=>'LEDGER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LEDGER'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Ledger'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>30
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(16783193391100048)
,p_name=>'PURGE_ELIGIBLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PURGE_ELIGIBLE'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>70
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(16783234067100049)
,p_name=>'PURGE_STATUS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PURGE_STATUS'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Purge Status'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>80
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>50
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(16783302846100050)
,p_name=>'PURGE_STATUS_MESSAGE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PURGE_STATUS_MESSAGE'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Purge Status Message'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>1000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(16948495783405101)
,p_name=>'CREATED_BY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CREATED_BY'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>100
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(16948551246405102)
,p_name=>'CREATED_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CREATED_DATE'
,p_data_type=>'TIMESTAMP'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>110
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(16948608407405103)
,p_name=>'LAST_UPDATED_BY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LAST_UPDATED_BY'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>120
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(16948703576405104)
,p_name=>'LAST_UPDATED_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LAST_UPDATED_DATE'
,p_data_type=>'TIMESTAMP'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>130
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_api.create_interactive_grid(
 p_id=>wwv_flow_api.id(16782435816100041)
,p_internal_uid=>16782435816100041
,p_is_editable=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_api.create_ig_report(
 p_id=>wwv_flow_api.id(16954348054405473)
,p_interactive_grid_id=>wwv_flow_api.id(16782435816100041)
,p_static_id=>'169544'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_api.create_ig_report_view(
 p_id=>wwv_flow_api.id(16954505961405474)
,p_report_id=>wwv_flow_api.id(16954348054405473)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(16955033312405482)
,p_view_id=>wwv_flow_api.id(16954505961405474)
,p_display_seq=>1
,p_column_id=>wwv_flow_api.id(16782535565100042)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(16955954473405493)
,p_view_id=>wwv_flow_api.id(16954505961405474)
,p_display_seq=>2
,p_column_id=>wwv_flow_api.id(16782649348100043)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(16956739137405500)
,p_view_id=>wwv_flow_api.id(16954505961405474)
,p_display_seq=>3
,p_column_id=>wwv_flow_api.id(16782779314100044)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(16957600156405506)
,p_view_id=>wwv_flow_api.id(16954505961405474)
,p_display_seq=>5
,p_column_id=>wwv_flow_api.id(16782820174100045)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>158.656
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(16958523513405514)
,p_view_id=>wwv_flow_api.id(16954505961405474)
,p_display_seq=>6
,p_column_id=>wwv_flow_api.id(16782988332100046)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>138.663
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(16959434436405519)
,p_view_id=>wwv_flow_api.id(16954505961405474)
,p_display_seq=>4
,p_column_id=>wwv_flow_api.id(16783042314100047)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>118.65299999999999
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(16960322438405523)
,p_view_id=>wwv_flow_api.id(16954505961405474)
,p_display_seq=>7
,p_column_id=>wwv_flow_api.id(16783193391100048)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(16961204535405528)
,p_view_id=>wwv_flow_api.id(16954505961405474)
,p_display_seq=>8
,p_column_id=>wwv_flow_api.id(16783234067100049)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>119.66000000000003
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(16962151260405532)
,p_view_id=>wwv_flow_api.id(16954505961405474)
,p_display_seq=>8
,p_column_id=>wwv_flow_api.id(16783302846100050)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(16963062780405535)
,p_view_id=>wwv_flow_api.id(16954505961405474)
,p_display_seq=>10
,p_column_id=>wwv_flow_api.id(16948495783405101)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(16963913315405539)
,p_view_id=>wwv_flow_api.id(16954505961405474)
,p_display_seq=>11
,p_column_id=>wwv_flow_api.id(16948551246405102)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(16964891081405544)
,p_view_id=>wwv_flow_api.id(16954505961405474)
,p_display_seq=>12
,p_column_id=>wwv_flow_api.id(16948608407405103)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(16965735097405548)
,p_view_id=>wwv_flow_api.id(16954505961405474)
,p_display_seq=>13
,p_column_id=>wwv_flow_api.id(16948703576405104)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16615030357716248)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(16614885023716246)
,p_button_name=>'Back'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(15953564518702893)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Back'
,p_button_position=>'ABOVE_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16614926841716247)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(16614885023716246)
,p_button_name=>'Refersh'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(15953564518702893)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Refersh'
,p_button_position=>'ABOVE_BOX'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16780857204100025)
,p_name=>'P3_BATCH_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(16614885023716246)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16780942346100026)
,p_name=>'P3_SUBLEDGER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(16614885023716246)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16781043797100027)
,p_name=>'P3_LEDGER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(16614885023716246)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(16781277451100029)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'username varchar2(200) := APEX_UTIL.GET_SESSION_STATE(''USER_NAME'');',
'begin :P_USER_NAME := username; end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(16781177447100028)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_user_name varchar2(200);',
'v_jwt_token  varchar2(4000);',
'',
'BEGIN',
'',
'-- APEX_CUSTOM_AUTH.SET_USER(''WESCO_USER'');',
'-- APEX_UTIL.SET_SESSION_STATE(''USER_NAME'',''WESCO_USER'');',
'',
'IF  APEX_UTIL.GET_SESSION_STATE(''USER_NAME'') IS NULL THEN',
'   ',
'  xx_apex_user_security_pkg.main(v_jwt_token,v_user_name,null);  ',
'  ',
'  APEX_UTIL.SET_SESSION_STATE(''USER_NAME'',v_user_name);',
'    APEX_UTIL.SET_SESSION_STATE(''JWT_TOKEN'',v_jwt_token);',
'   ',
'    IF APEX_UTIL.GET_SESSION_STATE(''USER_NAME'') IS NULL THEN',
'        APEX_UTIL.REDIRECT_URL(''f?p=&APP_ID.:9999:&APP_SESSION.'');',
'   ELSE',
'        APEX_CUSTOM_AUTH.SET_USER(APEX_UTIL.GET_SESSION_STATE(''USER_NAME''));',
'        ',
'   END IF;',
'   ',
'ELSE',
'   APEX_CUSTOM_AUTH.SET_USER(APEX_UTIL.GET_SESSION_STATE(''USER_NAME''));  ',
'   ',
'END IF;',
'',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
