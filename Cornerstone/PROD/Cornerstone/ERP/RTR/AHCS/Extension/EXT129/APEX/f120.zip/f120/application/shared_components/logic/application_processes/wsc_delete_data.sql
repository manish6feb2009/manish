prompt --application/shared_components/logic/application_processes/wsc_delete_data
begin
--   Manifest
--     APPLICATION PROCESS: WSC_DELETE_DATA
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1701052144005286
,p_default_application_id=>120
,p_default_id_offset=>0
,p_default_owner=>'FININT'
);
wwv_flow_api.create_flow_process(
 p_id=>wwv_flow_api.id(16020032101707282)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'WSC_DELETE_DATA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    L_BLOB           BLOB;',
'    L_CLOB           CLOB;',
'    L_DEST_OFFSET    INTEGER := 1;',
'    L_SRC_OFFSET     INTEGER := 1;',
'    L_LANG_CONTEXT   INTEGER := DBMS_LOB.DEFAULT_LANG_CTX;',
'    L_WARNING        INTEGER;',
'    L_LENGTH         INTEGER;',
'    P_SYSTEM_NAME_APP  varchar2(50)  := null;',
'',
'BEGIN',
'    DBMS_LOB.CREATETEMPORARY(L_BLOB, FALSE);',
'    select BLOB_DATA into L_BLOB from WSC_AHCS_PURGE_DATA_TEMPLATE_T where id = 1;',
'    L_LENGTH := DBMS_LOB.GETLENGTH(L_BLOB);  ',
'    dbms_output.put_line(l_length);',
'',
'    HTP.FLUSH;',
'    HTP.INIT;',
'',
'   OWA_UTIL.MIME_HEADER( ''application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'', FALSE);',
'',
'   HTP.P(''Content-length: '' || L_LENGTH);',
'   HTP.P(''Content-Disposition: attachment; filename="OIC purge data template.csv"'');',
'   HTP.P(''Set-Cookie: fileDownload=true; path=/'');',
'',
'   OWA_UTIL.HTTP_HEADER_CLOSE;',
'',
'   WPG_DOCLOAD.DOWNLOAD_FILE( L_BLOB );',
' EXCEPTION',
'   WHEN OTHERS THEN',
'     DBMS_LOB.FREETEMPORARY(L_BLOB);',
'     RAISE;',
'END;'))
,p_process_clob_language=>'PLSQL'
);
wwv_flow_api.component_end;
end;
/
