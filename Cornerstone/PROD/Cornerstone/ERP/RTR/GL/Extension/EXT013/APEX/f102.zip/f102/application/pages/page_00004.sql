prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1701052144005286
,p_default_application_id=>102
,p_default_id_offset=>22054525960715014
,p_default_owner=>'FININT'
);
wwv_flow_api.create_page(
 p_id=>4
,p_user_interface_id=>wwv_flow_api.id(27246903603868716)
,p_name=>'Wesco COA Upload Excel'
,p_alias=>'COA-MAPPING-UPLOAD-EXCEL'
,p_page_mode=>'MODAL'
,p_step_title=>'Wesco COA Upload Excel'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_api.id(27103530753868493)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'650'
,p_dialog_width=>'1200'
,p_page_is_public_y_n=>'Y'
,p_rejoin_existing_sessions=>'Y'
,p_last_updated_by=>'WESCO_DEV_DEVELOPER'
,p_last_upd_yyyymmddhh24miss=>'20230327073243'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(29622661605914169038)
,p_plug_name=>'COA Upload Excel'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(27155337943868575)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'	C001 COA_MAP_NAME,',
'	C002 SOURCE_SEGMENT1,',
'	C003 SOURCE_SEGMENT2,',
'	C004 SOURCE_SEGMENT3,',
'	C005 SOURCE_SEGMENT4,',
'	C006 SOURCE_SEGMENT5,',
'	C007 SOURCE_SEGMENT6,',
'	C008 SOURCE_SEGMENT7,',
'	C009 SOURCE_SEGMENT8,',
'	C010 SOURCE_SEGMENT9,',
'	C011 SOURCE_SEGMENT10',
'	',
'FROM APEX_COLLECTIONS C',
'WHERE C.COLLECTION_NAME=''XL2''',
'AND SEQ_ID > 1;'))
,p_plug_source_type=>'NATIVE_IG'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(38488867628164339)
,p_name=>'COA_MAP_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COA_MAP_NAME'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Coa Map Name'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>250
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(17549944612032707068)
,p_name=>'SOURCE_SEGMENT1'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT1'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Source Segment1'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>150
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(17549944764749707069)
,p_name=>'SOURCE_SEGMENT2'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT2'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Source Segment2'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>160
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(17549944846663707070)
,p_name=>'SOURCE_SEGMENT3'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT3'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Source Segment3'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>170
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(17549944929128707071)
,p_name=>'SOURCE_SEGMENT4'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT4'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Source Segment4'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>180
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(17549945089256707072)
,p_name=>'SOURCE_SEGMENT5'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT5'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Source Segment5'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>190
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(17549945170289707073)
,p_name=>'SOURCE_SEGMENT6'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT6'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Source Segment6'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>200
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(17549945292066707074)
,p_name=>'SOURCE_SEGMENT7'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT7'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Source Segment7'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>210
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(17549945370078707075)
,p_name=>'SOURCE_SEGMENT8'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT8'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Reference1'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>220
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(17549945418250707076)
,p_name=>'SOURCE_SEGMENT9'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT9'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Reference9'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>230
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(17549945576352707077)
,p_name=>'SOURCE_SEGMENT10'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_SEGMENT10'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Reference10'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>240
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_interactive_grid(
 p_id=>wwv_flow_api.id(29622661769309169039)
,p_internal_uid=>29600607243348454025
,p_is_editable=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_show_nulls_as=>'-'
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>false
,p_toolbar_buttons=>null
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_api.create_ig_report(
 p_id=>wwv_flow_api.id(29624447703345643266)
,p_interactive_grid_id=>wwv_flow_api.id(29622661769309169039)
,p_static_id=>'120775262'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_api.create_ig_report_view(
 p_id=>wwv_flow_api.id(29624447841201643266)
,p_report_id=>wwv_flow_api.id(29624447703345643266)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(38495635854165161)
,p_view_id=>wwv_flow_api.id(29624447841201643266)
,p_display_seq=>27
,p_column_id=>wwv_flow_api.id(38488867628164339)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(17549980501739712234)
,p_view_id=>wwv_flow_api.id(29624447841201643266)
,p_display_seq=>16
,p_column_id=>wwv_flow_api.id(17549944612032707068)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(17549981850091712236)
,p_view_id=>wwv_flow_api.id(29624447841201643266)
,p_display_seq=>17
,p_column_id=>wwv_flow_api.id(17549944764749707069)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(17549983222227712239)
,p_view_id=>wwv_flow_api.id(29624447841201643266)
,p_display_seq=>18
,p_column_id=>wwv_flow_api.id(17549944846663707070)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(17549984686480712241)
,p_view_id=>wwv_flow_api.id(29624447841201643266)
,p_display_seq=>19
,p_column_id=>wwv_flow_api.id(17549944929128707071)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(17549986097336712244)
,p_view_id=>wwv_flow_api.id(29624447841201643266)
,p_display_seq=>20
,p_column_id=>wwv_flow_api.id(17549945089256707072)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(17549987529297712246)
,p_view_id=>wwv_flow_api.id(29624447841201643266)
,p_display_seq=>21
,p_column_id=>wwv_flow_api.id(17549945170289707073)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(17549988940271712256)
,p_view_id=>wwv_flow_api.id(29624447841201643266)
,p_display_seq=>22
,p_column_id=>wwv_flow_api.id(17549945292066707074)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(17549990337400712259)
,p_view_id=>wwv_flow_api.id(29624447841201643266)
,p_display_seq=>23
,p_column_id=>wwv_flow_api.id(17549945370078707075)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(17549991792778712261)
,p_view_id=>wwv_flow_api.id(29624447841201643266)
,p_display_seq=>24
,p_column_id=>wwv_flow_api.id(17549945418250707076)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(17549993162804712264)
,p_view_id=>wwv_flow_api.id(29624447841201643266)
,p_display_seq=>25
,p_column_id=>wwv_flow_api.id(17549945576352707077)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(29624404877449033711)
,p_plug_name=>'Vendor Cost Data Upload'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(27126268930868538)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(33252460233040549)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(29624404877449033711)
,p_button_name=>'P4_LOAD'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(27222386225868667)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Load'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(33254350043040552)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(29622661605914169038)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(27222386225868667)
,p_button_image_alt=>'Cancel'
,p_button_position=>'BELOW_BOX'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(33253995848040551)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(29622661605914169038)
,p_button_name=>'Finish'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(27222386225868667)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Finish'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(33260267494040558)
,p_branch_name=>'Go To Page 2'
,p_branch_action=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:RP,::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(33254350043040552)
,p_branch_sequence=>30
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33214410773932030)
,p_name=>'P4_NEW_1'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(29624404877449033711)
,p_prompt=>'Please Select the Excel File:'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(27219924361868661)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'REQUEST'
,p_attribute_10=>'N'
,p_attribute_12=>'NATIVE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33215368726932040)
,p_name=>'P4_ERROR_MSG'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(29624404877449033711)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33253261260040550)
,p_name=>'P4_NEW'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(29624404877449033711)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(33256954933040555)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(33254350043040552)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(33257488707040556)
,p_event_id=>wwv_flow_api.id(33256954933040555)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(33257855833040556)
,p_name=>'New'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P4_BROWSE'
,p_condition_element=>'P4_BROWSE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(33258425367040556)
,p_event_id=>wwv_flow_api.id(33257855833040556)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var fp = $("#P4_BROWSE");',
'var lg = fp[0].files.length; // get length',
'var items = fp[0].files;',
'if (lg > 0) {',
'        for (var i = 0; i < lg; i++) {',
'            var fileName = items[i].name; // get file name',
'            var fileSize = items[i].size; // get file size ',
'            var fileType = items[i].type; // get file type',
'            apex.item( "P4_NEW" ).setValue( fileName, null, true );',
'           ',
' }',
'',
'}'))
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(33258900610040557)
,p_event_id=>wwv_flow_api.id(33257855833040556)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P_FILE_NAME := :P4_NEW;'
,p_attribute_02=>'P_FILE_NAME,P4_NEW'
,p_attribute_03=>'P_FILE_NAME'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(33255578460040554)
,p_name=>'New_2'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P4_BROWSE_1'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(33256103490040554)
,p_event_id=>wwv_flow_api.id(33255578460040554)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var fp = $("#P4_BROWSE_1");',
'var lg = fp[0].files.length; // get length',
'var items = fp[0].files;',
'if (lg > 0) {',
'        for (var i = 0; i < lg; i++) {',
'            var fileName = items[i].name; // get file name',
'            var fileSize = items[i].size; // get file size ',
'            var fileType = items[i].type; // get file type',
'            apex.item( "P4_NEW" ).setValue( fileName, null, true );',
'           ',
' }',
'',
'}'))
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(33256536218040555)
,p_event_id=>wwv_flow_api.id(33255578460040554)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P_FILE_NAME := :P4_NEW;'
,p_attribute_02=>'P4_NEW,P_FILE_NAME'
,p_attribute_03=>'P_FILE_NAME'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(33259289149040557)
,p_name=>'New_1'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(33253995848040551)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(33259787320040557)
,p_event_id=>wwv_flow_api.id(33259289149040557)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'APEX_COLLECTION.TRUNCATE_COLLECTION( ',
'',
'',
'    p_collection_name => ''XL2'');'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(33214500912932031)
,p_name=>'New_2'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P4_NEW_1'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(33214620335932032)
,p_event_id=>wwv_flow_api.id(33214500912932031)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var fp = $("#P4_NEW_1");',
'var lg = fp[0].files.length; // get length',
'var items = fp[0].files;',
'if (lg > 0) {',
'        for (var i = 0; i < lg; i++) {',
'            var fileName = items[i].name; // get file name',
'            var fileSize = items[i].size; // get file size ',
'            var fileType = items[i].type; // get file type',
'            apex.item( "P4_NEW" ).setValue( fileName, null, true );',
'           ',
' }',
'',
'}'))
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(33215020561932036)
,p_event_id=>wwv_flow_api.id(33214500912932031)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P_FILE_NAME := :P4_NEW;'
,p_attribute_02=>'P4_NEW,P_FILE_NAME'
,p_attribute_03=>'P_FILE_NAME'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(33255141401040554)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'PLUGIN_NL.AMIS.SCHEFFER.PROCESS.EXCEL2COLLECTION'
,p_process_name=>'ParseItemsDataFromXLSX'
,p_attribute_01=>'P4_NEW_1'
,p_attribute_02=>'XL2'
,p_attribute_03=>'1'
,p_attribute_04=>';'
,p_attribute_05=>'"'
,p_attribute_07=>'Y'
,p_attribute_08=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(33252460233040549)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(33254814616040552)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'LoadParsedItemsData'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Declare',
'Line_ID_Value number;',
'Header_ID Number;',
'',
'USER_NAME varchar2(200);',
'LV_COA_MAP_CNT number;',
'lv_error_msg varchar2(400);',
'lv_error varchar2(30) := ''False'';',
'V_COA_MAP_CHECK varchar2(200);',
'',
'e_error exception;',
'',
'begin',
'if upper(substr(:P_FILE_NAME,instr(:P_FILE_NAME,''.'',1)+1,length(:P_FILE_NAME)-instr(:P_FILE_NAME,''.'',1))) = upper(''CSV'') then',
'     ',
'     apex_util.set_session_state(''P4_ERROR_MSG'', ''Please Upload Excel Template'');',
'',
'     raise e_error;',
'  else ',
'	USER_NAME := :P_USER_NAME;',
'	Delete from WSC_GL_USER_COA_MAPPING_H where USER_NAME = :P_USER_NAME;',
'	Header_ID := WSC_GL_USER_COA_MAPPING_H_S.nextval;',
'	insert into WSC_GL_USER_COA_MAPPING_H(HEADER_ID,FILE_NAME,STATUS,USER_NAME)values (Header_ID,:P_FILE_NAME,''In Progress'',:P_USER_NAME);',
'    commit;',
'	delete from WSC_GL_USER_COA_MAPPING_T where USER_NAME = :P_USER_NAME;',
'    commit;',
'	-- Delete from WSC_GL_USER_COA_ERROR_T where USER_NAME = :P_USER_NAME;',
'    -- Line_ID_Value := WSC_GL_USER_COA_MAPPING_T_S.nextVal;',
'	Insert into WSC_GL_USER_COA_MAPPING_T(HEADER_ID,BATCH_ID,USER_NAME,COA_MAP_NAME,SOURCE_SEGMENT1,',
'	 SOURCE_SEGMENT2,SOURCE_SEGMENT3,SOURCE_SEGMENT4,SOURCE_SEGMENT5,SOURCE_SEGMENT6,SOURCE_SEGMENT7,SOURCE_SEGMENT8,',
'	 SOURCE_SEGMENT9,SOURCE_SEGMENT10,LEGACY_COA',
'	 -- ,ERROR_MESSAGE',
'	)',
'	select ',
'    Header_ID,',
'	Header_ID,',
'	USER_NAME,',
'	C001 ,',
'	C002 ,',
'	DECODE(C001,''WESCO to Cloud'',LPAD(C003, 6, ''0''),C003),',
'	C004 ,',
'	C005 ,',
'	C006 ,',
'	C007 ,',
'	C008 ,',
'	C009 ,',
'	C010 ,',
'	C011,',
'	nvl2(C002,C002,null)||nvl2(C003,''.''||DECODE(C001,''WESCO to Cloud'',LPAD(C003, 6, ''0''),C003),null)||',
'	nvl2(C004,''.''||C004,null)||nvl2(C005,''.''||C005,null)||',
'	nvl2(C006,''.''||C006,null)||nvl2(C007,''.''||C007,null)||',
'	nvl2(C008,''.''||C008,null)||',
'    case when C001 in (''WESCO to Cloud'' , ''POC to Cloud'') then ''.''|| C009 ',
'         when C009 is not null  then ''.''|| C009 ',
'         else null end || ',
'	nvl2(C010,''.''||C010,null)||nvl2(C011,''.''||C011,null)',
'	 -- lv_error_msg',
'	FROM APEX_COLLECTIONS C',
'			WHERE C.COLLECTION_NAME=''XL2''',
'			AND SEQ_ID>1 order by SEQ_ID;',
'	-- WSC_AHCS_AP_TRANSFORMATION_PKG.leg_coa_transformation(Header_ID);',
'	commit;',
'    dbms_output.put_line(''Before post_booking_flow_job'');',
'',
'  dbms_scheduler.create_job (',
'  job_name   =>  ''TRANSFORMRECORDS''||to_char(sysdate,''ddmonyyyyhh24miss''),',
'  job_type   => ''PLSQL_BLOCK'',',
'  job_action => ',
'    ''BEGIN ',
'       WSC_USER_COA_TRANSFORMATION_PKG.leg_coa_transformation(''||Header_ID||'',''||''''''''||:P_USER_NAME||''''''''||'');',
'     END;'',',
'  enabled   =>  TRUE,  ',
'  auto_drop =>  TRUE, ',
'  comments  =>  ''Purging Records from AHCS Staging Tables'');',
'end if;',
'end;',
'-- Declare',
'-- Line_ID_Value number;',
'-- Header_ID Number;',
'',
'-- USER_NAME varchar2(200);',
'-- LV_COA_MAP_CNT number;',
'-- lv_error_msg varchar2(400);',
'-- lv_error varchar2(30) := ''False'';',
'-- V_COA_MAP_CHECK varchar2(200);',
'',
'',
'-- begin',
'-- 	USER_NAME := :P_USER_NAME;',
'-- 	Delete from WSC_GL_USER_COA_MAPPING_H where USER_NAME = :P_USER_NAME;',
'-- 	Header_ID := WSC_GL_USER_COA_MAPPING_H_S.nextval;',
'-- 	insert into WSC_GL_USER_COA_MAPPING_H(HEADER_ID,FILE_NAME,STATUS,USER_NAME)values (Header_ID,:P_FILE_NAME,''In Progress'',:P_USER_NAME);',
'-- 	delete from WSC_GL_USER_COA_MAPPING_T where USER_NAME = :P_USER_NAME;',
'-- 	-- Delete from WSC_GL_USER_COA_ERROR_T where USER_NAME = :P_USER_NAME;',
'',
'-- 	Insert into WSC_GL_USER_COA_MAPPING_T(',
'--         LINE_ID,HEADER_ID,BATCH_ID,USER_NAME,COA_MAP_NAME,SOURCE_SEGMENT1,',
'-- 	    SOURCE_SEGMENT2,SOURCE_SEGMENT3,SOURCE_SEGMENT4,SOURCE_SEGMENT5,SOURCE_SEGMENT6,SOURCE_SEGMENT7,',
'--         SOURCE_SEGMENT8,SOURCE_SEGMENT9,SOURCE_SEGMENT10,LEGACY_COA',
'-- 	    -- ,ERROR_MESSAGE',
'-- 	)',
'-- 	select ',
'-- 	 WSC_GL_USER_COA_MAPPING_T_S.nextVal,',
'-- 	 Header_ID,',
'-- 	 Header_ID,',
'-- 	 USER_NAME,',
'-- 	 COA_MAP_NAME,',
'-- 	 SOURCE_SEGMENT1,',
'-- 	 SOURCE_SEGMENT2,',
'-- 	 SOURCE_SEGMENT3,',
'-- 	 SOURCE_SEGMENT4,',
'-- 	 SOURCE_SEGMENT5,',
'-- 	 SOURCE_SEGMENT6,',
'-- 	 SOURCE_SEGMENT7,',
'-- 	 SOURCE_SEGMENT8,',
'-- 	 SOURCE_SEGMENT9,',
'-- 	 SOURCE_SEGMENT10,',
'-- 	 nvl2(C001,SOURCE_SEGMENT1||''.''||,null)--||nvl2(SOURCE_SEGMENT2,SOURCE_SEGMENT2||''.'',null)||',
'',
'-- 	--  nvl2(SOURCE_SEGMENT3,SOURCE_SEGMENT3||''.'',null)||nvl2(SOURCE_SEGMENT4,SOURCE_SEGMENT4||''.'',null)||',
'-- 	--  nvl2(SOURCE_SEGMENT5,SOURCE_SEGMENT5||''.'',null)||nvl2(SOURCE_SEGMENT6,SOURCE_SEGMENT6||''.'',null)||',
'-- 	--  nvl2(SOURCE_SEGMENT7,SOURCE_SEGMENT7||''.'',null)||nvl2(SOURCE_SEGMENT8,SOURCE_SEGMENT8||''.'',null)||',
'-- 	--  nvl2(SOURCE_SEGMENT9,SOURCE_SEGMENT9||''.'',null)||nvl2(SOURCE_SEGMENT10,SOURCE_SEGMENT10||''.'',null)',
'-- 	 -- lv_error_msg',
'-- 	FROM APEX_COLLECTIONS C',
'-- 			WHERE C.COLLECTION_NAME=''XL1''',
'-- 			AND SEQ_ID>1 order by SEQ_ID;',
'-- 	-- WSC_AHCS_AP_TRANSFORMATION_PKG.leg_coa_transformation(Header_ID);',
'-- 	commit;',
'-- end;',
'',
'',
'-- Declare',
'-- Line_ID_Value number;',
'-- Header_ID Number;',
'',
'-- USER_NAME varchar2(200);',
'-- LV_COA_MAP_CNT number;',
'-- lv_error_msg varchar2(400);',
'-- lv_error varchar2(30) := ''False'';',
'-- V_COA_MAP_CHECK varchar2(200);',
'-- CURSOR C1 IS',
'-- 		SELECT ',
'-- 			C001 COA_MAP_NAME,',
'-- 			C002 SOURCE_SEGMENT1,',
'-- 			C003 SOURCE_SEGMENT2,',
'-- 			C004 SOURCE_SEGMENT3,',
'-- 			C005 SOURCE_SEGMENT4,',
'-- 			C006 SOURCE_SEGMENT5,',
'-- 			C007 SOURCE_SEGMENT6,',
'-- 			C008 SOURCE_SEGMENT7,',
'-- 			C009 SOURCE_SEGMENT8,',
'-- 			C010 SOURCE_SEGMENT9,',
'-- 			C011 SOURCE_SEGMENT10',
'-- 		FROM APEX_COLLECTIONS C',
'-- 			WHERE C.COLLECTION_NAME=''XL1''',
'-- 			AND SEQ_ID>1 order by SEQ_ID;',
'',
'-- type leg_seg_value_type is table of C1%rowtype;',
'-- lv_leg_seg_value leg_seg_value_type;',
'',
'',
'-- begin',
'-- USER_NAME := :P_USER_NAME;',
'-- Delete from WSC_GL_USER_COA_MAPPING_H where USER_NAME = :P_USER_NAME;',
'-- Header_ID := WSC_GL_USER_COA_MAPPING_H_S.nextval;',
'-- insert into WSC_GL_USER_COA_MAPPING_H(HEADER_ID,FILE_NAME,STATUS,USER_NAME)values (Header_ID,:P_FILE_NAME,''In Progress'',:P_USER_NAME);',
'-- delete from WSC_GL_USER_COA_MAPPING_T where USER_NAME = :P_USER_NAME;',
'-- -- Delete from WSC_GL_USER_COA_ERROR_T where USER_NAME = :P_USER_NAME;',
'-- begin',
'-- open C1;',
'-- loop',
'-- fetch C1 bulk collect into lv_leg_seg_value limit 400;',
'-- EXIT WHEN lv_leg_seg_value.COUNT = 0;',
'-- forall i in 1..lv_leg_seg_value.count',
'-- -- Line_ID_Value := ;',
'-- Insert into WSC_GL_USER_COA_MAPPING_T(LINE_ID,HEADER_ID,BATCH_ID,USER_NAME,COA_MAP_NAME,SOURCE_SEGMENT1,',
'-- SOURCE_SEGMENT2,SOURCE_SEGMENT3,SOURCE_SEGMENT4,SOURCE_SEGMENT5,SOURCE_SEGMENT6,SOURCE_SEGMENT7,SOURCE_SEGMENT8,',
'-- SOURCE_SEGMENT9,SOURCE_SEGMENT10,LEGACY_COA',
'-- -- ,ERROR_MESSAGE',
'-- )',
'-- values(WSC_GL_USER_COA_MAPPING_T_S.nextVal,',
'-- Header_ID,',
'-- Header_ID,',
'-- USER_NAME,',
'-- lv_leg_seg_value(i).COA_MAP_NAME,',
'-- lv_leg_seg_value(i).SOURCE_SEGMENT1,',
'-- lv_leg_seg_value(i).SOURCE_SEGMENT2,',
'-- lv_leg_seg_value(i).SOURCE_SEGMENT3,',
'-- lv_leg_seg_value(i).SOURCE_SEGMENT4,',
'-- lv_leg_seg_value(i).SOURCE_SEGMENT5,',
'-- lv_leg_seg_value(i).SOURCE_SEGMENT6,',
'-- lv_leg_seg_value(i).SOURCE_SEGMENT7,',
'-- lv_leg_seg_value(i).SOURCE_SEGMENT8,',
'-- lv_leg_seg_value(i).SOURCE_SEGMENT9,',
'-- lv_leg_seg_value(i).SOURCE_SEGMENT10,',
'-- nvl2(lv_leg_seg_value(i).SOURCE_SEGMENT1,lv_leg_seg_value(i).SOURCE_SEGMENT1,null)||''.''||nvl2(lv_leg_seg_value(i).SOURCE_SEGMENT2,lv_leg_seg_value(i).SOURCE_SEGMENT2,null)||''.''||nvl2(lv_leg_seg_value(i).SOURCE_SEGMENT3,lv_leg_seg_value(i).SOURCE_S'
||'EGMENT3,null)||''.''||nvl2(lv_leg_seg_value(i).SOURCE_SEGMENT4,lv_leg_seg_value(i).SOURCE_SEGMENT4,null)||''.''||',
'-- nvl2(lv_leg_seg_value(i).SOURCE_SEGMENT5,lv_leg_seg_value(i).SOURCE_SEGMENT5,null)||''.''||nvl2(lv_leg_seg_value(i).SOURCE_SEGMENT6,lv_leg_seg_value(i).SOURCE_SEGMENT6,null)||''.''||nvl2(lv_leg_seg_value(i).SOURCE_SEGMENT7,lv_leg_seg_value(i).SOURCE_S'
||'EGMENT7,null)||''.''||nvl2(lv_leg_seg_value(i).SOURCE_SEGMENT8,lv_leg_seg_value(i).SOURCE_SEGMENT8,null)||''.''||',
'-- nvl2(lv_leg_seg_value(i).SOURCE_SEGMENT9,lv_leg_seg_value(i).SOURCE_SEGMENT9,null)||''.''||nvl2(lv_leg_seg_value(i).SOURCE_SEGMENT10,lv_leg_seg_value(i).SOURCE_SEGMENT10,null)',
'-- -- lv_error_msg',
'-- );',
'-- end loop;',
'-- commit;',
'-- exception',
'--     when others then',
'--         insert into xx_test_procedure (TEST) values(''sqlerrm'');',
'-- end;',
'-- -- for REC_C1 in C1 loop',
'-- -- Line_ID_Value := WSC_GL_USER_COA_MAPPING_T_S.nextVal;',
'-- -- -- if((REC_C1.SOURCE_SEGMENT1 is null)and(REC_C1.SOURCE_SEGMENT2 is null) and (REC_C1.SOURCE_SEGMENT3 is null )and (REC_C1.SOURCE_SEGMENT4 is null) and (REC_C1.SOURCE_SEGMENT5 is null)',
'-- -- -- and (REC_C1.SOURCE_SEGMENT6 is null) and (REC_C1.SOURCE_SEGMENT7 is null) and (REC_C1.SOURCE_SEGMENT8 is null) and (REC_C1.SOURCE_SEGMENT9 is null) and (REC_C1.SOURCE_SEGMENT10 is null))',
'-- -- -- then',
'',
'-- -- -- lv_error_msg :=  '' :: alleast one source segment having a value.'';',
'-- -- -- lv_error := ''True'';',
'-- -- -- end if;',
'-- -- -- LV_COA_MAP_CNT := EXIT_COA_MAP_NAME(REC_C1.COA_MAP_NAME);',
'-- -- -- if(LV_COA_MAP_CNT = 0)then',
'-- -- -- lv_error_msg := lv_error_msg || '' -> '' || REC_C1.COA_MAP_NAME || '' :: COA Map Name value is invalid. Please verify.'';',
'-- -- -- lv_error := ''True'';',
'-- -- -- end if;',
'-- -- Insert into WSC_GL_USER_COA_MAPPING_T(LINE_ID,HEADER_ID,BATCH_ID,USER_NAME,COA_MAP_NAME,SOURCE_SEGMENT1,',
'-- -- SOURCE_SEGMENT2,SOURCE_SEGMENT3,SOURCE_SEGMENT4,SOURCE_SEGMENT5,SOURCE_SEGMENT6,SOURCE_SEGMENT7,SOURCE_SEGMENT8,',
'-- -- SOURCE_SEGMENT9,SOURCE_SEGMENT10,LEGACY_COA',
'-- -- -- ,ERROR_MESSAGE',
'-- -- )',
'-- -- values(Line_ID_Value,',
'-- -- Header_ID,',
'-- -- Header_ID,',
'-- -- USER_NAME,',
'-- -- REC_C1.COA_MAP_NAME,',
'-- -- REC_C1.SOURCE_SEGMENT1,',
'-- -- REC_C1.SOURCE_SEGMENT2,',
'-- -- REC_C1.SOURCE_SEGMENT3,',
'-- -- REC_C1.SOURCE_SEGMENT4,',
'-- -- REC_C1.SOURCE_SEGMENT5,',
'-- -- REC_C1.SOURCE_SEGMENT6,',
'-- -- REC_C1.SOURCE_SEGMENT7,',
'-- -- REC_C1.SOURCE_SEGMENT8,',
'-- -- REC_C1.SOURCE_SEGMENT9,',
'-- -- REC_C1.SOURCE_SEGMENT10,',
'-- -- nvl2(REC_C1.SOURCE_SEGMENT1,REC_C1.SOURCE_SEGMENT1,null)||''.''||nvl2(REC_C1.SOURCE_SEGMENT2,REC_C1.SOURCE_SEGMENT2,null)||''.''||nvl2(REC_C1.SOURCE_SEGMENT3,REC_C1.SOURCE_SEGMENT3,null)||''.''||nvl2(REC_C1.SOURCE_SEGMENT4,REC_C1.SOURCE_SEGMENT4,null'
||')||''.''||',
'-- -- nvl2(REC_C1.SOURCE_SEGMENT5,REC_C1.SOURCE_SEGMENT5,null)||''.''||nvl2(REC_C1.SOURCE_SEGMENT6,REC_C1.SOURCE_SEGMENT6,null)||''.''||nvl2(REC_C1.SOURCE_SEGMENT7,REC_C1.SOURCE_SEGMENT7,null)||''.''||nvl2(REC_C1.SOURCE_SEGMENT8,REC_C1.SOURCE_SEGMENT8,null'
||')||''.''||',
'-- -- nvl2(REC_C1.SOURCE_SEGMENT9,REC_C1.SOURCE_SEGMENT9,null)||''.''||nvl2(REC_C1.SOURCE_SEGMENT10,REC_C1.SOURCE_SEGMENT10,null)',
'-- -- -- lv_error_msg',
'-- -- );',
'-- dbms_output.put_line(''done'');',
'',
'-- -- end loop;',
'-- -- WSC_AHCS_AP_TRANSFORMATION_PKG.leg_coa_transformation(Header_ID);',
'-- -- commit;',
'-- end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'&P4_ERROR_MSG.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
