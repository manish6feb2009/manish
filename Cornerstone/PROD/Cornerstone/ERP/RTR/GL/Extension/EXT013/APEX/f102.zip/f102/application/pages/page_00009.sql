prompt --application/pages/page_00009
begin
--   Manifest
--     PAGE: 00009
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1701052144005286
,p_default_application_id=>102
,p_default_id_offset=>22054525960715014
,p_default_owner=>'FININT'
);
wwv_flow_api.create_page(
 p_id=>9
,p_user_interface_id=>wwv_flow_api.id(27246903603868716)
,p_name=>'WSC_COA_ONE_TO_ONE_TEST'
,p_alias=>'WSC-COA-ONE-TO-ONE-TEST'
,p_step_title=>'WSC_COA_ONE_TO_ONE_TEST'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_last_updated_by=>'WESCO_SIT1_DEVELOPER'
,p_last_upd_yyyymmddhh24miss=>'20211103121551'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(45944342268615287)
,p_plug_name=>'Wesco COA One to One Transformation'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:t-Form--standardPadding:t-Form--large:margin-top-md:margin-bottom-md'
,p_plug_template=>wwv_flow_api.id(27157263113868577)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(35751562847424097)
,p_button_sequence=>130
,p_button_plug_id=>wwv_flow_api.id(45944342268615287)
,p_button_name=>'Transform'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(27222386225868667)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Transform COA'
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_column_span=>3
,p_grid_column=>7
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(35752002875424104)
,p_name=>'9_COA_MAP_NAME_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(45944342268615287)
,p_prompt=>'COA Map Name'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select COA_MAP_NAME a, COA_MAP_NAME b from wsc_gl_coa_map_t  '
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_colspan=>3
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_api.id(27219679402868660)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(35752344235424107)
,p_name=>'P9_NEW_12'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(45944342268615287)
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cattributes_element=>'style="color:red;"'
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>0
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(27219679402868660)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(35752798122424108)
,p_name=>'P9_NEW_1'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(45944342268615287)
,p_prompt=>'Source Segment1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_colspan=>3
,p_grid_column=>1
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_api.id(27219679402868660)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(35753164763424109)
,p_name=>'P9_NEW_2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(45944342268615287)
,p_prompt=>'Source Segment2'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_grid_column=>4
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_api.id(27219679402868660)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(35753570450424110)
,p_name=>'P9_NEW_3'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(45944342268615287)
,p_prompt=>'Source Segment3'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_grid_column=>7
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_api.id(27219679402868660)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(35754000043424111)
,p_name=>'P9_NEW_4'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(45944342268615287)
,p_prompt=>'Source Segment4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_grid_column=>10
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_api.id(27219679402868660)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(35754364848424112)
,p_name=>'P9_NEW_5'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(45944342268615287)
,p_prompt=>'Source Segment5'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_colspan=>3
,p_grid_column=>1
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_api.id(27219679402868660)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(35754749000424113)
,p_name=>'P9_NEW_6'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(45944342268615287)
,p_prompt=>'Source Segment6'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_grid_column=>4
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_api.id(27219679402868660)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(35755200111424114)
,p_name=>'P9_NEW_7'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(45944342268615287)
,p_prompt=>'Source Segment7'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_grid_column=>7
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_api.id(27219679402868660)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(35755550027424115)
,p_name=>'P9_NEW_8'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(45944342268615287)
,p_prompt=>'Reference_1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_grid_column=>10
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_api.id(27219679402868660)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(35755947514424116)
,p_name=>'P9_NEW_9'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(45944342268615287)
,p_prompt=>'Reference_2'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_colspan=>3
,p_grid_column=>1
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_api.id(27219679402868660)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(35756402986424116)
,p_name=>'P9_NEW_10'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(45944342268615287)
,p_prompt=>'Reference_3'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_grid_column=>4
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_api.id(27219679402868660)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(35756756988424118)
,p_name=>'P9_NEW_11'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(45944342268615287)
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(27219924361868661)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(35757202679424118)
,p_name=>'P9_NEW'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(45944342268615287)
,p_prompt=>'Transformed Value '
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>250
,p_read_only_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(27219679402868660)
,p_item_template_options=>'#DEFAULT#:margin-top-lg'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(35758286988424158)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(35751562847424097)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(35759250505424164)
,p_event_id=>wwv_flow_api.id(35758286988424158)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
':P9_NEW:=WSC_USER_COA_TRANSFORMATION_PKG.transformation_one(:9_COA_MAP_NAME_ID,:P9_NEW_1,:P9_NEW_2,:P9_NEW_3,:P9_NEW_4,:P9_NEW_5,:P9_NEW_6,:P9_NEW_7,',
':P9_NEW_8,:P9_NEW_9,:P9_NEW_10,:P_USER_NAME);',
'',
'end;'))
,p_attribute_02=>'P9_NEW_1,P9_NEW_2,P9_NEW_3,P9_NEW_4,P9_NEW_5,P9_NEW_6,P9_NEW_7,P9_NEW_8,P9_NEW_9,P9_NEW_10,COA_MAP_NAME_ID,9_COA_MAP_NAME_ID'
,p_attribute_03=>'P9_NEW'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(35758812318424162)
,p_event_id=>wwv_flow_api.id(35758286988424158)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9_NEW'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>'select :P9_NEW from dual;'
,p_attribute_07=>'P9_NEW'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(35759670511424165)
,p_name=>'New_1'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'COA_MAP_NAME_ID'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(35760143696424166)
,p_event_id=>wwv_flow_api.id(35759670511424165)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9_NEW_12'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Please enter Segment 1 to  Reference 1 OR Segment 2 to Segment 7'' from dual where :COA_MAP_NAME_ID=''WESCO to Cloud''',
'union all',
'select ''Please enter Segment 1 & Segment 2 '' from dual where :COA_MAP_NAME_ID=''Central to Cloud''',
'union all',
'select ''Please enter Segment 1 to  Reference 1 OR Segment 2 to Segment 7'' from dual where :COA_MAP_NAME_ID=''POC to Cloud'''))
,p_attribute_07=>'COA_MAP_NAME_ID'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(35531146337001441)
,p_name=>'New_2'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'9_COA_MAP_NAME_ID'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(35531323645001442)
,p_event_id=>wwv_flow_api.id(35531146337001441)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($v("9_COA_MAP_NAME_ID")==''WESCO to Cloud'') {',
'    $("label[for=P9_NEW_1]").text("*Source Segment1")',
'    $("label[for=P9_NEW_2]").text("*Source Segment2")',
'    $("label[for=P9_NEW_3]").text("*Source Segment3")',
'    $("label[for=P9_NEW_4]").text("*Source Segment4")',
'    $("label[for=P9_NEW_5]").text("*Source Segment5")',
'    $("label[for=P9_NEW_6]").text("*Source Segment6")',
'    $("label[for=P9_NEW_7]").text("*Source Segment7")',
'    $("label[for=P9_NEW_8]").text("*Reference_1")',
'	',
'    $("#P9_NEW_1").removeAttr("disabled")',
'    $("#P9_NEW_2").removeAttr("disabled")',
'    $("#P9_NEW_3").removeAttr("disabled")',
'    $("#P9_NEW_4").removeAttr("disabled")',
'    $("#P9_NEW_5").removeAttr("disabled")',
'    $("#P9_NEW_6").removeAttr("disabled")',
'    $("#P9_NEW_7").removeAttr("disabled")  ',
'    $(''#P9_NEW_8'').attr(''disabled'', ''disabled'')',
'    $(''#P9_NEW_9'').attr(''disabled'', ''disabled'')',
'    $(''#P9_NEW_10'').attr(''disabled'', ''disabled'')',
'} ',
'else if ($v("9_COA_MAP_NAME_ID")==''POC to Cloud'') {',
'       $("label[for=P9_NEW_1]").text("*Source Segment1")',
'    $("label[for=P9_NEW_2]").text("*Source Segment2")',
'    $("label[for=P9_NEW_3]").text("*Source Segment3")',
'    $("label[for=P9_NEW_4]").text("*Source Segment4")',
'    $("label[for=P9_NEW_5]").text("*Source Segment5")',
'    $("label[for=P9_NEW_6]").text("*Source Segment6")',
'    $("label[for=P9_NEW_7]").text("*Source Segment7")',
'    $("label[for=P9_NEW_8]").text("*Reference_1")',
'	',
'    $("#P9_NEW_1").removeAttr("disabled")',
'    $("#P9_NEW_2").removeAttr("disabled")',
'    $("#P9_NEW_3").removeAttr("disabled")',
'    $("#P9_NEW_4").removeAttr("disabled")',
'    $("#P9_NEW_5").removeAttr("disabled")',
'    $("#P9_NEW_6").removeAttr("disabled")',
'    $("#P9_NEW_7").removeAttr("disabled")  ',
'    $(''#P9_NEW_8'').attr(''disabled'', ''disabled'')',
'    $(''#P9_NEW_9'').attr(''disabled'', ''disabled'')',
'    $(''#P9_NEW_10'').attr(''disabled'', ''disabled'')',
'}',
'',
'else if ($v("9_COA_MAP_NAME_ID")==''Central to Cloud'') {',
'    $("label[for=P9_NEW_1]").text("*Source Segment1")',
'    $("label[for=P9_NEW_2]").text("*Source Segment2")',
'    $("label[for=P9_NEW_3]").text("Source Segment3")',
'    $("label[for=P9_NEW_4]").text("Source Segment4")',
'    $("label[for=P9_NEW_5]").text("Source Segment5")',
'    $("label[for=P9_NEW_6]").text("Source Segment6")',
'    $("label[for=P9_NEW_7]").text("Source Segment7")',
'    $("label[for=P9_NEW_8]").text("Reference_1")',
'    ',
'    $("#P9_NEW_1").removeAttr("disabled")',
'    $("#P9_NEW_2").removeAttr("disabled")',
'    $(''#P9_NEW_3'').attr(''disabled'', ''disabled'')',
'    $(''#P9_NEW_4'').attr(''disabled'', ''disabled'')',
'    $(''#P9_NEW_5'').attr(''disabled'', ''disabled'')',
'    $(''#P9_NEW_6'').attr(''disabled'', ''disabled'')',
'    $(''#P9_NEW_7'').attr(''disabled'', ''disabled'')',
'    $(''#P9_NEW_8'').attr(''disabled'', ''disabled'')',
'    $(''#P9_NEW_9'').attr(''disabled'', ''disabled'')',
'    $(''#P9_NEW_10'').attr(''disabled'', ''disabled'')',
'}'))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(35531513548001444)
,p_name=>'New_3'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9_NEW_1'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(35531537836001445)
,p_event_id=>wwv_flow_api.id(35531513548001444)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($v("9_COA_MAP_NAME_ID")==''WESCO to Cloud'' || $v("9_COA_MAP_NAME_ID")== ''POC to Cloud'') {',
'    if($v("P9_NEW_1") != ''''){',
'        $("#P9_NEW_8").removeAttr("disabled");   ',
'    }',
'    else{',
'        $(''#P9_NEW_8'').attr(''disabled'', ''disabled'')',
'        $("#P9_NEW_8").val(null)',
'    }',
'}'))
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(35757923274424157)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'username varchar2(200) := APEX_UTIL.GET_SESSION_STATE(''USER_NAME'');',
'begin :P_USER_NAME := username; end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(35531372808001443)
,p_process_sequence=>10
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'New_2'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(35757561215424154)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_user_name varchar2(200);',
'v_jwt_token  varchar2(4000);',
'',
'BEGIN',
'',
'/*APEX_CUSTOM_AUTH.SET_USER(''WESCO_USER'');*/',
'',
'IF  APEX_UTIL.GET_SESSION_STATE(''USER_NAME'') IS NULL THEN',
'   ',
'  xx_apex_user_security_pkg.main(v_jwt_token,v_user_name,null);  ',
'--   insert into tbl_time_t values (v_user_name||v_jwt_token,sysdate,4);',
'       commit;',
'',
'   ',
'    APEX_UTIL.SET_SESSION_STATE(''USER_NAME'',v_user_name);',
'    APEX_UTIL.SET_SESSION_STATE(''JWT_TOKEN'',v_jwt_token);',
'   ',
'    IF APEX_UTIL.GET_SESSION_STATE(''USER_NAME'') IS NULL THEN',
'        APEX_UTIL.REDIRECT_URL(''f?p=&APP_ID.:9999:&APP_SESSION.'');',
'   ELSE',
'        APEX_CUSTOM_AUTH.SET_USER(APEX_UTIL.GET_SESSION_STATE(''USER_NAME''));',
'        ',
'   END IF;',
'   ',
'ELSE',
'   APEX_CUSTOM_AUTH.SET_USER(APEX_UTIL.GET_SESSION_STATE(''USER_NAME''));  ',
'   ',
'END IF;',
'',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
